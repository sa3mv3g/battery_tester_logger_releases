"""
This module defines the `ModbusDeviceConfigGui` class, which provides a graphical
user interface (GUI) for configuring Modbus devices. The GUI allows users to manage
Modbus device configurations, including holding registers, input registers,
discrete inputs, and coils. It also supports updating and adding new configurations
through user interactions.
Classes:
    ModbusDeviceConfigGui: A class that extends `ModbusDeviceConfigDialog`
    to provide a GUI for Modbus device configuration.

"""

import typing
import wx
from .usergui.modbusDeviceConfig import ModbusDeviceConfigDialog
from .mbDeviceConfig import ModbusDeviceConfig, HoldingRegister, InputRegister, DiscreteInput, Coil
from .common import REGISTER_DATATYPE_U16
from .common import REGISTER_DATATYPE_I16
from .common import REGISTER_DATATYPE_U32
from .common import REGISTER_DATATYPE_I32
from .common import REGISTER_DATATYPE_F32
from .common import appSerialPortInfo
from .common import appTcpPortInfo
from .usergui.serialDeviceTypeSelector import serial_device_type_selector_dialog

class SerialDeviceTypeSelectorDialog(serial_device_type_selector_dialog):
    # pylint: disable=too-many-ancestors
    def __init__(self, parent):
        super().__init__(parent)
        self.type:str = ModbusDeviceConfig.INTERFACE_TYPE_RTU

    def _evt_on_close(self, event):
        # pylint: disable=unused-argument
        sel = self.m_choice3.GetSelection()
        if sel == 0:
            self.type = ModbusDeviceConfig.INTERFACE_TYPE_RTU
        elif sel == 1:
            self.type = ModbusDeviceConfig.INTERFACE_TYPE_ASCII
        self.Destroy()

class ModbusDeviceConfigGui(ModbusDeviceConfigDialog): # pylint: disable=too-many-ancestors
    """
        A GUI class for configuring Modbus devices.
        This class provides methods to manage and update the configuration of Modbus devices,
        including holding registers, input registers, discrete inputs, and coils. It also
        handles the user interface interactions for adding, updating, and clearing these
        configurations.
    """
    def __init__(self, parent, modbus_device_config: ModbusDeviceConfig = None,
                 serial_config_list: typing.List[appSerialPortInfo] = None,
                 tcp_config_list: typing.List[appTcpPortInfo] = None,
                 **kwargs ):
        # pylint: disable=unused-argument
        super().__init__(parent)
        if modbus_device_config is None:
            modbus_device_config = ModbusDeviceConfig(
            device_address=0,
            interface_type = ModbusDeviceConfig.INTERFACE_TYPE_UNDEFINED,
            interface_config={},
            holding_registers={},
            input_registers={},
            discrete_inputs={},
            coils={},
            mime_identification=None,
            device_name = ""
            )
        self.modbus_device_config: typing.Optional[ModbusDeviceConfig] = modbus_device_config
        self.serial_config_list: typing.List[appSerialPortInfo] = serial_config_list
        self.tcp_config_list: typing.List[appTcpPortInfo] = tcp_config_list
        self._refresh_all_grid_boxes()

    def _update_holdings_registers_grid(self, event):
        """
        Updates the grid displaying the holding registers
        with the current data from the modbus device configuration.

        This method clears the existing grid and populates
        it with the address, label, description, and data type of
        each holding register.

        Args:
            event: The event that triggered this update, typically a UI event.
        """
        # pylint: disable=unused-argument
        self.m_grid_holding_registers.ClearGrid()
        if self.m_grid_holding_registers.GetNumberRows() > 0:
            self.m_grid_holding_registers.DeleteRows(
                0,
                self.m_grid_holding_registers.GetNumberRows()
            )

        for i, (address, register) in enumerate(
            self.modbus_device_config.holding_registers.items()
        ):
            self.m_grid_holding_registers.AppendRows(1)
            self.m_grid_holding_registers.SetCellValue(i, 0, str(address))
            self.m_grid_holding_registers.SetCellValue(i, 1, register.label)
            self.m_grid_holding_registers.SetCellValue(i, 2, register.description)
            self.m_grid_holding_registers.SetCellValue(i, 3, str(register.dataType))

        self.m_grid_holding_registers.AutoSizeColumns()
        self.m_grid_holding_registers.AutoSizeRows()
        self.m_grid_holding_registers.MakeCellVisible(self.m_grid_holding_registers.GetNumberRows()-1, 0)
        self.m_grid_holding_registers.ForceRefresh()

    def _add_holding_register(self, event) -> None:
        """
        Adds a holding register to the Modbus device configuration.

        This function retrieves the label, address, description, and
        data type for a new holding register from the user interface,
        validates the input, and adds the holding register to the Modbus
        device configuration. If the address already exists, it
        prompts the user to confirm whether to replace the existing register.

        Parameters:
            event (wx.Event): The event that triggered this function.

        Returns:
            None
        """
        # pylint: disable=unused-argument
        label = self.m_textCtrl_holding_register_label.GetValue()
        address = self.m_textCtrl_holding_register_address.GetValue()
        description = self.m_textCtrl_holding_register_description.GetValue()
        data_type = self.m_choice_holding_register_data_type.GetStringSelection()
        if not label or not address or not description:
            wx.LogError("Please fill in all fields.")
            return
        if not address.isdigit():
            wx.LogError("Address must be an integer.")
            return
        address = int(address)
        do_update: bool = True
        if address in self.modbus_device_config.holding_registers:
            dialog = wx.MessageDialog(
                self,
                "Address already exists. Do you want to replace it?",
                "Confirm Replace",
                wx.YES_NO | wx.NO_DEFAULT | wx.ICON_QUESTION
            )
            if dialog.ShowModal() == wx.ID_NO:
                do_update = False
            dialog.Destroy()
        if do_update:
            hr =  HoldingRegister(address, None, description, label)
            if data_type == 'unsigned 16bit':
                hr.dataType = REGISTER_DATATYPE_U16
            elif data_type == 'signed 16bit':
                hr.dataType = REGISTER_DATATYPE_I16
            elif data_type == 'unsigned 32bit':
                hr.dataType = REGISTER_DATATYPE_U32
            elif data_type == 'signed 32bit':
                hr.dataType = REGISTER_DATATYPE_I32
            elif data_type == 'float':
                hr.dataType = REGISTER_DATATYPE_F32
            else:
                hr.dataType = REGISTER_DATATYPE_U16
            self.modbus_device_config.holding_registers[address] = hr
            self._update_holdings_registers_grid(event)

    def _update_input_registers_grid(self, event):
        """
        Updates the input registers grid with the current data from the modbus device configuration.

        This method clears the existing grid and populates it with the address, label, description,
        and data type of each input register from the modbus device configuration.

        Args:
            event: The event that triggered this update, typically a UI event.
        """
        # pylint: disable=unused-argument
        self.m_grid_input_registers.ClearGrid()
        if self.m_grid_input_registers.GetNumberRows() > 0:
            self.m_grid_input_registers.DeleteRows(0, self.m_grid_input_registers.GetNumberRows())
        for i, (address, register) in enumerate(self.modbus_device_config.input_registers.items()):
            self.m_grid_input_registers.AppendRows(1)
            self.m_grid_input_registers.SetCellValue(i, 0, str(address))
            self.m_grid_input_registers.SetCellValue(i, 1, register.label)
            self.m_grid_input_registers.SetCellValue(i, 2, register.description)
            self.m_grid_input_registers.SetCellValue(i, 3, str(register.dataType))

        self.m_grid_input_registers.AutoSizeColumns()
        self.m_grid_input_registers.AutoSizeRows()
        self.m_grid_input_registers.MakeCellVisible(self.m_grid_input_registers.GetNumberRows()-1, 0)
        self.m_grid_input_registers.ForceRefresh()


    def _add_input_register(self, event):
        """
        Adds an input register to the Modbus device configuration.

        This method retrieves the label, address, description, and
        data type for the input register from the respective UI controls.
        It performs validation on the input fields and checks if the
        address already exists in the configuration. If the address exists,
        it prompts the user to confirm whether to replace the existing
        register. If confirmed or if the address does not exist, it creates
        a new InputRegister object with the specified parameters and adds
        it to the Modbus device configuration.

        Args:
            event (wx.Event): The event that triggered this method.

        Returns:
            None
        """
        # pylint: disable=unused-argument
        label = self.m_textCtrl_input_register_label.GetValue()
        address = self.m_textCtrl_input_register_address.GetValue()
        description = self.m_textCtrl_input_register_description.GetValue()
        data_type = self.m_choice_input_register_data_type.GetStringSelection()
        if not label or not address or not description:
            wx.LogError("Please fill in all fields.")
            return
        if not address.isdigit():
            wx.LogError("Address must be an integer.")
            return
        address = int(address)
        do_update: bool = True
        if address in self.modbus_device_config.input_registers:
            dialog = wx.MessageDialog(
                self,
                "Address already exists. Do you want to replace it?",
                "Confirm Replace",
                wx.YES_NO | wx.NO_DEFAULT | wx.ICON_QUESTION)
            if dialog.ShowModal() == wx.ID_NO:
                do_update = False
            dialog.Destroy()
        if do_update:
            ir =  InputRegister(address, None, description, label)
            if data_type == 'unsigned 16bit':
                ir.dataType = REGISTER_DATATYPE_U16
            elif data_type == 'signed 16bit':
                ir.dataType = REGISTER_DATATYPE_I16
            elif data_type == 'unsigned 32bit':
                ir.dataType = REGISTER_DATATYPE_U32
            elif data_type == 'signed 32bit':
                ir.dataType = REGISTER_DATATYPE_I32
            elif data_type == 'float':
                ir.dataType = REGISTER_DATATYPE_F32
            else:
                ir.dataType = REGISTER_DATATYPE_U16
            self.modbus_device_config.input_registers[address] = ir
            self._update_input_registers_grid(event)

    def _update_di_grid(self, event):
        """
        Updates the discrete inputs grid with the current Modbus device configuration.

        This method clears the existing grid and populates it with the address, label,
        and description of each discrete input from the Modbus device configuration.

        Args:
            event: The event that triggered this update.
        """
        # pylint: disable=unused-argument
        self.m_grid_di.ClearGrid()
        if self.m_grid_di.GetNumberRows() > 0:
            self.m_grid_di.DeleteRows(0, self.m_grid_di.GetNumberRows())
        for i, (address, di) in enumerate(self.modbus_device_config.discrete_inputs.items()):
            self.m_grid_di.AppendRows(1)
            self.m_grid_di.SetCellValue(i, 0, str(address))
            self.m_grid_di.SetCellValue(i, 1, di.label)
            self.m_grid_di.SetCellValue(i, 2, di.description)

        self.m_grid_di.AutoSizeColumns()
        self.m_grid_di.AutoSizeRows()
        self.m_grid_di.MakeCellVisible(self.m_grid_di.GetNumberRows()-1, 0)
        self.m_grid_di.ForceRefresh()

    def _add_di(self, event):
        """
        Adds a discrete input (DI) to the modbus device configuration.

        This method retrieves the label, address, and description from the respective
        text controls. It validates the inputs and checks if the address already exists
        in the configuration. If the address exists, it prompts the user to confirm
        whether to replace the existing entry. If confirmed or if the address does not
        exist, it adds the new DI to the configuration and updates the DI grid.

        Parameters:
            event (wx.Event): The event that triggered this method.

        Returns:
            None
        """
        # pylint: disable=unused-argument
        label = self.m_textCtrl_di_label.GetValue()
        address = self.m_textCtrl_di_address.GetValue()
        description = self.m_textCtrl_di_description.GetValue()
        if not label or not address or not description:
            wx.LogError("Please fill in all fields.")
            return
        if not address.isdigit():
            wx.LogError("Address must be an integer.")
            return
        address = int(address)
        do_update: bool = True
        if address in self.modbus_device_config.discrete_inputs:
            dialog = wx.MessageDialog(
                self,
                "Address already exists. Do you want to replace it?",
                "Confirm Replace",
                wx.YES_NO | wx.NO_DEFAULT | wx.ICON_QUESTION
            )
            if dialog.ShowModal() == wx.ID_NO:
                do_update = False
            dialog.Destroy()
        if do_update:
            di =  DiscreteInput(address, None, description, label)
            self.modbus_device_config.discrete_inputs[address] = di
            self._update_di_grid(event)

    def _update_coils_grid(self, event):
        """
        Updates the coils grid with the current Modbus device configuration.

        This method clears the existing grid and populates it with the address, label,
        and description of each coil from the Modbus device configuration.

        Args:
            event: The event that triggered this update.
        """
        # pylint: disable=unused-argument
        self.m_grid_coils.ClearGrid()
        if self.m_grid_coils.GetNumberRows() > 0:
            self.m_grid_coils.DeleteRows(0, self.m_grid_coils.GetNumberRows())
        for i, (address, coil) in enumerate(self.modbus_device_config.coils.items()):
            self.m_grid_coils.AppendRows(1)
            self.m_grid_coils.SetCellValue(i, 0, str(address))
            self.m_grid_coils.SetCellValue(i, 1, coil.label)
            self.m_grid_coils.SetCellValue(i, 2, coil.description)

        self.m_grid_coils.AutoSizeColumns()
        self.m_grid_coils.AutoSizeRows()
        self.m_grid_coils.MakeCellVisible(self.m_grid_coils.GetNumberRows()-1, 0)
        self.m_grid_coils.ForceRefresh()

    def _add_coil(self, event):
        """
        Adds a coil to the modbus device configuration.

        This method retrieves the label, address, and description from the respective
        text controls. It validates the inputs and checks if the address already exists
        in the configuration. If the address exists, it prompts the user to confirm
        whether to replace the existing entry. If confirmed or if the address does not
        exist, it adds the new coil to the configuration and updates the coil grid.

        Parameters:
        event (wx.Event): The event that triggered this method.

        Returns:
        None
        """
        # pylint: disable=unused-argument
        label = self.m_textCtrl_coils_label.GetValue()
        address = self.m_textCtrl_coils_address.GetValue()
        description = self.m_textCtrl_coils_description.GetValue()
        if not label or not address or not description:
            wx.LogError("Please fill in all fields.")
            return
        if not address.isdigit():
            wx.LogError("Address must be an integer.")
            return
        address = int(address)
        do_update: bool = True
        if address in self.modbus_device_config.coils:
            dialog = wx.MessageDialog(
                self,
                "Address already exists. Do you want to replace it?",
                "Confirm Replace",
                wx.YES_NO | wx.NO_DEFAULT | wx.ICON_QUESTION
            )
            if dialog.ShowModal() == wx.ID_NO:
                do_update = False
            dialog.Destroy()
        if do_update:
            coil =  Coil(address, None, description, label)
            self.modbus_device_config.coils[address] = coil
            self._update_coils_grid(event)

    def _clear_holding_registers_fields(self, event):
        """
        Clears the fields related to holding registers in the UI.

        This method is triggered by an event and it performs the following actions:
        - Clears the text in the holding register label field.
        - Sets the holding register address field to an empty string.
        - Sets the holding register description field to an empty string.

        Args:
            event: The event that triggers this method.
        """
        # pylint: disable=unused-argument
        self.m_textCtrl_holding_register_label.Clear()
        self.m_textCtrl_holding_register_address.SetValue("")
        self.m_textCtrl_holding_register_description.SetValue("")

    def _clear_input_registers_fields( self, event ):
        """
        Clears the input fields related to input registers.

        This method is triggered by an event and clears the text fields for
        input register label, address, and description.

        Args:
            event: The event that triggers this method.
        """
        # pylint: disable=unused-argument
        self.m_textCtrl_input_register_label.Clear()
        self.m_textCtrl_input_register_address.SetValue("")
        self.m_textCtrl_input_register_description.SetValue("")

    def _clear_di_fields( self, event ):
        """
        Clears the text fields in the Digital Input (DI) section of the UI.

        This method is triggered by an event and clears the following fields:
        - DI Label
        - DI Address
        - DI Description

        Args:
            event: The event that triggers this method.
        """
        # pylint: disable=unused-argument
        self.m_textCtrl_di_label.Clear()
        self.m_textCtrl_di_address.SetValue("")
        self.m_textCtrl_di_description.SetValue("")

    def _clear_coils_fields( self, event ):
        """
        Clears the input fields related to coils.

        This method is triggered by an event and clears the text fields for
        coils label, coils address, and coils description.

        Args:
            event: The event that triggers this method.
        """
        # pylint: disable=unused-argument
        self.m_textCtrl_coils_label.Clear()
        self.m_textCtrl_coils_address.SetValue("")
        self.m_textCtrl_coils_description.SetValue("")

    def _update_connection_tree(self, event):
        """
        Updates the connection tree with the current serial and TCP
        port configurations.

        This method clears the existing tree and populates
        it with the serial and TCP port configurations.

        Args:
            event: The event that triggered this update.
        """
        # pylint: disable=unused-argument
        self.m_treeCtrl_connection.DeleteAllItems()
        root = self.m_treeCtrl_connection.AddRoot("Connections")
        serial_ports = self.m_treeCtrl_connection.AppendItem(root, "Serial Ports")
        for port in self.serial_config_list:
            # pylint: disable=consider-using-f-string
            display_str = "{}: {}, {}, {}".format(
                port.port,
                port.baudrate,
                port.parity,
                port.stop_bits
            )
            spi = self.m_treeCtrl_connection.AppendItem(serial_ports,display_str)
            self.m_treeCtrl_connection.SetItemData(spi, port)
        tcp_ports = self.m_treeCtrl_connection.AppendItem(root, "TCP Ports")
        for port in self.tcp_config_list:
            tcppi = self.m_treeCtrl_connection.AppendItem(tcp_ports, port.port_name)
            self.m_treeCtrl_connection.SetItemData(tcppi, port)

        self.m_treeCtrl_connection.ExpandAll()

    def _refresh_all_grid_boxes(self, event=None):
        """
        Refreshes all grid boxes in the dialog.

        This method is triggered by an event and refreshes all grid boxes in the dialog.

        Args:
            event: The event that triggers this method.
        """
        # pylint: disable=unused-argument
        self._update_holdings_registers_grid(event)
        self._update_input_registers_grid(event)
        self._update_di_grid(event)
        self._update_coils_grid(event)
        self._update_connection_tree(event)
        dev_name:str = ""
        dev_addr:int = 0
        if self.modbus_device_config.device_name is not None:
            dev_name = self.modbus_device_config.device_name
        self.m_textCtrl_device_name.SetValue(dev_name)
        if self.modbus_device_config.device_address is not None:
            dev_addr = self.modbus_device_config.device_address
        self.m_textCtrl_device_address.SetValue(str(dev_addr))
        interface_desc = ""
        interface_desc += f"Device Type: {self.modbus_device_config.interface_type}, "
        if self.modbus_device_config.interface_type in (ModbusDeviceConfig.INTERFACE_TYPE_RTU,\
            ModbusDeviceConfig.INTERFACE_TYPE_ASCII):
            interface_desc += f"port: {self.modbus_device_config.interface_config['port']}, "
            interface_desc += f"baudrate: {self.modbus_device_config.interface_config['baudrate']}, "
            interface_desc += f"parity: {self.modbus_device_config.interface_config['parity']}, "
            interface_desc += f"stopbits: {self.modbus_device_config.interface_config['stopbits']}, "
            interface_desc += f"bytesize: {self.modbus_device_config.interface_config['bytesize']}, "
            interface_desc += f"timeout: {self.modbus_device_config.interface_config['timeout']}"
        elif self.modbus_device_config.interface_type in (ModbusDeviceConfig.INTERFACE_TYPE_TCP,):
            interface_desc += f"host: {self.modbus_device_config.interface_config['host']}, "
            interface_desc += f"port: {self.modbus_device_config.interface_config['port']}, "
            interface_desc += f"timeout: {self.modbus_device_config.interface_config['timeout']}, "
        else:
            interface_desc += "No interface configured"

        self.m_textCtrl15.SetValue(interface_desc)

    def _user_finished(self, event):
        """
        Handles the event when the user finishes inputting device information.
        This method retrieves the device name and address from the respective text controls,
        validates the inputs, and updates the modbus device configuration if the inputs are valid.
        If any input is invalid, an error message is logged and the method returns early.

        Parameters:
            event (wx.Event): The event object associated with the user action.
        Returns:
            None
        """
        # pylint: disable=unused-argument
        self.modbus_device_config = self.modbus_device_config
        device_name = self.m_textCtrl_device_name.GetValue()
        device_address = self.m_textCtrl_device_address.GetValue()
        if not device_name or not device_address:
            wx.LogError("Please fill in all fields.")
            return
        if not device_address.isdigit():
            wx.LogError("Address must be an integer.")
            return
        self.modbus_device_config.device_name = device_name
        self.modbus_device_config.device_address = int(device_address)
        self.Close()

    def _evt_on_delete_holding_register(self, event):
        """
        Deletes the selected holding register from the Modbus device configuration.

        This method retrieves the selected row from the holding registers grid,
        confirms the deletion with the user, and removes the corresponding holding
        register from the configuration. It then updates the grid to reflect the changes.

        Args:
            event: The event that triggered this method.
        """
        # pylint: disable=unused-argument
        selected_row = self.m_grid_holding_registers.GetGridCursorRow()
        if selected_row == wx.NOT_FOUND:
            wx.LogError("No row selected.")
            return

        address = self.m_grid_holding_registers.GetCellValue(selected_row, 0)
        dialog = wx.MessageDialog(
            self,
            f"Are you sure you want to delete the holding register at address {address}?",
            "Confirm Delete",
            wx.YES_NO | wx.NO_DEFAULT | wx.ICON_QUESTION
        )
        if dialog.ShowModal() == wx.ID_YES:
            if address in self.modbus_device_config.holding_registers:
                del self.modbus_device_config.holding_registers[address]
            else:
                wx.LogError(f"Holding register at address {address} does not exist.")
            self._update_holdings_registers_grid(event)
        dialog.Destroy()

    def _on_evt_modify_holding_register(self, event):
        """
        Modifies the selected holding register in the Modbus device configuration.

        This method retrieves the selected row from the holding registers grid,
        populates the input fields with the current values of the selected holding register,
        and allows the user to modify the values. After modification, it updates the
        holding register in the configuration and refreshes the grid.

        Args:
            event: The event that triggered this method.
        """
        # pylint: disable=unused-argument
        selected_row = self.m_grid_holding_registers.GetGridCursorRow()
        if selected_row == wx.NOT_FOUND:
            wx.LogError("No row selected.")
            return

        address = int(self.m_grid_holding_registers.GetCellValue(selected_row, 0))
        if address not in self.modbus_device_config.holding_registers:
            wx.LogError(f"Holding register at address {address} does not exist.")
            return

        register = self.modbus_device_config.holding_registers[address]
        self.m_textCtrl_holding_register_label.SetValue(register.label)
        self.m_textCtrl_holding_register_address.SetValue(str(register.address))
        self.m_textCtrl_holding_register_description.SetValue(register.description)
        data_type = register.dataType
        if data_type == REGISTER_DATATYPE_U16:
            self.m_choice_holding_register_data_type.SetStringSelection('unsigned 16bit')
        elif data_type == REGISTER_DATATYPE_I16:
            self.m_choice_holding_register_data_type.SetStringSelection('signed 16bit')
        elif data_type == REGISTER_DATATYPE_U32:
            self.m_choice_holding_register_data_type.SetStringSelection('unsigned 32bit')
        elif data_type == REGISTER_DATATYPE_I32:
            self.m_choice_holding_register_data_type.SetStringSelection('signed 32bit')
        elif data_type == REGISTER_DATATYPE_F32:
            self.m_choice_holding_register_data_type.SetStringSelection('float 32bit')
        else:
            self.m_choice_holding_register_data_type.SetStringSelection('unsigned 16bit')

    def _on_evt_delete_input_registers(self, event):
        """
        Deletes the selected input register from the Modbus device configuration.

        This method retrieves the selected row from the input registers grid,
        confirms the deletion with the user, and removes the corresponding input
        register from the configuration. It then updates the grid to reflect the changes.

        Args:
            event: The event that triggered this method.
        """
        # pylint: disable=unused-argument
        selected_row = self.m_grid_input_registers.GetGridCursorRow()
        if selected_row == wx.NOT_FOUND:
            wx.LogError("No row selected.")
            return

        address = self.m_grid_input_registers.GetCellValue(selected_row, 0)
        dialog = wx.MessageDialog(
            self,
            f"Are you sure you want to delete the input register at address {address}?",
            "Confirm Delete",
            wx.YES_NO | wx.NO_DEFAULT | wx.ICON_QUESTION
        )
        if dialog.ShowModal() == wx.ID_YES:
            if address in self.modbus_device_config.input_registers:
                del self.modbus_device_config.input_registers[address]
            else:
                wx.LogError(f"Input register at address {address} does not exist.")
            self._update_input_registers_grid(event)
        dialog.Destroy()

    def _on_evt_modify_input_registers(self, event):
        """
        Modifies the selected input register in the Modbus device configuration.

        This method retrieves the selected row from the input registers grid,
        populates the input fields with the current values of the selected input register,
        and allows the user to modify the values. After modification, it updates the
        input register in the configuration and refreshes the grid.

        Args:
            event: The event that triggered this method.
        """
        # pylint: disable=unused-argument
        selected_row = self.m_grid_input_registers.GetGridCursorRow()
        if selected_row == wx.NOT_FOUND:
            wx.LogError("No row selected.")
            return

        address = self.m_grid_input_registers.GetCellValue(selected_row, 0)
        if address not in self.modbus_device_config.input_registers:
            wx.LogError(f"Input register at address {address} does not exist.")
            return

        register = self.modbus_device_config.input_registers[address]
        self.m_textCtrl_input_register_label.SetValue(register.label)
        self.m_textCtrl_input_register_address.SetValue(str(register.address))
        self.m_textCtrl_input_register_description.SetValue(register.description)
        data_type = register.dataType
        if data_type == REGISTER_DATATYPE_U16:
            self.m_choice_input_register_data_type.SetStringSelection('unsigned 16bit')
        elif data_type == REGISTER_DATATYPE_I16:
            self.m_choice_input_register_data_type.SetStringSelection('signed 16bit')
        elif data_type == REGISTER_DATATYPE_U32:
            self.m_choice_input_register_data_type.SetStringSelection('unsigned 32bit')
        elif data_type == REGISTER_DATATYPE_I32:
            self.m_choice_input_register_data_type.SetStringSelection('signed 32bit')
        elif data_type == REGISTER_DATATYPE_F32:
            self.m_choice_input_register_data_type.SetStringSelection('float 32bit')
        else:
            self.m_choice_input_register_data_type.SetStringSelection('unsigned 16bit')

    def _on_evt_delete_di(self, event):
        """
        Deletes the selected discrete input (DI) from the Modbus device configuration.

        This method retrieves the selected row from the discrete inputs grid,
        confirms the deletion with the user, and removes the corresponding DI
        from the configuration. It then updates the grid to reflect the changes.

        Args:
            event: The event that triggered this method.
        """
        # pylint: disable=unused-argument
        selected_row = self.m_grid_di.GetGridCursorRow()
        if selected_row == wx.NOT_FOUND:
            wx.LogError("No row selected.")
            return

        address = self.m_grid_di.GetCellValue(selected_row, 0)
        dialog = wx.MessageDialog(
            self,
            f"Are you sure you want to delete the discrete input at address {address}?",
            "Confirm Delete",
            wx.YES_NO | wx.NO_DEFAULT | wx.ICON_QUESTION
        )
        if dialog.ShowModal() == wx.ID_YES:
            if address in self.modbus_device_config.discrete_inputs:
                del self.modbus_device_config.discrete_inputs[address]
            else:
                wx.LogError(f"Discrete input at address {address} does not exist.")
            self._update_di_grid(event)
        dialog.Destroy()

    def _on_evt_modify_di(self, event):
        """
        Modifies the selected discrete input (DI) in the Modbus device configuration.

        This method retrieves the selected row from the discrete inputs grid,
        populates the input fields with the current values of the selected DI,
        and allows the user to modify the values. After modification, it updates the
        DI in the configuration and refreshes the grid.

        Args:
            event: The event that triggered this method.
        """
        # pylint: disable=unused-argument
        selected_row = self.m_grid_di.GetGridCursorRow()
        if selected_row == wx.NOT_FOUND:
            wx.LogError("No row selected.")
            return

        address = self.m_grid_di.GetCellValue(selected_row, 0)
        if address not in self.modbus_device_config.discrete_inputs:
            wx.LogError(f"Discrete input at address {address} does not exist.")
            return

        di = self.modbus_device_config.discrete_inputs[address]
        self.m_textCtrl_di_label.SetValue(di.label)
        self.m_textCtrl_di_address.SetValue(str(di.address))
        self.m_textCtrl_di_description.SetValue(di.description)

    def _on_evt_delete_coil(self, event):
        """
        Deletes the selected coil from the Modbus device configuration.

        This method retrieves the selected row from the coils grid,
        confirms the deletion with the user, and removes the corresponding coil
        from the configuration. It then updates the grid to reflect the changes.

        Args:
            event: The event that triggered this method.
        """
        # pylint: disable=unused-argument
        selected_row = self.m_grid_coils.GetGridCursorRow()
        if selected_row == wx.NOT_FOUND:
            wx.LogError("No row selected.")
            return

        address = self.m_grid_coils.GetCellValue(selected_row, 0)
        dialog = wx.MessageDialog(
            self,
            f"Are you sure you want to delete the coil at address {address}?",
            "Confirm Delete",
            wx.YES_NO | wx.NO_DEFAULT | wx.ICON_QUESTION
        )
        if dialog.ShowModal() == wx.ID_YES:
            if address in self.modbus_device_config.coils:
                del self.modbus_device_config.coils[address]
            else:
                wx.LogError(f"Coil at address {address} does not exist.")
            self._update_coils_grid(event)
        dialog.Destroy()

    def _on_evt_modify_coil(self, event):
        """
        Modifies the selected coil in the Modbus device configuration.

        This method retrieves the selected row from the coils grid,
        populates the input fields with the current values of the selected coil,
        and allows the user to modify the values. After modification, it updates the
        coil in the configuration and refreshes the grid.

        Args:
            event: The event that triggered this method.
        """
        # pylint: disable=unused-argument
        selected_row = self.m_grid_coils.GetGridCursorRow()
        if selected_row == wx.NOT_FOUND:
            wx.LogError("No row selected.")
            return

        address = int(self.m_grid_coils.GetCellValue(selected_row, 0))
        if address not in self.modbus_device_config.coils:
            wx.LogError(f"Coil at address {address} does not exist.")
            return

        coil = self.modbus_device_config.coils[address]
        self.m_textCtrl_coils_label.SetValue(coil.label)
        self.m_textCtrl_coils_address.SetValue(str(coil.address))
        self.m_textCtrl_coils_description.SetValue(coil.description)

    def _evt_on_selecting_iterface(self, event):
        # pylint: disable=unused-argument
        #get the details from the connection
        item = self.m_treeCtrl_connection.GetSelection()
        if item:
            item_data = self.m_treeCtrl_connection.GetItemData(item)
            if isinstance(item_data, appSerialPortInfo):
                # selected is a serial port.
                # ask if device type is rtu or ascii
                sp:appSerialPortInfo = item_data
                dlg = SerialDeviceTypeSelectorDialog(self)
                dlg.ShowModal()
                self.modbus_device_config.configure_serial_interface(
                    sp.uid,
                    sp.port,
                    sp.baudrate,
                    sp.parity,
                    sp.stop_bits,
                    8,
                    sp.timeout
                )
                self.modbus_device_config.interface_type = dlg.type
            elif isinstance(item_data, appTcpPortInfo):
                tp:appTcpPortInfo = item_data
                self.modbus_device_config.configure_tcp_interface(
                    tp.ip_address,
                    tp.port_number,
                    tp.timeout
                )
            self._refresh_all_grid_boxes()
