# -*- coding: utf-8 -*-

###########################################################################
## Python code generated with wxFormBuilder (version 3.10.1-0-g8feb16b3)
## http://www.wxformbuilder.org/
##
## PLEASE DO *NOT* EDIT THIS FILE!
###########################################################################

import wx
import wx.xrc
import wx.grid

###########################################################################
## Class monitorGroupDialog
###########################################################################

class monitorGroupDialog ( wx.Dialog ):

	def __init__( self, parent ):
		wx.Dialog.__init__ ( self, parent, id = wx.ID_ANY, title = u"Configure Monitor Group", pos = wx.DefaultPosition, size = wx.Size( 844,526 ), style = wx.DEFAULT_DIALOG_STYLE|wx.MAXIMIZE_BOX|wx.MINIMIZE_BOX )

		self.SetSizeHints( wx.DefaultSize, wx.DefaultSize )

		bSizer8 = wx.BoxSizer( wx.VERTICAL )

		gSizer1 = wx.GridSizer( 2, 2, 0, 0 )

		self.m_name = wx.StaticText( self, wx.ID_ANY, u"Name", wx.DefaultPosition, wx.DefaultSize, 0|wx.FULL_REPAINT_ON_RESIZE )
		self.m_name.Wrap( -1 )

		gSizer1.Add( self.m_name, 0, wx.ALL, 5 )

		self.m_textCtrl15 = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0|wx.FULL_REPAINT_ON_RESIZE )
		gSizer1.Add( self.m_textCtrl15, 0, wx.ALL, 5 )

		self.m_staticText20 = wx.StaticText( self, wx.ID_ANY, u"Poll Time (ms)", wx.DefaultPosition, wx.DefaultSize, 0|wx.FULL_REPAINT_ON_RESIZE )
		self.m_staticText20.Wrap( -1 )

		gSizer1.Add( self.m_staticText20, 0, wx.ALL, 5 )

		self.m_textCtrl16 = wx.TextCtrl( self, wx.ID_ANY, u"1000", wx.DefaultPosition, wx.DefaultSize, 0|wx.FULL_REPAINT_ON_RESIZE )
		gSizer1.Add( self.m_textCtrl16, 0, wx.ALL, 5 )


		bSizer8.Add( gSizer1, 0, 0, 5 )

		bSizer14 = wx.BoxSizer( wx.HORIZONTAL )

		self.m_treeCtrl_monitor_group = wx.TreeCtrl( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TR_DEFAULT_STYLE|wx.FULL_REPAINT_ON_RESIZE )
		self.m_treeCtrl_monitor_group.SetMinSize( wx.Size( 300,-1 ) )
		self.m_treeCtrl_monitor_group.SetMaxSize( wx.Size( 300,-1 ) )

		bSizer14.Add( self.m_treeCtrl_monitor_group, 1, wx.ALL|wx.EXPAND, 5 )

		bSizer15 = wx.BoxSizer( wx.VERTICAL )

		fgSizer7 = wx.FlexGridSizer( 2, 2, 0, 0 )
		fgSizer7.SetFlexibleDirection( wx.BOTH )
		fgSizer7.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )

		self.m_staticText25 = wx.StaticText( self, wx.ID_ANY, u"Register Info", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText25.Wrap( -1 )

		fgSizer7.Add( self.m_staticText25, 0, wx.ALL, 5 )

		self.m_staticText26 = wx.StaticText( self, wx.ID_ANY, u"Parameter Info", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText26.Wrap( -1 )

		fgSizer7.Add( self.m_staticText26, 0, wx.ALL, 5 )

		fgSizer8 = wx.FlexGridSizer( 4, 2, 0, 0 )
		fgSizer8.SetFlexibleDirection( wx.BOTH )
		fgSizer8.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )

		self.m_staticText27 = wx.StaticText( self, wx.ID_ANY, u"Address", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText27.Wrap( -1 )

		fgSizer8.Add( self.m_staticText27, 0, wx.ALL, 5 )

		self.m_textCtrl20 = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, wx.TE_READONLY )
		fgSizer8.Add( self.m_textCtrl20, 0, wx.ALL, 5 )

		self.m_staticText28 = wx.StaticText( self, wx.ID_ANY, u"Label", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText28.Wrap( -1 )

		fgSizer8.Add( self.m_staticText28, 0, wx.ALL, 5 )

		self.m_textCtrl21 = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, wx.TE_READONLY )
		fgSizer8.Add( self.m_textCtrl21, 0, wx.ALL, 5 )

		self.m_staticText29 = wx.StaticText( self, wx.ID_ANY, u"Datatype", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText29.Wrap( -1 )

		fgSizer8.Add( self.m_staticText29, 0, wx.ALL, 5 )

		self.m_textCtrl22 = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, wx.TE_READONLY )
		fgSizer8.Add( self.m_textCtrl22, 0, wx.ALL, 5 )

		self.m_staticText30 = wx.StaticText( self, wx.ID_ANY, u"description", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText30.Wrap( -1 )

		fgSizer8.Add( self.m_staticText30, 0, wx.ALL, 5 )

		self.m_textCtrl23 = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, wx.TE_READONLY )
		fgSizer8.Add( self.m_textCtrl23, 0, wx.ALL, 5 )


		fgSizer7.Add( fgSizer8, 1, wx.EXPAND, 5 )

		fgSizer6 = wx.FlexGridSizer( 3, 2, 0, 0 )
		fgSizer6.SetFlexibleDirection( wx.BOTH )
		fgSizer6.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )

		self.m_staticText21 = wx.StaticText( self, wx.ID_ANY, u"Name", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText21.Wrap( -1 )

		fgSizer6.Add( self.m_staticText21, 0, wx.ALL, 5 )

		self.m_textCtrl17 = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer6.Add( self.m_textCtrl17, 0, wx.ALL, 5 )

		self.m_staticText22 = wx.StaticText( self, wx.ID_ANY, u"Unit", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText22.Wrap( -1 )

		fgSizer6.Add( self.m_staticText22, 0, wx.ALL, 5 )

		self.m_textCtrl18 = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer6.Add( self.m_textCtrl18, 0, wx.ALL, 5 )

		self.m_staticText23 = wx.StaticText( self, wx.ID_ANY, u"History Bufer Len", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText23.Wrap( -1 )

		fgSizer6.Add( self.m_staticText23, 0, wx.ALL, 5 )

		self.m_textCtrl19 = wx.TextCtrl( self, wx.ID_ANY, u"1", wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer6.Add( self.m_textCtrl19, 0, wx.ALL, 5 )


		fgSizer7.Add( fgSizer6, 0, wx.EXPAND, 5 )


		bSizer15.Add( fgSizer7, 1, wx.EXPAND, 5 )

		self.m_staticline1 = wx.StaticLine( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.LI_HORIZONTAL )
		bSizer15.Add( self.m_staticline1, 0, wx.EXPAND |wx.ALL, 5 )

		self.m_staticText24 = wx.StaticText( self, wx.ID_ANY, u"Selected Parameters For This Group:", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText24.Wrap( -1 )

		bSizer15.Add( self.m_staticText24, 0, wx.ALL, 5 )

		self.m_grid_monitor_group = wx.grid.Grid( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, 0 )

		# Grid
		self.m_grid_monitor_group.CreateGrid( 0, 8 )
		self.m_grid_monitor_group.EnableEditing( True )
		self.m_grid_monitor_group.EnableGridLines( True )
		self.m_grid_monitor_group.EnableDragGridSize( False )
		self.m_grid_monitor_group.SetMargins( 0, 0 )

		# Columns
		self.m_grid_monitor_group.SetColSize( 0, 100 )
		self.m_grid_monitor_group.SetColSize( 1, 100 )
		self.m_grid_monitor_group.SetColSize( 2, 100 )
		self.m_grid_monitor_group.SetColSize( 3, 100 )
		self.m_grid_monitor_group.SetColSize( 4, 100 )
		self.m_grid_monitor_group.SetColSize( 5, 100 )
		self.m_grid_monitor_group.SetColSize( 6, 100 )
		self.m_grid_monitor_group.EnableDragColMove( False )
		self.m_grid_monitor_group.EnableDragColSize( True )
		self.m_grid_monitor_group.SetColLabelValue( 0, u"Device Address" )
		self.m_grid_monitor_group.SetColLabelValue( 1, u"Reg Addr" )
		self.m_grid_monitor_group.SetColLabelValue( 2, u"Reg Label" )
		self.m_grid_monitor_group.SetColLabelValue( 3, u"Reg Datatype" )
		self.m_grid_monitor_group.SetColLabelValue( 4, u"Reg Desc" )
		self.m_grid_monitor_group.SetColLabelValue( 5, u"Param Name" )
		self.m_grid_monitor_group.SetColLabelValue( 6, u"Param Unit" )
		self.m_grid_monitor_group.SetColLabelValue( 7, u"Buff Len" )
		self.m_grid_monitor_group.SetColLabelValue( 8, wx.EmptyString )
		self.m_grid_monitor_group.SetColLabelAlignment( wx.ALIGN_CENTER, wx.ALIGN_CENTER )

		# Rows
		self.m_grid_monitor_group.EnableDragRowSize( True )
		self.m_grid_monitor_group.SetRowLabelAlignment( wx.ALIGN_CENTER, wx.ALIGN_CENTER )

		# Label Appearance

		# Cell Defaults
		self.m_grid_monitor_group.SetDefaultCellAlignment( wx.ALIGN_LEFT, wx.ALIGN_TOP )
		bSizer15.Add( self.m_grid_monitor_group, 1, wx.ALL|wx.EXPAND, 5 )


		bSizer14.Add( bSizer15, 1, wx.EXPAND, 5 )


		bSizer8.Add( bSizer14, 1, wx.EXPAND, 5 )

		bSizer10 = wx.BoxSizer( wx.HORIZONTAL )

		self.m_button_ok = wx.Button( self, wx.ID_ANY, u"Ok", wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer10.Add( self.m_button_ok, 0, wx.ALL, 5 )

		self.m_button_cancel = wx.Button( self, wx.ID_ANY, u"Cancel", wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer10.Add( self.m_button_cancel, 0, wx.ALL, 5 )


		bSizer8.Add( bSizer10, 0, 0, 5 )


		self.SetSizer( bSizer8 )
		self.Layout()

		self.Centre( wx.BOTH )

		# Connect Events
		self.m_treeCtrl_monitor_group.Bind( wx.EVT_TREE_ITEM_ACTIVATED, self.evt_add_selection_to_monitor_group )
		self.m_treeCtrl_monitor_group.Bind( wx.EVT_TREE_SEL_CHANGED, self.evt_on_item_select )
		self.m_button_ok.Bind( wx.EVT_BUTTON, self.evt_ok_btn )
		self.m_button_cancel.Bind( wx.EVT_BUTTON, self.evt_cancel_btn_click )

	def __del__( self ):
		pass


	# Virtual event handlers, override them in your derived class
	def evt_add_selection_to_monitor_group( self, event ):
		event.Skip()

	def evt_on_item_select( self, event ):
		event.Skip()

	def evt_ok_btn( self, event ):
		event.Skip()

	def evt_cancel_btn_click( self, event ):
		event.Skip()


