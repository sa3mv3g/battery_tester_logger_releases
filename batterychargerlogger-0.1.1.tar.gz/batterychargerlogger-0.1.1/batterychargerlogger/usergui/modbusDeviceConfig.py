# -*- coding: utf-8 -*-

###########################################################################
## Python code generated with wxFormBuilder (version 3.10.1-0-g8feb16b3)
## http://www.wxformbuilder.org/
##
## PLEASE DO *NOT* EDIT THIS FILE!
###########################################################################

import wx
import wx.xrc
import wx.grid

###########################################################################
## Class ModbusDeviceConfigDialog
###########################################################################

class ModbusDeviceConfigDialog ( wx.Dialog ):

	def __init__( self, parent ):
		wx.Dialog.__init__ ( self, parent, id = wx.ID_ANY, title = u"Modbus Device Configuration", pos = wx.DefaultPosition, size = wx.Size( 711,552 ), style = wx.CLOSE_BOX|wx.DEFAULT_DIALOG_STYLE|wx.MAXIMIZE_BOX|wx.MINIMIZE_BOX|wx.RESIZE_BORDER )

		self.SetSizeHints( wx.DefaultSize, wx.DefaultSize )

		bSizer3 = wx.BoxSizer( wx.VERTICAL )

		fgSizer2 = wx.FlexGridSizer( 2, 2, 0, 0 )
		fgSizer2.SetFlexibleDirection( wx.BOTH )
		fgSizer2.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )

		self.m_staticText29 = wx.StaticText( self, wx.ID_ANY, u"Device Name", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText29.Wrap( -1 )

		fgSizer2.Add( self.m_staticText29, 0, wx.ALL, 5 )

		self.m_textCtrl_device_name = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer2.Add( self.m_textCtrl_device_name, 0, wx.ALL, 5 )

		self.m_staticText5 = wx.StaticText( self, wx.ID_ANY, u"Device Address", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText5.Wrap( -1 )

		fgSizer2.Add( self.m_staticText5, 0, wx.ALL, 5 )

		self.m_textCtrl_device_address = wx.TextCtrl( self, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer2.Add( self.m_textCtrl_device_address, 0, wx.ALL, 5 )


		bSizer3.Add( fgSizer2, 0, 0, 5 )

		self.m_notebook1 = wx.Notebook( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_panel5 = wx.Panel( self.m_notebook1, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		bSizer7 = wx.BoxSizer( wx.VERTICAL )

		self.m_staticText17 = wx.StaticText( self.m_panel5, wx.ID_ANY, u"Selected Interface Configurations:", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText17.Wrap( -1 )

		bSizer7.Add( self.m_staticText17, 0, wx.ALL, 5 )

		self.m_textCtrl15 = wx.TextCtrl( self.m_panel5, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_textCtrl15.Enable( False )

		bSizer7.Add( self.m_textCtrl15, 0, wx.ALL|wx.EXPAND, 5 )

		self.m_staticText18 = wx.StaticText( self.m_panel5, wx.ID_ANY, u"Available Interface Configurations:", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText18.Wrap( -1 )

		bSizer7.Add( self.m_staticText18, 0, wx.ALL, 5 )

		self.m_treeCtrl_connection = wx.TreeCtrl( self.m_panel5, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TR_DEFAULT_STYLE )
		bSizer7.Add( self.m_treeCtrl_connection, 1, wx.ALL|wx.EXPAND, 5 )


		self.m_panel5.SetSizer( bSizer7 )
		self.m_panel5.Layout()
		bSizer7.Fit( self.m_panel5 )
		self.m_notebook1.AddPage( self.m_panel5, u"Connection", True )
		self.m_panel3 = wx.Panel( self.m_notebook1, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		bSizer4 = wx.BoxSizer( wx.VERTICAL )

		fgSizer1 = wx.FlexGridSizer( 3, 4, 0, 0 )
		fgSizer1.SetFlexibleDirection( wx.BOTH )
		fgSizer1.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )

		self.m_staticText1 = wx.StaticText( self.m_panel3, wx.ID_ANY, u"Label", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText1.Wrap( -1 )

		fgSizer1.Add( self.m_staticText1, 0, wx.ALL, 5 )

		self.m_textCtrl_holding_register_label = wx.TextCtrl( self.m_panel3, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer1.Add( self.m_textCtrl_holding_register_label, 0, wx.ALL, 5 )

		self.m_staticText2 = wx.StaticText( self.m_panel3, wx.ID_ANY, u"Address", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText2.Wrap( -1 )

		fgSizer1.Add( self.m_staticText2, 0, wx.ALL, 5 )

		self.m_textCtrl_holding_register_address = wx.TextCtrl( self.m_panel3, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer1.Add( self.m_textCtrl_holding_register_address, 0, wx.ALL, 5 )

		self.m_staticText3 = wx.StaticText( self.m_panel3, wx.ID_ANY, u"Description", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText3.Wrap( -1 )

		fgSizer1.Add( self.m_staticText3, 0, wx.ALL, 5 )

		self.m_textCtrl_holding_register_description = wx.TextCtrl( self.m_panel3, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer1.Add( self.m_textCtrl_holding_register_description, 0, wx.ALL, 5 )

		self.m_staticText4 = wx.StaticText( self.m_panel3, wx.ID_ANY, u"Data Type", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText4.Wrap( -1 )

		fgSizer1.Add( self.m_staticText4, 0, wx.ALL, 5 )

		m_choice_holding_register_data_typeChoices = [ u"unsigned 16bit", u"signed 16bit", u"unsigned 32bit", u"signed 32bit", u"float 32bit" ]
		self.m_choice_holding_register_data_type = wx.Choice( self.m_panel3, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, m_choice_holding_register_data_typeChoices, 0 )
		self.m_choice_holding_register_data_type.SetSelection( 0 )
		fgSizer1.Add( self.m_choice_holding_register_data_type, 0, wx.ALL, 5 )

		self.m_button1 = wx.Button( self.m_panel3, wx.ID_ANY, u"Clear Above", wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer1.Add( self.m_button1, 0, wx.ALL, 5 )

		self.m_button2 = wx.Button( self.m_panel3, wx.ID_ANY, u"Add", wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer1.Add( self.m_button2, 0, wx.ALL, 5 )


		bSizer4.Add( fgSizer1, 0, wx.EXPAND, 5 )

		self.m_grid_holding_registers = wx.grid.Grid( self.m_panel3, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.FULL_REPAINT_ON_RESIZE|wx.HSCROLL|wx.VSCROLL )

		# Grid
		self.m_grid_holding_registers.CreateGrid( 1, 4 )
		self.m_grid_holding_registers.EnableEditing( False )
		self.m_grid_holding_registers.EnableGridLines( True )
		self.m_grid_holding_registers.EnableDragGridSize( False )
		self.m_grid_holding_registers.SetMargins( 0, 0 )

		# Columns
		self.m_grid_holding_registers.EnableDragColMove( True )
		self.m_grid_holding_registers.EnableDragColSize( True )
		self.m_grid_holding_registers.SetColLabelValue( 0, u"Address" )
		self.m_grid_holding_registers.SetColLabelValue( 1, u"Label" )
		self.m_grid_holding_registers.SetColLabelValue( 2, u"Desc" )
		self.m_grid_holding_registers.SetColLabelValue( 3, u"Data Type" )
		self.m_grid_holding_registers.SetColLabelAlignment( wx.ALIGN_CENTER, wx.ALIGN_CENTER )

		# Rows
		self.m_grid_holding_registers.EnableDragRowSize( True )
		self.m_grid_holding_registers.SetRowLabelAlignment( wx.ALIGN_CENTER, wx.ALIGN_CENTER )

		# Label Appearance

		# Cell Defaults
		self.m_grid_holding_registers.SetDefaultCellAlignment( wx.ALIGN_LEFT, wx.ALIGN_TOP )
		bSizer4.Add( self.m_grid_holding_registers, 1, wx.ALL|wx.EXPAND, 5 )

		bSizer8 = wx.BoxSizer( wx.HORIZONTAL )

		self.m_button112 = wx.Button( self.m_panel3, wx.ID_ANY, u"Delete", wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer8.Add( self.m_button112, 0, wx.ALL, 5 )

		self.m_button12 = wx.Button( self.m_panel3, wx.ID_ANY, u"Modify", wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer8.Add( self.m_button12, 0, wx.ALL, 5 )


		bSizer4.Add( bSizer8, 0, wx.EXPAND, 5 )


		self.m_panel3.SetSizer( bSizer4 )
		self.m_panel3.Layout()
		bSizer4.Fit( self.m_panel3 )
		self.m_notebook1.AddPage( self.m_panel3, u"Holding Registers", False )
		self.m_panel4 = wx.Panel( self.m_notebook1, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		bSizer41 = wx.BoxSizer( wx.VERTICAL )

		fgSizer11 = wx.FlexGridSizer( 3, 4, 0, 0 )
		fgSizer11.SetFlexibleDirection( wx.BOTH )
		fgSizer11.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )

		self.m_staticText11 = wx.StaticText( self.m_panel4, wx.ID_ANY, u"Label", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText11.Wrap( -1 )

		fgSizer11.Add( self.m_staticText11, 0, wx.ALL, 5 )

		self.m_textCtrl_input_register_label = wx.TextCtrl( self.m_panel4, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer11.Add( self.m_textCtrl_input_register_label, 0, wx.ALL, 5 )

		self.m_staticText21 = wx.StaticText( self.m_panel4, wx.ID_ANY, u"Address", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText21.Wrap( -1 )

		fgSizer11.Add( self.m_staticText21, 0, wx.ALL, 5 )

		self.m_textCtrl_input_register_address = wx.TextCtrl( self.m_panel4, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer11.Add( self.m_textCtrl_input_register_address, 0, wx.ALL, 5 )

		self.m_staticText31 = wx.StaticText( self.m_panel4, wx.ID_ANY, u"Description", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText31.Wrap( -1 )

		fgSizer11.Add( self.m_staticText31, 0, wx.ALL, 5 )

		self.m_textCtrl_input_register_description = wx.TextCtrl( self.m_panel4, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer11.Add( self.m_textCtrl_input_register_description, 0, wx.ALL, 5 )

		self.m_staticText41 = wx.StaticText( self.m_panel4, wx.ID_ANY, u"Data Type", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText41.Wrap( -1 )

		fgSizer11.Add( self.m_staticText41, 0, wx.ALL, 5 )

		m_choice_input_register_data_typeChoices = [ u"unsigned 16bit", u"signed 16bit", u"unsigned 32bit", u"signed 32bit", u"float 32bit" ]
		self.m_choice_input_register_data_type = wx.Choice( self.m_panel4, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, m_choice_input_register_data_typeChoices, 0 )
		self.m_choice_input_register_data_type.SetSelection( 0 )
		fgSizer11.Add( self.m_choice_input_register_data_type, 0, wx.ALL, 5 )

		self.m_button11 = wx.Button( self.m_panel4, wx.ID_ANY, u"Clear Above", wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer11.Add( self.m_button11, 0, wx.ALL, 5 )

		self.m_button21 = wx.Button( self.m_panel4, wx.ID_ANY, u"Add", wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer11.Add( self.m_button21, 0, wx.ALL, 5 )


		bSizer41.Add( fgSizer11, 0, wx.EXPAND, 5 )

		self.m_grid_input_registers = wx.grid.Grid( self.m_panel4, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.FULL_REPAINT_ON_RESIZE|wx.HSCROLL|wx.VSCROLL )

		# Grid
		self.m_grid_input_registers.CreateGrid( 1, 4 )
		self.m_grid_input_registers.EnableEditing( False )
		self.m_grid_input_registers.EnableGridLines( True )
		self.m_grid_input_registers.EnableDragGridSize( False )
		self.m_grid_input_registers.SetMargins( 0, 0 )

		# Columns
		self.m_grid_input_registers.EnableDragColMove( True )
		self.m_grid_input_registers.EnableDragColSize( True )
		self.m_grid_input_registers.SetColLabelValue( 0, u"Address" )
		self.m_grid_input_registers.SetColLabelValue( 1, u"Label" )
		self.m_grid_input_registers.SetColLabelValue( 2, u"Desc" )
		self.m_grid_input_registers.SetColLabelValue( 3, u"Data Type" )
		self.m_grid_input_registers.SetColLabelAlignment( wx.ALIGN_CENTER, wx.ALIGN_CENTER )

		# Rows
		self.m_grid_input_registers.EnableDragRowSize( True )
		self.m_grid_input_registers.SetRowLabelAlignment( wx.ALIGN_CENTER, wx.ALIGN_CENTER )

		# Label Appearance

		# Cell Defaults
		self.m_grid_input_registers.SetDefaultCellAlignment( wx.ALIGN_LEFT, wx.ALIGN_TOP )
		bSizer41.Add( self.m_grid_input_registers, 1, wx.ALL|wx.EXPAND, 5 )

		bSizer9 = wx.BoxSizer( wx.HORIZONTAL )

		self.m_button13 = wx.Button( self.m_panel4, wx.ID_ANY, u"Delete", wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer9.Add( self.m_button13, 0, wx.ALL, 5 )

		self.m_button14 = wx.Button( self.m_panel4, wx.ID_ANY, u"Modify", wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer9.Add( self.m_button14, 0, wx.ALL, 5 )


		bSizer41.Add( bSizer9, 0, wx.EXPAND, 5 )


		self.m_panel4.SetSizer( bSizer41 )
		self.m_panel4.Layout()
		bSizer41.Fit( self.m_panel4 )
		self.m_notebook1.AddPage( self.m_panel4, u"Input Registers", False )
		self.m_panel31 = wx.Panel( self.m_notebook1, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		bSizer411 = wx.BoxSizer( wx.VERTICAL )

		fgSizer111 = wx.FlexGridSizer( 3, 4, 0, 0 )
		fgSizer111.SetFlexibleDirection( wx.BOTH )
		fgSizer111.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )

		self.m_staticText111 = wx.StaticText( self.m_panel31, wx.ID_ANY, u"Label", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText111.Wrap( -1 )

		fgSizer111.Add( self.m_staticText111, 0, wx.ALL, 5 )

		self.m_textCtrl_di_label = wx.TextCtrl( self.m_panel31, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer111.Add( self.m_textCtrl_di_label, 0, wx.ALL, 5 )

		self.m_staticText211 = wx.StaticText( self.m_panel31, wx.ID_ANY, u"Address", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText211.Wrap( -1 )

		fgSizer111.Add( self.m_staticText211, 0, wx.ALL, 5 )

		self.m_textCtrl_di_address = wx.TextCtrl( self.m_panel31, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer111.Add( self.m_textCtrl_di_address, 0, wx.ALL, 5 )

		self.m_staticText311 = wx.StaticText( self.m_panel31, wx.ID_ANY, u"Description", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText311.Wrap( -1 )

		fgSizer111.Add( self.m_staticText311, 0, wx.ALL, 5 )

		self.m_textCtrl_di_description = wx.TextCtrl( self.m_panel31, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer111.Add( self.m_textCtrl_di_description, 0, wx.ALL, 5 )


		fgSizer111.Add( ( 0, 0), 1, wx.EXPAND, 5 )


		fgSizer111.Add( ( 0, 0), 1, wx.EXPAND, 5 )

		self.m_button111 = wx.Button( self.m_panel31, wx.ID_ANY, u"Clear Above", wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer111.Add( self.m_button111, 0, wx.ALL, 5 )

		self.m_button211 = wx.Button( self.m_panel31, wx.ID_ANY, u"Add", wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer111.Add( self.m_button211, 0, wx.ALL, 5 )


		bSizer411.Add( fgSizer111, 0, wx.EXPAND, 5 )

		self.m_grid_di = wx.grid.Grid( self.m_panel31, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.FULL_REPAINT_ON_RESIZE|wx.HSCROLL|wx.VSCROLL )

		# Grid
		self.m_grid_di.CreateGrid( 1, 3 )
		self.m_grid_di.EnableEditing( False )
		self.m_grid_di.EnableGridLines( True )
		self.m_grid_di.EnableDragGridSize( False )
		self.m_grid_di.SetMargins( 0, 0 )

		# Columns
		self.m_grid_di.EnableDragColMove( True )
		self.m_grid_di.EnableDragColSize( True )
		self.m_grid_di.SetColLabelValue( 0, u"Address" )
		self.m_grid_di.SetColLabelValue( 1, u"Label" )
		self.m_grid_di.SetColLabelValue( 2, u"Desc" )
		self.m_grid_di.SetColLabelAlignment( wx.ALIGN_CENTER, wx.ALIGN_CENTER )

		# Rows
		self.m_grid_di.EnableDragRowSize( True )
		self.m_grid_di.SetRowLabelAlignment( wx.ALIGN_CENTER, wx.ALIGN_CENTER )

		# Label Appearance

		# Cell Defaults
		self.m_grid_di.SetDefaultCellAlignment( wx.ALIGN_LEFT, wx.ALIGN_TOP )
		bSizer411.Add( self.m_grid_di, 1, wx.ALL|wx.EXPAND, 5 )

		bSizer10 = wx.BoxSizer( wx.HORIZONTAL )

		self.m_button151 = wx.Button( self.m_panel31, wx.ID_ANY, u"Delete", wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer10.Add( self.m_button151, 0, wx.ALL, 5 )

		self.m_button161 = wx.Button( self.m_panel31, wx.ID_ANY, u"Modify", wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer10.Add( self.m_button161, 0, wx.ALL, 5 )


		bSizer411.Add( bSizer10, 0, wx.EXPAND, 5 )


		self.m_panel31.SetSizer( bSizer411 )
		self.m_panel31.Layout()
		bSizer411.Fit( self.m_panel31 )
		self.m_notebook1.AddPage( self.m_panel31, u"Discrete Inputs", False )
		self.m_panel41 = wx.Panel( self.m_notebook1, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		bSizer4111 = wx.BoxSizer( wx.VERTICAL )

		fgSizer1111 = wx.FlexGridSizer( 3, 4, 0, 0 )
		fgSizer1111.SetFlexibleDirection( wx.BOTH )
		fgSizer1111.SetNonFlexibleGrowMode( wx.FLEX_GROWMODE_SPECIFIED )

		self.m_staticText1111 = wx.StaticText( self.m_panel41, wx.ID_ANY, u"Label", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText1111.Wrap( -1 )

		fgSizer1111.Add( self.m_staticText1111, 0, wx.ALL, 5 )

		self.m_textCtrl_coils_label = wx.TextCtrl( self.m_panel41, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer1111.Add( self.m_textCtrl_coils_label, 0, wx.ALL, 5 )

		self.m_staticText2111 = wx.StaticText( self.m_panel41, wx.ID_ANY, u"Address", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText2111.Wrap( -1 )

		fgSizer1111.Add( self.m_staticText2111, 0, wx.ALL, 5 )

		self.m_textCtrl_coils_address = wx.TextCtrl( self.m_panel41, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer1111.Add( self.m_textCtrl_coils_address, 0, wx.ALL, 5 )

		self.m_staticText3111 = wx.StaticText( self.m_panel41, wx.ID_ANY, u"Description", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText3111.Wrap( -1 )

		fgSizer1111.Add( self.m_staticText3111, 0, wx.ALL, 5 )

		self.m_textCtrl_coils_description = wx.TextCtrl( self.m_panel41, wx.ID_ANY, wx.EmptyString, wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer1111.Add( self.m_textCtrl_coils_description, 0, wx.ALL, 5 )


		fgSizer1111.Add( ( 0, 0), 1, wx.EXPAND, 5 )


		fgSizer1111.Add( ( 0, 0), 1, wx.EXPAND, 5 )

		self.m_button1111 = wx.Button( self.m_panel41, wx.ID_ANY, u"Clear Above", wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer1111.Add( self.m_button1111, 0, wx.ALL, 5 )

		self.m_button2111 = wx.Button( self.m_panel41, wx.ID_ANY, u"Add", wx.DefaultPosition, wx.DefaultSize, 0 )
		fgSizer1111.Add( self.m_button2111, 0, wx.ALL, 5 )


		bSizer4111.Add( fgSizer1111, 0, wx.EXPAND, 5 )

		self.m_grid_coils = wx.grid.Grid( self.m_panel41, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.FULL_REPAINT_ON_RESIZE|wx.HSCROLL|wx.VSCROLL )

		# Grid
		self.m_grid_coils.CreateGrid( 1, 3 )
		self.m_grid_coils.EnableEditing( False )
		self.m_grid_coils.EnableGridLines( True )
		self.m_grid_coils.EnableDragGridSize( False )
		self.m_grid_coils.SetMargins( 0, 0 )

		# Columns
		self.m_grid_coils.EnableDragColMove( True )
		self.m_grid_coils.EnableDragColSize( True )
		self.m_grid_coils.SetColLabelValue( 0, u"Address" )
		self.m_grid_coils.SetColLabelValue( 1, u"Label" )
		self.m_grid_coils.SetColLabelValue( 2, u"Desc" )
		self.m_grid_coils.SetColLabelAlignment( wx.ALIGN_CENTER, wx.ALIGN_CENTER )

		# Rows
		self.m_grid_coils.EnableDragRowSize( True )
		self.m_grid_coils.SetRowLabelAlignment( wx.ALIGN_CENTER, wx.ALIGN_CENTER )

		# Label Appearance

		# Cell Defaults
		self.m_grid_coils.SetDefaultCellAlignment( wx.ALIGN_LEFT, wx.ALIGN_TOP )
		bSizer4111.Add( self.m_grid_coils, 1, wx.ALL|wx.EXPAND, 5 )

		bSizer11 = wx.BoxSizer( wx.HORIZONTAL )

		self.m_button17 = wx.Button( self.m_panel41, wx.ID_ANY, u"Delete", wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer11.Add( self.m_button17, 0, wx.ALL, 5 )

		self.m_button18 = wx.Button( self.m_panel41, wx.ID_ANY, u"Modify", wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer11.Add( self.m_button18, 0, wx.ALL, 5 )


		bSizer4111.Add( bSizer11, 0, wx.EXPAND, 5 )


		self.m_panel41.SetSizer( bSizer4111 )
		self.m_panel41.Layout()
		bSizer4111.Fit( self.m_panel41 )
		self.m_notebook1.AddPage( self.m_panel41, u"Coils", False )

		bSizer3.Add( self.m_notebook1, 1, wx.ALL|wx.EXPAND, 5 )

		bSizer12 = wx.BoxSizer( wx.HORIZONTAL )

		self.m_button15 = wx.Button( self, wx.ID_ANY, u"Refresh", wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer12.Add( self.m_button15, 0, wx.ALL, 5 )

		self.m_button16 = wx.Button( self, wx.ID_ANY, u"Finish", wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer12.Add( self.m_button16, 0, wx.ALL, 5 )


		bSizer3.Add( bSizer12, 0, wx.EXPAND, 5 )


		self.SetSizer( bSizer3 )
		self.Layout()

		self.Centre( wx.BOTH )

		# Connect Events
		self.m_treeCtrl_connection.Bind( wx.EVT_TREE_ITEM_ACTIVATED, self._evt_on_selecting_iterface )
		self.m_button1.Bind( wx.EVT_BUTTON, self._clear_holding_registers_fields )
		self.m_button2.Bind( wx.EVT_BUTTON, self._add_holding_register )
		self.m_button112.Bind( wx.EVT_BUTTON, self._evt_on_delete_holding_register )
		self.m_button12.Bind( wx.EVT_BUTTON, self._on_evt_modify_holding_register )
		self.m_button11.Bind( wx.EVT_BUTTON, self._clear_input_registers_fields )
		self.m_button21.Bind( wx.EVT_BUTTON, self._add_input_register )
		self.m_button13.Bind( wx.EVT_BUTTON, self._on_evt_delete_input_registers )
		self.m_button14.Bind( wx.EVT_BUTTON, self._on_evt_modify_input_registers )
		self.m_button111.Bind( wx.EVT_BUTTON, self._clear_di_fields )
		self.m_button211.Bind( wx.EVT_BUTTON, self._add_di )
		self.m_button151.Bind( wx.EVT_BUTTON, self._on_evt_delete_di )
		self.m_button161.Bind( wx.EVT_BUTTON, self._on_evt_modify_di )
		self.m_button1111.Bind( wx.EVT_BUTTON, self._clear_coils_fields )
		self.m_button2111.Bind( wx.EVT_BUTTON, self._add_coil )
		self.m_button17.Bind( wx.EVT_BUTTON, self._on_evt_delete_coil )
		self.m_button18.Bind( wx.EVT_BUTTON, self._on_evt_modify_coil )
		self.m_button15.Bind( wx.EVT_BUTTON, self.refresh_all_grid_boxes )
		self.m_button16.Bind( wx.EVT_BUTTON, self._user_finished )

	def __del__( self ):
		pass


	# Virtual event handlers, override them in your derived class
	def _evt_on_selecting_iterface( self, event ):
		event.Skip()

	def _clear_holding_registers_fields( self, event ):
		event.Skip()

	def _add_holding_register( self, event ):
		event.Skip()

	def _evt_on_delete_holding_register( self, event ):
		event.Skip()

	def _on_evt_modify_holding_register( self, event ):
		event.Skip()

	def _clear_input_registers_fields( self, event ):
		event.Skip()

	def _add_input_register( self, event ):
		event.Skip()

	def _on_evt_delete_input_registers( self, event ):
		event.Skip()

	def _on_evt_modify_input_registers( self, event ):
		event.Skip()

	def _clear_di_fields( self, event ):
		event.Skip()

	def _add_di( self, event ):
		event.Skip()

	def _on_evt_delete_di( self, event ):
		event.Skip()

	def _on_evt_modify_di( self, event ):
		event.Skip()

	def _clear_coils_fields( self, event ):
		event.Skip()

	def _add_coil( self, event ):
		event.Skip()

	def _on_evt_delete_coil( self, event ):
		event.Skip()

	def _on_evt_modify_coil( self, event ):
		event.Skip()

	def refresh_all_grid_boxes( self, event ):
		event.Skip()

	def _user_finished( self, event ):
		event.Skip()


