# -*- coding: utf-8 -*-

###########################################################################
## Python code generated with wxFormBuilder (version 3.10.1-0-g8feb16b3)
## http://www.wxformbuilder.org/
##
## PLEASE DO *NOT* EDIT THIS FILE!
###########################################################################

import wx
import wx.xrc

###########################################################################
## Class monitorWindow
###########################################################################

class monitorWindow ( wx.Dialog ):

	def __init__( self, parent ):
		wx.Dialog.__init__ ( self, parent, id = wx.ID_ANY, title = u"Monitor Window", pos = wx.DefaultPosition, size = wx.Size( 703,514 ), style = wx.DEFAULT_DIALOG_STYLE|wx.DIALOG_NO_PARENT|wx.MAXIMIZE_BOX|wx.MINIMIZE_BOX|wx.RESIZE_BORDER|wx.SYSTEM_MENU )

		self.SetSizeHints( wx.DefaultSize, wx.DefaultSize )

		bSizer1 = wx.BoxSizer( wx.VERTICAL )

		self.m_toolBar2 = wx.ToolBar( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TB_HORIZONTAL|wx.TB_NOICONS|wx.TB_TEXT )
		self.m_tool2 = self.m_toolBar2.AddTool( wx.ID_ANY, u"Pause", wx.NullBitmap, wx.NullBitmap, wx.ITEM_NORMAL, wx.EmptyString, wx.EmptyString, None )

		self.m_tool3 = self.m_toolBar2.AddTool( wx.ID_ANY, u"Resume", wx.NullBitmap, wx.NullBitmap, wx.ITEM_NORMAL, wx.EmptyString, wx.EmptyString, None )

		self.m_tool1 = self.m_toolBar2.AddTool( wx.ID_ANY, u" Export To Excel", wx.ArtProvider.GetBitmap( wx.ART_FILE_SAVE_AS, wx.ART_TOOLBAR ), wx.NullBitmap, wx.ITEM_NORMAL, u"Export to excel", wx.EmptyString, None )

		self.m_toolBar2.Realize()

		bSizer1.Add( self.m_toolBar2, 0, wx.EXPAND, 5 )

		self.m_staticline1 = wx.StaticLine( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.LI_HORIZONTAL )
		bSizer1.Add( self.m_staticline1, 0, wx.EXPAND |wx.ALL, 5 )

		bSizer2 = wx.BoxSizer( wx.VERTICAL )

		self.m_scrolledWindow1 = wx.ScrolledWindow( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.HSCROLL|wx.VSCROLL )
		self.m_scrolledWindow1.SetScrollRate( 5, 5 )
		bSizer2.Add( self.m_scrolledWindow1, 1, wx.EXPAND |wx.ALL, 5 )


		bSizer1.Add( bSizer2, 1, wx.EXPAND, 5 )


		self.SetSizer( bSizer1 )
		self.Layout()
		self.m_timer1 = wx.Timer()
		self.m_timer1.SetOwner( self, wx.ID_ANY )

		self.Centre( wx.BOTH )

		# Connect Events
		self.Bind( wx.EVT_CLOSE, self.evt_on_close )
		self.Bind( wx.EVT_TOOL, self._evt_on_pause_timer, id = self.m_tool2.GetId() )
		self.Bind( wx.EVT_TOOL, self._evt_on_timer_resume, id = self.m_tool3.GetId() )
		self.Bind( wx.EVT_TOOL, self._evt_on_export_to_excel, id = self.m_tool1.GetId() )
		self.Bind( wx.EVT_TIMER, self.evt_request_data, id=wx.ID_ANY )

	def __del__( self ):
		pass


	# Virtual event handlers, override them in your derived class
	def evt_on_close( self, event ):
		event.Skip()

	def _evt_on_pause_timer( self, event ):
		event.Skip()

	def _evt_on_timer_resume( self, event ):
		event.Skip()

	def _evt_on_export_to_excel( self, event ):
		event.Skip()

	def evt_request_data( self, event ):
		event.Skip()


