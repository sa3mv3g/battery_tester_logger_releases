import logging
from datetime import datetime
from typing import List, Union, Optional
import threading
import wx
from pymodbus.payload import BinaryPayloadDecoder, BinaryPayloadBuilder
from pymodbus.constants import Endian
from .usergui.register_control_panel_gui import RegisterControlPanelGui
from .common import ControlGroup
from .mbDeviceConfig import ModbusDeviceConfig
from .common import REGISTER_TYPE_HOLDING_REGISTER
from .common import REGISTER_TYPE_INPUT_REGISTER
from .common import REGISTER_TYPE_DISCRETE_INPUT
from .common import REGISTER_TYPE_COILS
from .common import ANY_MODBUS_MEM_T
from .common import REGISTER_DATATYPE_U16
from .common import REGISTER_DATATYPE_I16
from .common import REGISTER_DATATYPE_F32
from .common import REGISTER_DATATYPE_U32
from .common import REGISTER_DATATYPE_I32
from .modbus_master_server import ModbusTransactionToken
from .modbus_master_server import ModbusMasterServer
from .modbus_master_server import DEVICE_INTERNAL_COMM_ERROR, DEVICE_DISCONNECT_ERROR, DEVICE_NO_ERROR

class NumericControlWindow:
    def __init__(self, mbDevice:ModbusDeviceConfig, reg:ANY_MODBUS_MEM_T, parent: wx.Window, sizer: wx.Sizer):
        self.parent = parent
        self.boxSizer = sizer
        self.mbDevice:ModbusDeviceConfig = mbDevice
        self.reg:ANY_MODBUS_MEM_T = reg
        self.textCtrl:Optional[wx.TextCtrl] = None
        self.updateButton:Optional[wx.Button] = None

    def  addNumberControl(self, label: str, unit: str, control_id: int):
        horizontalBoxSizer = wx.BoxSizer(wx.HORIZONTAL)
        label = wx.StaticText(self.parent, label=label)
        horizontalBoxSizer.Add(label, 0, wx.ALL, 5)
        self.textCtrl = wx.TextCtrl(self.parent, value=str(self.reg.value), \
                                    style=wx.TE_RIGHT, id=control_id)
        if self.reg.value is not None:
            self.textCtrl.SetValue(self.reg.logging_parameters.getCalibratedNumberAsString(self.reg.value))
        horizontalBoxSizer.Add(self.textCtrl, 0, wx.ALL, 5)
        unitLabel = wx.StaticText(self.parent, label=unit)
        horizontalBoxSizer.Add(unitLabel, 0, wx.ALL, 5)
        self.updateButton = wx.Button(self.parent, label="Update", id=wx.ID_ANY)
        horizontalBoxSizer.Add(self.updateButton, 0, wx.ALL, 5)
        self.updateButton.Bind(wx.EVT_BUTTON, self.onUpdateButtonClick)
        self.boxSizer.Add(horizontalBoxSizer, 0, wx.ALL, 5)

    def onUpdateButtonClick(self, event):
        # pylint: disable=unused-argument
        # this function will send the write request to
        # modbus server. For this will create a unique transaction token (ModbusTransactionToken).
        # After sending the transaction, the token will be stored in the
        # transaction_requests list and the textctrl will be disabled.
        # The textctrl will be enabled again when the transaction is completed.
        value = self.textCtrl.GetValue()
        reg_vals = []
        ts = datetime.now().timestamp()
        tid = (int(ts) << 4) | 2
        builder = BinaryPayloadBuilder(byteorder=Endian.BIG, wordorder=Endian.BIG)
        if self.reg.dataType == REGISTER_DATATYPE_I16:
            builder.add_16bit_int(int(value))
        elif self.reg.dataType == REGISTER_DATATYPE_U16:
            builder.add_16bit_uint(int(value))
        elif self.reg.dataType == REGISTER_DATATYPE_F32:
            builder.add_32bit_float(float(value))
        elif self.reg.dataType == REGISTER_DATATYPE_I32:
            builder.add_32bit_int(int(value))
        elif self.reg.dataType == REGISTER_DATATYPE_U32:
            builder.add_32bit_uint(int(value))

        reg_vals = builder.to_registers()
        self.reg.value = reg_vals
        transaction_token = ModbusTransactionToken(
            tid = tid,
            timestamp = ts,
            starting_address=self.reg.address,
            request_length = len(reg_vals),
            register_type=self.reg,
            device_info=self.mbDevice,
            transactionCompleteSemaphore = threading.Event()
        )
        transaction_token.read_or_write = ModbusTransactionToken.OPERATION_WRITE
        ModbusMasterServer.transfer_queue.put(transaction_token)
        if transaction_token.transactionCompleteSemaphore.wait(timeout=3.0):
            if transaction_token.errorResponse == DEVICE_DISCONNECT_ERROR:
                wx.LogError("Modbus Device Disconnected.")
            elif transaction_token.errorResponse == DEVICE_INTERNAL_COMM_ERROR:
                wx.LogError("Modbus Device internal communication error.")

class BooleanControlWindow:
    def __init__(self, mbDevice:ModbusDeviceConfig, reg:ANY_MODBUS_MEM_T, parent: wx.Window, sizer: wx.Sizer):
        self.parent = parent
        self.boxSizer = sizer
        self.reg:ANY_MODBUS_MEM_T = reg
        self.mbDevice:ModbusDeviceConfig = mbDevice
        self.checkBox:Optional[wx.CheckBox] = None
        self.updateButton:Optional[wx.Button] = None

    def addBooleanControl(self, label: str, control_id: int):
        horizontalBoxSizer = wx.BoxSizer(wx.HORIZONTAL)
        label = wx.StaticText(self.parent, label=label)
        horizontalBoxSizer.Add(label, 0, wx.ALL, 5)
        self.checkBox = wx.CheckBox(self.parent, id=control_id)
        if self.reg.value is not None:
            self.checkBox.SetValue(bool(self.reg.value))
        self.updateButton = wx.Button(self.parent, label="Update", id=wx.ID_ANY)
        self.updateButton.Bind(wx.EVT_BUTTON, self.onUpdateButtonClick)
        horizontalBoxSizer.Add(self.checkBox, 0, wx.ALL, 5)
        horizontalBoxSizer.Add(self.updateButton, 0, wx.ALL, 5)
        self.boxSizer.Add(horizontalBoxSizer, 0, wx.ALL, 5)

    def onUpdateButtonClick(self, event):
        # pylint: disable=unused-argument
        # this function will send the write request to
        # modbus server. For this will create a unique transaction token (ModbusTransactionToken).
        # After sending the transaction, the token will be stored in the
        # transaction_requests list and the textctrl will be disabled.
        # The textctrl will be enabled again when the transaction is completed.
        value = self.checkBox.GetValue()
        reg_vals = [1 if value is True else 0]
        self.reg.value = [value]
        ts = datetime.now().timestamp()
        tid = (int(ts) << 4) | 1
        transaction_token = ModbusTransactionToken(
            tid = tid,
            timestamp = ts,
            starting_address=self.reg.address,
            request_length = len(reg_vals),
            register_type=self.reg,
            device_info=self.mbDevice,
            transactionCompleteSemaphore = threading.Event()
        )
        transaction_token.read_or_write = ModbusTransactionToken.OPERATION_WRITE
        ModbusMasterServer.transfer_queue.put(transaction_token)
        if transaction_token.transactionCompleteSemaphore.wait(timeout=3.0):
            if transaction_token.errorResponse == DEVICE_DISCONNECT_ERROR:
                wx.LogError("Modbus Device Disconnected.")
            elif transaction_token.errorResponse == DEVICE_INTERNAL_COMM_ERROR:
                wx.LogError("Modbus Device internal communication error.")

class RegisterControlGroupGui(RegisterControlPanelGui):
    # pylint: disable=too-many-ancestors

    def __init__(self, parent: wx.Window, control_group: ControlGroup,
                 modbus_device_list: List[ModbusDeviceConfig]):
        # pylint: disable=too-many-branches, too-many-statements
        super().__init__(parent)
        if control_group is None:
            wx.LogError("Control group is not provided.")
            self.Destroy()
        self.control_group_config:ControlGroup = control_group
        self.modbus_device_list: List[ModbusDeviceConfig] = modbus_device_list
        self.controlWindows:List[Union[NumericControlWindow, BooleanControlWindow]] = []
        self.m_verticalBoxSizer = wx.BoxSizer(wx.VERTICAL)

        id_cntr = 0
        for regRef in self.control_group_config.registers:
            if regRef.device_address not in [device.device_address for device in self.modbus_device_list]:
                logging.error("Device with address %d not found in the device list", regRef.device_address)
                continue
            device = next(device for device in self.modbus_device_list \
                            if device.device_address == regRef.device_address)
            reg = device.get_register_from_reference(regRef)
            if reg is None:
                logging.error("Register with address %d not found in the device", regRef.register_address)
                continue

            if regRef.register_type in (REGISTER_TYPE_INPUT_REGISTER, REGISTER_TYPE_DISCRETE_INPUT):
                logging.error("Unsupported register type %s for register %s", regRef.register_type, reg.label)
                continue

            reg.value = None
            if regRef.register_type == REGISTER_TYPE_HOLDING_REGISTER:
                id_cntr += 1
                # get its initial value
                sa = reg.address
                rl = 0
                if reg.dataType in (REGISTER_DATATYPE_U16, REGISTER_DATATYPE_I16):
                    rl = 1
                else:
                    rl = 2
                token =  ModbusTransactionToken(
                    tid = 0,
                    timestamp = 0,
                    starting_address=sa,
                    request_length = rl,
                    register_type=reg,
                    device_info=device,
                    transactionCompleteSemaphore=threading.Event()
                )
                ModbusMasterServer.transfer_queue.put(token)
                semwait = token.transactionCompleteSemaphore.wait(timeout=3.0)
                if semwait is True and token.errorResponse == DEVICE_NO_ERROR:
                    decoder = BinaryPayloadDecoder.fromRegisters(
                        token.response,
                        byteorder=Endian.BIG,
                        wordorder=Endian.BIG
                    )
                    if reg.dataType == REGISTER_DATATYPE_I16:
                        reg.value = decoder.decode_16bit_int()
                    elif reg.dataType == REGISTER_DATATYPE_U16:
                        reg.value = decoder.decode_16bit_uint()
                    elif reg.dataType == REGISTER_DATATYPE_F32:
                        reg.value = decoder.decode_32bit_float()
                    elif reg.dataType == REGISTER_DATATYPE_I32:
                        reg.value = decoder.decode_32bit_int()
                    elif reg.dataType == REGISTER_DATATYPE_U32:
                        reg.value = decoder.decode_32bit_uint()
                else:
                    logging.error("Error in reading holding register %s", reg.label)
                numericControlWindow = NumericControlWindow(
                    device,
                    reg,
                    self.m_scrolledWindow1,
                    self.m_verticalBoxSizer
                )
                numericControlWindow.addNumberControl(
                    reg.logging_parameters.name,
                    reg.logging_parameters.unit,
                    id_cntr
                )
                self.controlWindows.append(numericControlWindow)
            elif regRef.register_type == REGISTER_TYPE_COILS:
                id_cntr += 1
                token =  ModbusTransactionToken(
                    tid = 0,
                    timestamp = 0,
                    starting_address=reg.address,
                    request_length = 1,
                    register_type=reg,
                    device_info=device,
                    transactionCompleteSemaphore=threading.Event()
                )
                ModbusMasterServer.transfer_queue.put(token)
                semwait = token.transactionCompleteSemaphore.wait(timeout=3.0)
                if semwait is True and token.errorResponse == DEVICE_NO_ERROR:
                    #pylint: disable=unsubscriptable-object
                    reg.value = token.response[0]
                else:
                    logging.error("Error in reading coil %s", reg.label)
                booleanControlWindow = BooleanControlWindow(
                    device,
                    reg,
                    self.m_scrolledWindow1,
                    self.m_verticalBoxSizer
                )
                booleanControlWindow.addBooleanControl(reg.logging_parameters.name, id_cntr)
                self.controlWindows.append(booleanControlWindow)
            else:
                logging.log("Unsupported data type %s for register %s", regRef.register_type, reg.label)

        self.m_scrolledWindow1.SetSizer(self.m_verticalBoxSizer)
        self.m_scrolledWindow1.SetVirtualSize(self.m_verticalBoxSizer.GetMinSize())
        self.m_scrolledWindow1.Layout()
