"""
serial_port_config_gui.py

This module provides a GUI dialog for configuring serial port settings using wxPython.
It includes the following classes:
    SerialPortConfigGui: A GUI dialog for configuring serial port settings.

Classes:
    SerialPortConfigGui: Inherits from SerialPortConfigDialog and appSerialPortInfo.
        Attributes:
            serial_port_config (appSerialPortInfo): The current serial port configuration.
        Methods:
            __init__(parent, serial_port_config):
                Initializes the dialog with the given parent and serial port configuration.
            get_serial_ports():
                Returns a list of available serial ports on the system.
            populate_serial_ports_choice():
                Populates the m_choice1 control with the available serial ports.
            onDialogInit(event):
                Event handler for dialog initialization. Populates the serial ports choice control.
            onRefresh(event=None):
                Event handler for refreshing the serial ports list. Populates the serial ports
                choice control.
            onComplete(event):
                Event handler for completing the dialog. Saves the selected serial
                port configuration and closes the dialog.
            onCancel(event):
                Event handler for canceling the dialog. Clears the serial port configuration
                and closes the dialog.
"""
import uuid
import serial.tools.list_ports
import wx
from .usergui.serial_port_config import SerialPortConfigDialog
from .common import appSerialPortInfo

class SerialPortConfigGui(SerialPortConfigDialog, appSerialPortInfo):
    """
    A GUI dialog for configuring serial port settings.
    Inherits from:
        SerialPortConfigDialog: Base class for serial port configuration dialog.
        appSerialPortInfo: Common application serial port information.
    Attributes:
        serial_port_config (appSerialPortInfo): The current serial port configuration.
    Methods:
        __init__(parent, serial_port_config):
            Initializes the dialog with the given parent and serial port configuration.
        get_serial_ports():
        populate_serial_ports_choice():
        onDialogInit(event):
            Event handler for dialog initialization. Populates the serial ports choice control.
        onRefresh(event=None):
            Event handler for refreshing the serial ports list. Populates
            the serial ports choice control.
        onComplete(event):
            Event handler for completing the dialog. Saves the selected serial
            port configuration and closes the dialog.
        onCancel(event):
            Event handler for canceling the dialog. Clears the
            serial port configuration and closes the dialog.
    """
    # pylint: disable=too-many-ancestors
    def __init__(self, parent, serial_port_config: appSerialPortInfo = None):
        super().__init__(parent)
        self.serial_port_config = serial_port_config
        if self.serial_port_config is not None:
            self.m_choice1.SetValue(serial_port_config.port)
            self.m_choice2.SetStringSelection(str(serial_port_config.baudrate))
            self.m_choice3.SetStringSelection(serial_port_config.parity)
            self.m_choice4.SetStringSelection(str(serial_port_config.stop_bits))
            self.m_textCtrl5.SetValue(str(serial_port_config.timeout))

    def get_serial_ports(self): #pylint: disable=no-self-use
        """
        Returns a list of available serial ports on the system.
        """
        ports = serial.tools.list_ports.comports()
        return [port.device for port in ports]

    def populate_serial_ports_choice(self):
        """
        Populates the m_choice1 control with the available serial ports.
        """
        serial_ports = self.get_serial_ports()
        if not serial_ports:
            wx.LogError("No serial ports available.")
            return
        self.m_choice1.Clear()
        for port in serial_ports:
            self.m_choice1.Append(port)

    def evt_on_dialog_init(self, event):
        # pylint: disable=unused-argument
        self.populate_serial_ports_choice()

    def evt_on_refresh(self, event=None):
        # pylint: disable=unused-argument
        self.populate_serial_ports_choice()

    def evt_on_complete(self, event):
        # pylint: disable=unused-argument
        port_name = self.m_choice1.GetValue()
        baudrate = int(self.m_choice2.GetStringSelection())
        parity = self.m_choice3.GetStringSelection()
        stop_bits = int(self.m_choice4.GetStringSelection())
        timeout = int(self.m_textCtrl5.GetValue())
        self.serial_port_config = appSerialPortInfo(
            uid=self.serial_port_config.uid if self.serial_port_config else str(uuid.uuid4()),
            port = port_name,
            baudrate = baudrate,
            parity = parity,
            stop_bits = stop_bits,
            timeout = timeout
        )
        self.Close()

    def evt_on_cancel(self, event):
        # pylint: disable=unused-argument
        self.serial_port_config = None
        self.Close()
