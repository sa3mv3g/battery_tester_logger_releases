"""
Global Constants:
- REGISTER_DATATYPE_U16: String constant for 16-bit unsigned integer data type.
- REGISTER_DATATYPE_F32: String constant for 32-bit float data type.
- REGISTER_DATATYPE_I16: String constant for 16-bit signed integer data type.
- REGISTER_DATATYPE_U32: String constant for 32-bit unsigned integer data type.
- REGISTER_DATATYPE_I32: String constant for 32-bit signed integer data type.
- REGISTER_DATATYPE_BIT: String constant for bit data type.
Dictionary Keys:
- KEY_DEVICE_ADDRESS: Key for the Modbus device address.
- KEY_INTERFACE_TYPE: Key for the interface type.
- KEY_INTERFACE_CONFIG: Key for the interface configuration.
- KEY_HOLDING_REGISTERS: Key for holding registers.
- KEY_INPUT_REGISTERS: Key for input registers.
- KEY_DISCRETE_INPUTS: Key for discrete inputs.
- KEY_COILS: Key for coils.
- KEY_MIME_IDENTIFICATION: Key for MIME device identification.
- KEY_DEVICE_NAME: Key for the device name.
This module defines a class that describes a Modbus device configuration.

The class includes the following information:
- Holding registers
- Input registers
- Discrete inputs
- Coils
- MIME device identification
- Modbus device address
- Communication interface configuration (e.g., serial port, TCP/IP)

The class provides methods to configure and access the device settings, ensuring proper
communication with the Modbus device over the specified interface.
"""

from typing import Dict, Optional, Union, Tuple
import struct
import inspect
from .common import HoldingRegister, InputRegister, DiscreteInput, Coil
from .common import appSerialPortInfo
from .common import RegisterReference
from .common import REGISTER_TYPE_DISCRETE_INPUT
from .common import REGISTER_TYPE_COILS
from .common import REGISTER_TYPE_HOLDING_REGISTER
from .common import REGISTER_TYPE_INPUT_REGISTER

class BitEncoding:
    @staticmethod
    def encode_u32_to_u16(value: int) -> Tuple[int, int]:
        """
        Encodes a 32-bit unsigned integer into two 16-bit unsigned integers.

        :param value: The 32-bit unsigned integer.
        :return: A tuple containing two 16-bit unsigned integers.
        """
        high = (value >> 16) & 0xFFFF
        low = value & 0xFFFF
        return high, low

    @staticmethod
    def decode_u16_to_u32(high: int, low: int) -> int:
        """
        Decodes two 16-bit unsigned integers into a 32-bit unsigned integer.

        :param high: The high 16 bits.
        :param low: The low 16 bits.
        :return: The 32-bit unsigned integer.
        """
        return (high << 16) | low

    @staticmethod
    def encode_i32_to_u16(value: int) -> Tuple[int, int]:
        """
        Encodes a 32-bit signed integer into two 16-bit unsigned integers.

        :param value: The 32-bit signed integer.
        :return: A tuple containing two 16-bit unsigned integers.
        """
        high = (value >> 16) & 0xFFFF
        low = value & 0xFFFF
        return high, low

    @staticmethod
    def decode_u16_to_i32(high: int, low: int) -> int:
        """
        Decodes two 16-bit unsigned integers into a 32-bit signed integer.

        :param high: The high 16 bits.
        :param low: The low 16 bits.
        :return: The 32-bit signed integer.
        """
        value = (high << 16) | low
        if value & 0x80000000:
            value -= 0x100000000
        return value

    @staticmethod
    def encode_f32_to_u16(value: float) -> Tuple[int, int]:
        """
        Encodes a 32-bit float into two 16-bit unsigned integers.

        :param value: The 32-bit float.
        :return: A tuple containing two 16-bit unsigned integers.
        """
        packed = struct.pack('>f', value)
        high, low = struct.unpack('>HH', packed)
        return high, low

    @staticmethod
    def decode_u16_to_f32(high: int, low: int) -> float:
        """
        Decodes two 16-bit unsigned integers into a 32-bit float.

        :param high: The high 16 bits.
        :param low: The low 16 bits.
        :return: The 32-bit float.
        """
        packed = struct.pack('>HH', high, low)
        return struct.unpack('>f', packed)[0]

class ModbusDeviceConfig:
    """
    ModbusDeviceConfig is a class that represents the configuration of a Modbus device.
    It includes various attributes and methods to manage the device's configuration,
    such as device address, interface type, interface configuration, holding registers,
    input registers, discrete inputs, and coils.
    Attributes:
        KEY_DEVICE_ADDRESS (str):
            A constant key used to represent the device address in the configuration dictionary.
        KEY_INTERFACE_TYPE (str):
            A constant key used to represent the interface type in the configuration dictionary.
        KEY_INTERFACE_CONFIG (str):
            A constant key used to represent the interface configuration in the configuration dictionary.
        KEY_HOLDING_REGISTERS (str):
            A constant key used to represent the holding registers in the configuration dictionary.
        KEY_INPUT_REGISTERS (str):
            A constant key used to represent the input registers in the configuration dictionary.
        KEY_DISCRETE_INPUTS (str):
            A constant key used to represent the discrete inputs in the configuration dictionary.
        KEY_COILS (str):
            A constant key used to represent the coils in the configuration dictionary.
        KEY_MIME_IDENTIFICATION (str):
            A constant key used to represent the MIME identification in the configuration dictionary.
        KEY_DEVICE_NAME (str):
            A constant key used to represent the device name in the configuration dictionary.
    """
    # Global constants for dictionary keys
    # pylint: disable=too-many-instance-attributes
    KEY_DEVICE_ADDRESS = "device_address"
    KEY_INTERFACE_TYPE = "interface_type"
    KEY_INTERFACE_CONFIG = "interface_config"
    KEY_HOLDING_REGISTERS = "holding_registers"
    KEY_INPUT_REGISTERS = "input_registers"
    KEY_DISCRETE_INPUTS = "discrete_inputs"
    KEY_COILS = "coils"
    KEY_MIME_IDENTIFICATION = "mime_identification"
    KEY_DEVICE_NAME = "device_name"

    INTERFACE_TYPE_RTU = 'rtu'
    INTERFACE_TYPE_TCP = 'tcp'
    INTERFACE_TYPE_ASCII = 'ascii'
    INTERFACE_TYPE_UNDEFINED = 'undefined'

    def __init__(self,
                 device_address: int,
                 interface_type: str,
                 interface_config: Dict[str, Union[str, int, float]],
                 holding_registers: Optional[Dict[int, HoldingRegister]] = None,
                 input_registers: Optional[Dict[int, InputRegister]] = None,
                 discrete_inputs: Optional[Dict[int, DiscreteInput]] = None,
                 coils: Optional[Dict[int, Coil]] = None,
                 mime_identification: Optional[str] = None,
                 **kwargs
                ):
        """
        Initializes the ModbusDeviceConfig with the given parameters.

        :param device_address: The Modbus device address.
        :param interface_type: The type of interface (e.g., 'serial', 'tcp').
        :param interface_config: The configuration for the specified interface.
        :param holding_registers: A dictionary of holding registers.
        :param input_registers: A dictionary of input registers.
        :param discrete_inputs: A dictionary of discrete inputs.
        :param coils: A dictionary of coils.
        :param mime_identification: MIME device identification information.
        """
        # pylint: disable=too-many-arguments
        self.device_address: int = device_address
        self.interface_type: str = interface_type
        self.interface_config: Dict[str, Union[str, int, float]] = interface_config
        self.holding_registers: Dict[int, HoldingRegister] = holding_registers if holding_registers is not None else {}
        self.input_registers: Dict[int, InputRegister] = input_registers if input_registers is not None else {}
        self.discrete_inputs: Dict[int, DiscreteInput] = discrete_inputs if discrete_inputs is not None else {}
        self.coils: Dict[int, Coil] = coils if coils is not None else {}
        self.mime_identification: Optional[str] = mime_identification
        self.device_name: Optional[str] = kwargs.get('device_name', None)

    def to_dict(self) -> Dict[str, Union[int, str, Dict[str, Union[str, int, float]],\
                                         Dict[int, Dict[str, Union[int, bool, str]]]]]:
        """
        Converts the ModbusDeviceConfig to a dictionary.

        :return: A dictionary representation of the ModbusDeviceConfig.
        """
        return {
            self.KEY_DEVICE_ADDRESS: self.device_address,
            self.KEY_INTERFACE_TYPE: self.interface_type,
            self.KEY_INTERFACE_CONFIG: self.interface_config,
            self.KEY_HOLDING_REGISTERS: {int(addr): reg.to_dict() for addr, reg in self.holding_registers.items()},
            self.KEY_INPUT_REGISTERS: {int(addr): reg.to_dict() for addr, reg in self.input_registers.items()},
            self.KEY_DISCRETE_INPUTS: {int(addr): reg.to_dict() for addr, reg in self.discrete_inputs.items()},
            self.KEY_COILS: {int(addr): reg.to_dict() for addr, reg in self.coils.items()},
            self.KEY_MIME_IDENTIFICATION: self.mime_identification,
            self.KEY_DEVICE_NAME: self.device_name
        }

    @classmethod
    def from_dict(cls, data) -> 'ModbusDeviceConfig':
        """
        Populates the ModbusDeviceConfig from a dictionary.

        :param data: A dictionary containing the ModbusDeviceConfig data.
        :return: A ModbusDeviceConfig object.
        """
        if not all(key in data for key in\
                    [ModbusDeviceConfig.KEY_DEVICE_ADDRESS,\
                     ModbusDeviceConfig.KEY_INTERFACE_TYPE,\
                     ModbusDeviceConfig.KEY_INTERFACE_CONFIG,\
                        ModbusDeviceConfig.KEY_HOLDING_REGISTERS,\
                            ModbusDeviceConfig.KEY_INPUT_REGISTERS,\
                                ModbusDeviceConfig.KEY_DISCRETE_INPUTS,\
                                    ModbusDeviceConfig.KEY_COILS]):
            fmt = "Invalid data format: Missing one or more required keys in the input dictionary (file: {}, line: {})"
            err_str = fmt.format(__file__, inspect.currentframe().f_lineno)
            raise ValueError(err_str)
        holding_registers = {int(addr): HoldingRegister.from_dict(reg)\
                             for addr, reg in data.get(ModbusDeviceConfig.KEY_HOLDING_REGISTERS, {}).items()}
        input_registers = {int(addr): InputRegister.from_dict(reg)\
                           for addr, reg in data.get(ModbusDeviceConfig.KEY_INPUT_REGISTERS, {}).items()}
        discrete_inputs = {int(addr): DiscreteInput.from_dict(reg)\
                           for addr, reg in data.get(ModbusDeviceConfig.KEY_DISCRETE_INPUTS, {}).items()}
        coils = {int(addr): Coil.from_dict(reg)\
                 for addr, reg in data.get(ModbusDeviceConfig.KEY_COILS, {}).items()}
        return cls(
            device_address=data[ModbusDeviceConfig.KEY_DEVICE_ADDRESS],
            interface_type=data[ModbusDeviceConfig.KEY_INTERFACE_TYPE],
            interface_config=data[ModbusDeviceConfig.KEY_INTERFACE_CONFIG],
            holding_registers=holding_registers,
            input_registers=input_registers,
            discrete_inputs=discrete_inputs,
            coils=coils,
            mime_identification=data.get(ModbusDeviceConfig.KEY_MIME_IDENTIFICATION),
            device_name=data.get(ModbusDeviceConfig.KEY_DEVICE_NAME)
        )

    def add_holding_register(self, address: int, value: int, description: str = "", label: str = "") -> None:
        """
        Adds or updates a holding register.

        :param address: The address of the holding register.
        :param value: The value to set for the holding register.
        :param description: A description of the holding register.
        :param label: A label for the holding register.
        """
        self.holding_registers[address] = HoldingRegister(address, value, description, label)

    def add_input_register(self, address: int, value: int, description: str = "", label: str = "") -> None:
        """
        Adds or updates an input register.

        :param address: The address of the input register.
        :param value: The value to set for the input register.
        :param description: A description of the input register.
        :param label: A label for the input register.
        """
        self.input_registers[address] = InputRegister(address, value, description, label)

    def add_discrete_input(self, address: int, value: bool, description: str = "", label: str = "") -> None:
        """
        Adds or updates a discrete input.

        :param address: The address of the discrete input.
        :param value: The value to set for the discrete input.
        :param description: A description of the discrete input.
        :param label: A label for the discrete input.
        """
        self.discrete_inputs[address] = DiscreteInput(address, value, description, label)

    def add_coil(self, address: int, value: bool, description: str = "", label: str = "") -> None:
        """
        Adds or updates a coil.

        :param address: The address of the coil.
        :param value: The value to set for the coil.
        :param description: A description of the coil.
        :param label: A label for the coil.
        """
        self.coils[address] = Coil(address, value, description, label)

    def get_holding_register(self, address: int) -> Optional[HoldingRegister]:
        """
        Retrieves the value of a holding register.

        :param address: The address of the holding register.
        :return: The holding register object.
        """
        return self.holding_registers.get(address)

    def get_input_register(self, address: int) -> Optional[InputRegister]:
        """
        Retrieves the value of an input register.

        :param address: The address of the input register.
        :return: The input register object.
        """
        return self.input_registers.get(address)

    def get_discrete_input(self, address: int) -> Optional[DiscreteInput]:
        """
        Retrieves the value of a discrete input.

        :param address: The address of the discrete input.
        :return: The discrete input object.
        """
        return self.discrete_inputs.get(address)

    def get_coil(self, address: int) -> Optional[Coil]:
        """
        Retrieves the value of a coil.

        :param address: The address of the coil.
        :return: The coil object.
        """
        return self.coils.get(address)

    def configure_serial_interface(self, uid:str ,port: str, baudrate: int,
            parity: str, stopbits: int, bytesize: int, timeout: float) -> None:
        """
        Configures the serial interface.

        :param port: The serial port.
        :param baudrate: The baud rate.
        :param parity: The parity.
        :param stopbits: The number of stop bits.
        :param bytesize: The byte size.
        :param timeout: The timeout value.
        """
        # pylint: disable=too-many-arguments
        if self.interface_type in (ModbusDeviceConfig.INTERFACE_TYPE_RTU,
            ModbusDeviceConfig.INTERFACE_TYPE_ASCII, ModbusDeviceConfig.INTERFACE_TYPE_UNDEFINED):
            self.interface_config = {
                'port': port,
                'baudrate': baudrate,
                'parity': parity,
                'stopbits': stopbits,
                'bytesize': bytesize,
                'timeout': timeout,
                'uid': uid
            }
        else:
            raise ValueError("Interface type is not serial")

    def configure_serial_interface_from_class(self, info:appSerialPortInfo) -> None:
        """
        Configures the serial interface.

        :param info: The serial port information.
        """
        if self.interface_type in (ModbusDeviceConfig.INTERFACE_TYPE_RTU,
            ModbusDeviceConfig.INTERFACE_TYPE_ASCII, ModbusDeviceConfig.INTERFACE_TYPE_UNDEFINED):
            self.interface_config = {
                'port': info.port,
                'baudrate': info.baudrate,
                'parity': info.parity,
                'stopbits': info.stop_bits,
                'bytesize': 8,
                'timeout': info.timeout,
                'uid': info.uid
            }
        else:
            raise ValueError("Interface type is not serial")

    def configure_tcp_interface(self, uid:str, host: str, port: int, timeout: float) -> None:
        """
        Configures the TCP/IP interface.

        :param host: The host address.
        :param port: The port number.
        :param timeout: The timeout value.
        """
        if self.interface_type == 'tcp':
            self.interface_config = {
                'host': host,
                'port': port,
                'timeout': timeout,
                'uid': uid
            }
        else:
            raise ValueError("Interface type is not TCP")

    def get_register_from_reference(self, ref:RegisterReference) -> \
        Optional[Union[InputRegister, HoldingRegister, DiscreteInput, Coil]]:
        retval:Optional[Union[InputRegister, HoldingRegister, DiscreteInput, Coil]] = None
        try:
            if ref.register_type is REGISTER_TYPE_DISCRETE_INPUT:
                retval = self.discrete_inputs[ref.register_address]
            elif ref.register_type is REGISTER_TYPE_COILS:
                retval = self.coils[ref.register_address]
            elif ref.register_type is REGISTER_TYPE_HOLDING_REGISTER:
                retval = self.holding_registers[ref.register_address]
            elif ref.register_type is REGISTER_TYPE_INPUT_REGISTER:
                retval = self.input_registers[ref.register_address]
        except KeyError:
            retval = None

        return retval
