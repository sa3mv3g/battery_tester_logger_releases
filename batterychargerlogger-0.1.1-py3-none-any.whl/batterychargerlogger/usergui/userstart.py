# -*- coding: utf-8 -*-

###########################################################################
## Python code generated with wxFormBuilder (version 3.10.1-0-g8feb16b3)
## http://www.wxformbuilder.org/
##
## PLEASE DO *NOT* EDIT THIS FILE!
###########################################################################

import wx
import wx.xrc

###########################################################################
## Class user_start
###########################################################################

class user_start ( wx.Frame ):

    def __init__( self, parent ):
        wx.Frame.__init__ ( self, parent, id = wx.ID_ANY, title = u"[Battery Charger:: Start]", pos = wx.DefaultPosition, size = wx.Size( 1015,608 ), style = wx.CLOSE_BOX|wx.DEFAULT_FRAME_STYLE|wx.MAXIMIZE|wx.MAXIMIZE_BOX|wx.MINIMIZE|wx.MINIMIZE_BOX|wx.HSCROLL|wx.TAB_TRAVERSAL|wx.VSCROLL|wx.WANTS_CHARS )

        self.SetSizeHints( wx.DefaultSize, wx.DefaultSize )

        self.m_menubar1 = wx.MenuBar( 0 )
        self.m_menu1 = wx.Menu()
        self.fileMenu_New = wx.MenuItem( self.m_menu1, wx.ID_ANY, u"New", wx.EmptyString, wx.ITEM_NORMAL )
        self.m_menu1.Append( self.fileMenu_New )

        self.fileMenu_Open = wx.MenuItem( self.m_menu1, wx.ID_ANY, u"Open", wx.EmptyString, wx.ITEM_NORMAL )
        self.m_menu1.Append( self.fileMenu_Open )

        self.fileMenu_Save = wx.MenuItem( self.m_menu1, wx.ID_ANY, u"Save"+ u"\t" + u"ctrl + s", wx.EmptyString, wx.ITEM_NORMAL )
        self.m_menu1.Append( self.fileMenu_Save )

        self.fileMenu_SaveAs = wx.MenuItem( self.m_menu1, wx.ID_ANY, u"SaveAs", wx.EmptyString, wx.ITEM_NORMAL )
        self.m_menu1.Append( self.fileMenu_SaveAs )

        self.m_menubar1.Append( self.m_menu1, u"File" )

        self.m_menu3 = wx.Menu()
        self.m_menuItem5 = wx.MenuItem( self.m_menu3, wx.ID_ANY, u"New", wx.EmptyString, wx.ITEM_NORMAL )
        self.m_menu3.Append( self.m_menuItem5 )

        self.m_menubar1.Append( self.m_menu3, u"MB Device" )

        self.m_menu31 = wx.Menu()
        self.m_menuItem6 = wx.MenuItem( self.m_menu31, wx.ID_ANY, u"New TCP Port", wx.EmptyString, wx.ITEM_NORMAL )
        self.m_menu31.Append( self.m_menuItem6 )

        self.m_menuItem7 = wx.MenuItem( self.m_menu31, wx.ID_ANY, u"New Serial Port", wx.EmptyString, wx.ITEM_NORMAL )
        self.m_menu31.Append( self.m_menuItem7 )

        self.m_menubar1.Append( self.m_menu31, u"Ports" )

        self.m_menu4 = wx.Menu()
        self.m_menuItem8 = wx.MenuItem( self.m_menu4, wx.ID_ANY, u"New Monitor Group", wx.EmptyString, wx.ITEM_NORMAL )
        self.m_menu4.Append( self.m_menuItem8 )

        self.m_menuItem9 = wx.MenuItem( self.m_menu4, wx.ID_ANY, u"Start Monitor", wx.EmptyString, wx.ITEM_NORMAL )
        self.m_menu4.Append( self.m_menuItem9 )

        self.m_menubar1.Append( self.m_menu4, u"Monitor" )

        self.m_menu5 = wx.Menu()
        self.m_menuItem10 = wx.MenuItem( self.m_menu5, wx.ID_ANY, u"New Control Group", wx.EmptyString, wx.ITEM_NORMAL )
        self.m_menu5.Append( self.m_menuItem10 )

        self.m_menuItem11 = wx.MenuItem( self.m_menu5, wx.ID_ANY, u"Start Control", wx.EmptyString, wx.ITEM_NORMAL )
        self.m_menu5.Append( self.m_menuItem11 )

        self.m_menubar1.Append( self.m_menu5, u"Control" )

        self.SetMenuBar( self.m_menubar1 )

        bSizer1 = wx.BoxSizer( wx.VERTICAL )

        bSizer2 = wx.BoxSizer( wx.HORIZONTAL )

        bSizer3 = wx.BoxSizer( wx.VERTICAL )

        self.m_staticText1 = wx.StaticText( self, wx.ID_ANY, u"Details", wx.DefaultPosition, wx.DefaultSize, 0 )
        self.m_staticText1.Wrap( -1 )

        bSizer3.Add( self.m_staticText1, 0, wx.ALL, 5 )

        self.m_treeCtrl2 = wx.TreeCtrl( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TR_DEFAULT_STYLE|wx.VSCROLL )
        bSizer3.Add( self.m_treeCtrl2, 1, wx.ALL|wx.EXPAND, 5 )


        bSizer2.Add( bSizer3, 1, wx.EXPAND, 5 )

        bSizer4 = wx.BoxSizer( wx.VERTICAL )

        self.m_staticText2 = wx.StaticText( self, wx.ID_ANY, u"Monitor Groups", wx.DefaultPosition, wx.DefaultSize, 0 )
        self.m_staticText2.Wrap( -1 )

        bSizer4.Add( self.m_staticText2, 0, wx.ALL, 5 )

        self.m_monitor_group_tree = wx.TreeCtrl( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TR_DEFAULT_STYLE )
        bSizer4.Add( self.m_monitor_group_tree, 1, wx.ALL|wx.EXPAND, 5 )


        bSizer2.Add( bSizer4, 1, wx.EXPAND, 5 )

        bSizer5 = wx.BoxSizer( wx.VERTICAL )

        self.m_staticText3 = wx.StaticText( self, wx.ID_ANY, u"Control Groups", wx.DefaultPosition, wx.DefaultSize, 0 )
        self.m_staticText3.Wrap( -1 )

        bSizer5.Add( self.m_staticText3, 0, wx.ALL, 5 )

        self.m_control_groups_tree = wx.TreeCtrl( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TR_DEFAULT_STYLE )
        bSizer5.Add( self.m_control_groups_tree, 1, wx.ALL|wx.EXPAND, 5 )


        bSizer2.Add( bSizer5, 1, wx.EXPAND, 5 )


        bSizer1.Add( bSizer2, 1, wx.ALL|wx.EXPAND, 5 )


        self.SetSizer( bSizer1 )
        self.Layout()
        self.m_statusBar2 = self.CreateStatusBar( 1, wx.STB_SIZEGRIP, wx.ID_ANY )

        self.Centre( wx.BOTH )

        # Connect Events
        self.Bind( wx.EVT_CLOSE, self.evt_on_dialog_close )
        self.Bind( wx.EVT_MENU, self.evt_create_new_file, id = self.fileMenu_New.GetId() )
        self.Bind( wx.EVT_MENU, self.evt_open_app_file, id = self.fileMenu_Open.GetId() )
        self.Bind( wx.EVT_MENU, self.evt_save_app_file, id = self.fileMenu_Save.GetId() )
        self.Bind( wx.EVT_MENU, self.evt_get_new_modbus_device_config, id = self.m_menuItem5.GetId() )
        self.Bind( wx.EVT_MENU, self.evt_save_new_tcp_port, id = self.m_menuItem6.GetId() )
        self.Bind( wx.EVT_MENU, self.evt_save_new_serial_port, id = self.m_menuItem7.GetId() )
        self.Bind( wx.EVT_MENU, self.evt_open_monitor_group_dialog, id = self.m_menuItem8.GetId() )
        self.Bind( wx.EVT_MENU, self.evt_startMonitoring, id = self.m_menuItem9.GetId() )
        self.Bind( wx.EVT_MENU, self._evt_on_new_control_group, id = self.m_menuItem10.GetId() )
        self.Bind( wx.EVT_MENU, self._evt_on_start_control_group, id = self.m_menuItem11.GetId() )
        self.m_treeCtrl2.Bind( wx.EVT_LEFT_DCLICK, self.evt_show_details )
        self.m_treeCtrl2.Bind( wx.EVT_LEFT_DOWN, self.update_props_of_device )
        self.m_monitor_group_tree.Bind( wx.EVT_LEFT_DCLICK, self._evt_start_monitor_window_from_tree )
        self.m_control_groups_tree.Bind( wx.EVT_LEFT_DCLICK, self._evt_start_control_group_from_tree )

    def __del__( self ):
        pass


    # Virtual event handlers, override them in your derived class
    def evt_on_dialog_close( self, event ):
        event.Skip()

    def evt_create_new_file( self, event ):
        event.Skip()

    def evt_open_app_file( self, event ):
        event.Skip()

    def evt_save_app_file( self, event ):
        event.Skip()

    def evt_get_new_modbus_device_config( self, event ):
        event.Skip()

    def evt_save_new_tcp_port( self, event ):
        event.Skip()

    def evt_save_new_serial_port( self, event ):
        event.Skip()

    def evt_open_monitor_group_dialog( self, event ):
        event.Skip()

    def evt_startMonitoring( self, event ):
        event.Skip()

    def _evt_on_new_control_group( self, event ):
        event.Skip()

    def _evt_on_start_control_group( self, event ):
        event.Skip()

    def evt_show_details( self, event ):
        event.Skip()

    def update_props_of_device( self, event ):
        event.Skip()

    def _evt_start_monitor_window_from_tree( self, event ):
        event.Skip()

    def _evt_start_control_group_from_tree( self, event ):
        event.Skip()


