from typing import Any, Optional, List
import wx
from matplotlib.backends.backend_wxagg import FigureCanvasWxAgg as FigureCanvas
from matplotlib.figure import Figure
from matplotlib.axes import Axes
from matplotlib.lines import Line2D
from .common import ANY_MODBUS_MEM_T
from .common import HoldingRegister
from .common import InputRegister
from .common import DiscreteInput
from .common import Coil
from .common import ChartDataPoint

class _DisplayType:
    """
    This class represents the type of display
    that the monitor window should display.
    """
    def __init__(self):
        self._data_table:List[Any] = []

    def add_data(self, data:ChartDataPoint):
        if not isinstance(data, ChartDataPoint):
            raise TypeError(f"Expected data to be of type ChartDataPoint, but got {type(data).__name__} instead.")
        self._data_table.append(data)

class _DisplayTypeNumber(_DisplayType):
    """
    This class represents the type of display
    that the monitor window should display.
    """
    def __init__(self, register:ANY_MODBUS_MEM_T, parent, sizer:wx.BoxSizer):
        super().__init__()
        self.register = register
        # create a new horizontal box sizer and
        # add lable, text control and unit label to it.
        # then add that horizontal box sizer to the parent sizer.
        self._wxBox:wx.BoxSizer = wx.BoxSizer(wx.HORIZONTAL)
        self._label:wx.StaticText = wx.StaticText(parent, label=self.register.logging_parameters.name)
        self._textCtrl:wx.TextCtrl = wx.TextCtrl(parent, style=wx.TE_RIGHT)
        self._unitLabel:wx.StaticText = wx.StaticText(parent, label=self.register.logging_parameters.unit)
        self._wxBox.Add(self._label, 0, wx.ALL, 5)
        self._wxBox.Add(self._textCtrl, 0, wx.ALL, 5)
        self._wxBox.Add(self._unitLabel, 0, wx.ALL, 5)
        self._textCtrl.Enable(False)
        self._wxBox.Layout()
        sizer.Add(self._wxBox, 0, wx.ALL, 5)

    def add_data(self, data:ChartDataPoint):
        super().add_data(data)
        self._textCtrl.SetValue(str(data.y))

class _DisplayTypeNumericPlot(_DisplayType):
    # pylint: disable=too-many-instance-attributes
    """
    This class represents the type of display
    that the monitor window should display.
    """
    def __init__(self, register:ANY_MODBUS_MEM_T, parent, sizer:wx.BoxSizer, buffLen:int):
        super().__init__()
        self.register:ANY_MODBUS_MEM_T = register
        self.buffLen:int = buffLen
        self._wxBox:wx.BoxSizer = wx.BoxSizer(wx.VERTICAL)
        # Add plot figure
        self._figure:Figure = Figure()
        self._canvas:FigureCanvas = FigureCanvas(parent, -1, self._figure)
        self._wxBox.Add(self._canvas, 1, wx.LEFT | wx.TOP | wx.GROW)
        self._axes:Axes = self._figure.add_subplot(111)
        name_lable = ""
        unit_label = ""
        if register.logging_parameters.name is not None \
            and len(register.logging_parameters.name) > 0:
            name_lable = register.logging_parameters.name
        if register.logging_parameters.unit is not None \
            and len(register.logging_parameters.unit) > 0:
            unit_label = f"({register.logging_parameters.unit})"
        self._axes.set_ylabel(f"{name_lable} {unit_label}")
        self._axes.set_xlabel("time (secs)")
        self._line:List[Line2D] = self._axes.plot([], [])
        self._current_value_display = _DisplayTypeNumber(register, parent, self._wxBox)
        self._wxBox.Layout()

        # Add the sizer to the parent sizer
        sizer.Add(self._wxBox, 1, wx.LEFT | wx.TOP | wx.GROW)

    def add_data(self, data:ChartDataPoint):
        super().add_data(data)
        self._current_value_display.add_data(data)
        x_data, y_data = self._line[0].get_data()
        x_data = [] if x_data is None else list(x_data)
        y_data = [] if y_data is None else list(y_data)
        x_data.append(data.x)
        y_data.append(data.y)
        if len(x_data) > self.buffLen:
            x_data = x_data[len(x_data) - self.buffLen:]
            y_data = y_data[len(y_data) - self.buffLen:]
        # sort the x_data and y_data based on x_data
        x_data, y_data = zip(*sorted(zip(x_data, y_data)))
        self._line[0].set_data(x_data, y_data)
        self._axes.relim()
        self._axes.autoscale_view()
        self._canvas.draw()

class _DisplayTypeBooleanPlot(_DisplayTypeNumericPlot):
    # pylint: disable=useless-super-delegation
    """
    This class represents the type of display
    that the monitor window should display.
    """
    def __init__(self, register:ANY_MODBUS_MEM_T, parent, sizer:wx.BoxSizer, buffLen:int):
        super().__init__(register, parent, sizer, buffLen)

    def add_data(self, data:List[int]):
        ndata = [data[0], 1 if data[1] else 0]
        super().add_data(ndata)
        self._current_value_display.add_data(ndata)

class _DisplayTypeBoolean(_DisplayTypeNumber):
    """
    This class represents the type of display
    that the monitor window should display.
    """
    def __init__(self, register:ANY_MODBUS_MEM_T, parent, sizer:wx.BoxSizer):
        super().__init__(register, parent, sizer)
        self._textCtrl.Enable(False)

    def add_data(self, data:List[int]):
        super().add_data(data)
        self._textCtrl.SetValue("ON" if data[1] else "OFF")

class ParameterWindowGui_Params:
    def __init__(self):
        self.parent = None
        self.sizer = None
        self.register:Optional[ANY_MODBUS_MEM_T] = None
        self.initValue:Optional[float] = None

class ParameterWindowGui:
    """
    This class represents the parameter window GUI.
    """
    def __init__(self, params:ParameterWindowGui_Params):
        self.params = params
        if self.params.register is None:
            raise ValueError("Register is not provided.")
        if self.params.parent is None:
            raise ValueError("Parent window is not provided.")
        # if the register is of type HoldingRegister or InputRegister then based on history buffer length it
        # will create a plot or a text control to display the data. If regiter is of type DiscreteInput or Coil
        # then it will create a text control to display the data.
        if isinstance(self.params.register, (HoldingRegister, InputRegister)):
            if self.params.register.logging_parameters.historyBufferLen > 1:
                self.displayControl = _DisplayTypeNumericPlot(
                    self.params.register,
                    self.params.parent,
                    self.params.sizer,
                    self.params.register.logging_parameters.historyBufferLen
                )
            else:
                self.displayControl = _DisplayTypeNumber(
                    self.params.register,
                    self.params.parent,
                    self.params.sizer
                )
        elif isinstance(self.params.register, (DiscreteInput, Coil)):
            if self.params.register.logging_parameters.historyBufferLen > 1:
                self.displayControl = _DisplayTypeBooleanPlot(
                    self.params.register,
                    self.params.parent,
                    self.params.sizer,
                    self.params.register.logging_parameters.historyBufferLen
                )
            else:
                self.displayControl = _DisplayTypeBoolean(
                    self.params.register,
                    self.params.parent,
                    self.params.sizer
                )
        else:
            raise ValueError("Invalid register type.")

    def add_data(self, data:List[int]):
        self.displayControl.add_data(data)

__all__ = [
    "ParameterWindowGui",
    "ParameterWindowGui_Params"
]
