"""
tcp_port_config_gui.py
    This module defines the TcpPortConfigGui class,
    which provides a graphical user interface (GUI)
    for configuring TCP port settings.
    It extends the tcpPortConfigDialog class and uses
    the appTcpPortInfo class for storing TCP port
    configuration information.
Classes:
    TcpPortConfigGui: A GUI class for configuring TCP port settings.
Usage:
    This module is intended to be used as part of a larger application
    that requires TCP port configuration through a GUI.
Dependencies:
    -   usergui.tcpPortConfigDialog: A module that provides the base
        dialog class for TCP port configuration.
    -   common: A module that contains the appTcpPortInfo class for
        storing TCP port configuration information.
"""

from .usergui.tcpPortConfigDialog import tcpPortConfigDialog
from .common import appTcpPortInfo

class TcpPortConfigGui(tcpPortConfigDialog, appTcpPortInfo):
    """
    A GUI dialog for configuring TCP port settings.
    Inherits from:
        tcpPortConfigDialog: The base dialog class for TCP port configuration.
        appTcpPortInfo: A class containing TCP port information.
    Attributes:
        tcp_port_config (appTcpPortInfo): An instance containing TCP
        port configuration details.
    Methods:
        __init__(parent, tcp_port_config):
            Initializes the TcpPortConfigGui dialog with the given parent
            and TCP port configuration.
        onComplete(event):
            Event handler for completing the TCP port configuration.
            Retrieves values from the GUI and updates the
            tcp_port_config attribute.
        onCancel(event):
            Event handler for canceling the TCP port configuration.
            Sets the tcp_port_config attribute
            to None and closes the dialog.
    """
    # pylint: disable=too-many-ancestors

    def __init__(self, parent, tcp_port_config: appTcpPortInfo = None):
        """
        Initializes the TCP port configuration GUI.
        Args:
            parent: The parent widget.
            tcp_port_config (appTcpPortInfo, optional):
                The TCP port configuration information. Defaults to None.
        """
        super().__init__(parent)
        self.tcp_port_config = tcp_port_config

    def evt_on_complete(self, event):
        """
        Event handler for the completion event.
        This method is triggered when the completion event occurs. It retrieves
        the IP address, port number, timeout, and name from the respective text
        controls, creates a `appTcpPortInfo` object with these values, and then
        closes the current window.
        Args:
            event: The event object that triggered this handler.
        """
        # pylint: disable=unused-argument
        ip_address = self.m_textCtrl6.GetValue()
        port_number = int(self.m_textCtrl7.GetValue())
        timeout = int(self.m_textCtrl8.GetValue())
        name = self.m_textCtrl9.GetValue()
        self.tcp_port_config = appTcpPortInfo(ip_address, port_number, timeout, name)
        self.Close()

    def evt_on_cancel(self, event):
        """
        Event handler for the cancel button.

        This method is triggered when the cancel button is clicked. It sets the
        tcp_port_config attribute to None and closes the current window.

        Args:
            event: The event object associated with the cancel button click.
        """
        # pylint: disable=unused-argument
        self.tcp_port_config = None
        self.Close()
