import inspect
from typing import Dict, Union, List
from typing import Optional
import uuid
from pathlib import Path

REGISTER_TYPE_HOLDING_REGISTER = "H"
REGISTER_TYPE_INPUT_REGISTER = "I"
REGISTER_TYPE_DISCRETE_INPUT = "D"
REGISTER_TYPE_COILS = "C"

REGISTER_DATATYPE_U16 = "u16"
REGISTER_DATATYPE_I16 = "i16"
REGISTER_DATATYPE_F32 = "f32"
REGISTER_DATATYPE_U32 = "u32"
REGISTER_DATATYPE_I32 = "i32"
REGISTER_DATATYPE_BIT = "BIT"


class appTcpPortInfo:
    """
    A class to represent TCP port information for an application.
    Attributes:
    -----------
    ip_address : str
        The IP address of the TCP port.
    port_number : int
        The port number.
    timeout : int
        The timeout value in milliseconds.
    name : str
        The name associated with the TCP port.
    Methods:
    --------
    to_dict():
        Converts the instance to a dictionary.
    __str__():
        Returns a string representation of the instance.
    __repr__():
        Returns a string representation of the instance.
    __eq__(other):
        Checks if two instances are equal.
    __ne__(other):
        Checks if two instances are not equal.
    from_dict(data):
        Creates an instance from a dictionary.
    """
    KEY_IP_ADDRESS = "ip_address"
    KEY_PORT_NUMBER = "port_number"
    KEY_TIMEOUT = "timeout"
    KEY_NAME = "name"
    KEY_UID = "uid"

    def __init__(self, ip_address:str, port_number:int, timeout:int, name:str, **kwargs):
        # pylint: disable=unused-argument
        self.ip_address = ip_address
        self.port_number = port_number
        self.timeout = timeout
        self.name = name
        self.uid:str = kwargs.get(self.KEY_UID, str(uuid.uuid4()))

    def to_dict(self):
        return {
            appTcpPortInfo.KEY_IP_ADDRESS: self.ip_address,
            appTcpPortInfo.KEY_PORT_NUMBER: self.port_number,
            appTcpPortInfo.KEY_TIMEOUT: self.timeout,
            appTcpPortInfo.KEY_NAME: self.name,
            appTcpPortInfo.KEY_UID: self.uid
        }

    def __str__(self):
        return f"{self.name}: {self.ip_address}:{self.port_number} with timeout {self.timeout} ms"

    def __repr__(self):
        return f"{self.name}: {self.ip_address}:{self.port_number} with timeout {self.timeout} ms"

    def __eq__(self, other):
        if not isinstance(other, appTcpPortInfo):
            return False
        a = self.ip_address == other.ip_address
        b = self.port_number == other.port_number
        c = self.timeout == other.timeout
        d = self.name == other.name
        e = self.uid == other.uid
        return a and b and c and d and e

    def __ne__(self, other):
        return not self.__eq__(other)

    @classmethod
    def from_dict(cls, data):
        if not isinstance(data, dict):
            raise ValueError(f"Input data must be a dictionary, got {type(data).__name__} instead")
        ip_address = data.get(cls.KEY_IP_ADDRESS)
        port_number = data.get(cls.KEY_PORT_NUMBER)
        timeout = data.get(cls.KEY_TIMEOUT)
        name = data.get(cls.KEY_NAME)
        uid  = data.get(cls.KEY_UID)
        if ip_address is None or port_number is None or timeout is None or name is None or uid is None:
            missing_fields = [field for field in
                [cls.KEY_IP_ADDRESS, cls.KEY_PORT_NUMBER, cls.KEY_TIMEOUT, cls.KEY_NAME, cls.KEY_UID]
                if data.get(field) is None
            ]
            raise ValueError(f"Missing required fields in data: {', '.join(missing_fields)}")
        return cls(ip_address, port_number, timeout, name, uid=uid)

class appSerialPortInfo:
    """
    A class to represent serial port information for an application.
    Attributes:
    -----------
    port : str
        The name of the serial port.
    baudrate : int
        The baud rate for the serial communication.
    parity : str
        The parity setting for the serial communication.
    stop_bits : float
        The number of stop bits for the serial communication.
    timeout : int
        The timeout value for the serial communication in milliseconds.
    Methods:
    --------
    to_dict():
        Converts the serial port information to a dictionary.
    __str__():
        Returns a string representation of the serial port information.
    __repr__():
        Returns a string representation of the serial port information.
    __eq__(other):
        Checks if two appSerialPortInfo objects are equal.
    __ne__(other):
        Checks if two appSerialPortInfo objects are not equal.
    from_dict(data):
        Creates an appSerialPortInfo object from a dictionary.
    """
    KEY_PORT_NAME = "port"
    KEY_BAUDRATE = "baudrate"
    KEY_PARITY = "parity"
    KEY_STOP_BITS = "stop_bits"
    KEY_TIMEOUT = "timeout"
    KEY_UID = "uid"
    def __init__(
            self,
            uid:str,
            port:str,
            baudrate:int,
            parity:str,
            stop_bits:float,
            timeout:int,
            **kwargs
        ):
        # pylint: disable=unused-argument
        # pylint: disable=too-many-arguments
        self.port = port
        self.baudrate = baudrate
        self.parity = parity
        self.stop_bits = stop_bits
        self.timeout = timeout
        self.uid:str = uid

    def to_dict(self):
        return {
            appSerialPortInfo.KEY_PORT_NAME: self.port,
            appSerialPortInfo.KEY_BAUDRATE: self.baudrate,
            appSerialPortInfo.KEY_PARITY: self.parity,
            appSerialPortInfo.KEY_STOP_BITS: self.stop_bits,
            appSerialPortInfo.KEY_TIMEOUT: self.timeout,
            appSerialPortInfo.KEY_UID: self.uid
        }

    def __str__(self):
        fmt_str = "{}: {} baudrate, {} parity, {} stop bits with timeout {} ms"
        return fmt_str.format(
            self.port,
            self.baudrate,
            self.parity,
            self.stop_bits,
            self.timeout
        )

    def __repr__(self):
        fmt_str = "{}: {} baudrate, {} parity, {} stop bits with timeout {} ms"
        return fmt_str.format(
            self.port,
            self.baudrate,
            self.parity,
            self.stop_bits,
            self.timeout
        )

    def __eq__(self, other):
        if not isinstance(other, appSerialPortInfo):
            return False
        a = self.port == other.port
        b = self.baudrate == other.baudrate
        c = self.parity == other.parity
        d = self.stop_bits == other.stop_bits
        e = self.timeout == other.timeout
        f = self.uid == other.uid
        return a and b and c and d and e and f

    def __ne__(self, other):
        return not self.__eq__(other)

    @classmethod
    def from_dict(cls, data):
        if not isinstance(data, dict):
            raise ValueError(f"Input data must be a dictionary, got {type(data).__name__} instead")
        port = data.get(cls.KEY_PORT_NAME)
        baudrate = data.get(cls.KEY_BAUDRATE)
        parity = data.get(cls.KEY_PARITY)
        stop_bits = data.get(cls.KEY_STOP_BITS)
        timeout = data.get(cls.KEY_TIMEOUT)
        uid = data.get(cls.KEY_UID)
        bexp = all([port is None, baudrate is None, parity is None, stop_bits is None,
                     timeout is None, uid is None])
        if bexp:
            missing_fields = [
                field for field in
            [cls.KEY_PORT_NAME,cls.KEY_BAUDRATE,cls.KEY_PARITY,cls.KEY_STOP_BITS,cls.KEY_TIMEOUT, cls.KEY_UID]
                if data.get(field) is None
            ]
            raise ValueError(f"Missing required fields in data: {', '.join(missing_fields)}, \
in file {__file__.replace(str(Path.cwd()), '')} at line {inspect.currentframe().f_lineno}")
        retval = cls(uid, port, baudrate, parity, stop_bits, timeout)
        return retval

class LoggingParameter:
    """
    A class to represent a logging parameter.
    Attributes:
    -----------
    NAME : str
        The name of the logging parameter.
    UNIT : str
        The unit of the logging parameter.
    HISTORY_BUFFER_LEN : str
        The history buffer length of the logging parameter.
    Methods:
    --------
    __init__(name, unit, **kwargs):
        Initializes a new instance of the LoggingParameter class.
    __str__():
        Returns a string representation of the LoggingParameter instance.
    to_dict():
        Converts the LoggingParameter instance to a dictionary.
    from_dict(data):
        Creates a LoggingParameter instance from a dictionary.
    __eq__(other):
        Checks if two LoggingParameter instances are equal.
    __ne__(other):
        Checks if two LoggingParameter instances are not equal.
    __repr__():
        Returns a string representation of the LoggingParameter instance.
    """

    KEY_NAME = "name"
    KEY_UNIT = "unit"
    KEY_HISTORY_BUFFER_LEN = "historyBufferLen"
    KEY_CALIBRATION_SCALING_FACTOR = "csf"
    KEY_CALIBRATION_OFFSET_TERM = 'cot'
    KEY_CALIBRATION_DEAD_ZONE = 'cdz'
    KEY_DISPLAY_FORMAT = 'display_format'

    def __init__(self, name:str, unit:str, **kwargs):
        self.name:str = name
        self.unit:str = unit
        self.historyBufferLen:int = kwargs.get(LoggingParameter.KEY_HISTORY_BUFFER_LEN, 1)
        self.csf:float = kwargs.get(LoggingParameter.KEY_CALIBRATION_SCALING_FACTOR, 1.0)
        self.cot:float = kwargs.get(LoggingParameter.KEY_CALIBRATION_OFFSET_TERM, 0)
        self.cdz:float = kwargs.get(LoggingParameter.KEY_CALIBRATION_DEAD_ZONE, 0)
        self.display_format:str = kwargs.get(LoggingParameter.KEY_DISPLAY_FORMAT, "%d")

    def getCalibratedValue(self,val):
        nval = self.csf * val + self.cot
        if abs(nval) < self.cdz:
            nval = 0
        return nval

    def getCalibratedNumberAsString(self, val) -> str:
        retval = ""
        nval = self.getCalibratedValue(val)
        retval = str(nval)
        if self.display_format:
            try:
                retval = self.display_format % nval
            except TypeError:
                retval = str(nval)
        return retval

    def __str__(self):
        return f"{self.name}, {self.unit} (History Buffer Length: {self.historyBufferLen})"

    def to_dict(self):
        return {
            LoggingParameter.KEY_NAME: self.name,
            LoggingParameter.KEY_UNIT: self.unit,
            LoggingParameter.KEY_HISTORY_BUFFER_LEN: self.historyBufferLen,
            LoggingParameter.KEY_CALIBRATION_SCALING_FACTOR: self.csf,
            LoggingParameter.KEY_CALIBRATION_OFFSET_TERM: self.cot,
            LoggingParameter.KEY_CALIBRATION_DEAD_ZONE: self.cdz,
            LoggingParameter.KEY_DISPLAY_FORMAT: self.display_format,
        }

    @classmethod
    def from_dict(cls, data):
        if not isinstance(data, dict):
            fmt = "Input data must be a dictionary, got {} instead in file {} at line {}"
            err_str = fmt.format(type(data).__name__, __file__, inspect.currentframe().f_lineno)
            raise ValueError(err_str)
        name = data.get(cls.KEY_NAME, None)
        unit = data.get(cls.KEY_UNIT, None)
        historyBufferLen = data.get(cls.KEY_HISTORY_BUFFER_LEN, None)
        csf = data.get(cls.KEY_CALIBRATION_SCALING_FACTOR, None)
        cot = data.get(cls.KEY_CALIBRATION_OFFSET_TERM, None)
        cdz = data.get(cls.KEY_CALIBRATION_DEAD_ZONE, None)
        display_formats = data.get(cls.KEY_DISPLAY_FORMAT, None)
        arr = [name, unit, csf, cot, cdz, display_formats]
        for fld in arr:
            if fld is None:
                raise ValueError(f"Got error file parsing {data}")
        retval =  cls(
            name,
            unit,
            historyBufferLen = historyBufferLen,
            csf = csf,
            cot = cot,
            cdz = cdz,
            display_format = display_formats
        )

        return retval

    def __eq__(self, other):
        if not isinstance(other, LoggingParameter):
            return False
        return self.name == other.name and self.unit == other.unit and self.historyBufferLen == other.historyBufferLen

    def __ne__(self, other):
        return not self.__eq__(other)

    def __repr__(self):
        return f"{self.name}, {self.unit} (History Buffer Length: {self.historyBufferLen})"

class Register:
    """
    A class representing a register with various attributes.
    Attributes:
        KEY_ADDRESS (str): The key for the address attribute.
        KEY_VALUE (str): The key for the value attribute.
        KEY_DESCRIPTION (str): The key for the description attribute.
        KEY_LABEL (str): The key for the label attribute.
        KEY_DATATYPE (str): The key for the data type attribute.
        KEY_LOGGING_PARAMETERS (str): The key for the logging parameters attribute.
    Methods:
        __init__(address: int, value: Union[int, bool], description: str = "", label: str = "", **kwargs):
            Initializes a new instance of the Register class.
        to_dict() -> Dict[str, Union[int, bool, str]]:
        from_dict(cls, data: Dict[str, Union[int, bool, str, Dict]]) -> 'Register':
    """
    KEY_ADDRESS = "address"
    KEY_VALUE = "value"
    KEY_DESCRIPTION = "description"
    KEY_LABEL = "label"
    KEY_DATATYPE = "dataType"
    KEY_LOGGING_PARAMETERS = "logging_parameters"
    def __init__(
            self,
            address: int,
            value: Optional[Union[int, bool]] = None,
            description: str = "",
            label: str = "",
            **kwargs
        ):
        self.address: int = address
        self.value: Optional[Union[int, bool]] = value
        self.description: str = description
        self.label: str = label
        self.dataType: str = kwargs.get(Register.KEY_DATATYPE, REGISTER_DATATYPE_U16)
        self.logging_parameters: LoggingParameter = kwargs.get("logging_parameters", LoggingParameter(label, ""))

    def to_dict(self) -> Dict[str, Union[int, bool, str]]:
        """
        Converts the register to a dictionary.

        :return: A dictionary representation of the register.
        """
        return {
            Register.KEY_ADDRESS: self.address,
            Register.KEY_VALUE: self.value,
            Register.KEY_DESCRIPTION: self.description,
            Register.KEY_LABEL: self.label,
            Register.KEY_DATATYPE: self.dataType,
            Register.KEY_LOGGING_PARAMETERS: self.logging_parameters.to_dict()
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Union[int, bool, str, Dict]]) -> 'Register':
        """
        Populates the register from a dictionary.

        :param data: A dictionary containing the register data.
        :return: A Register object.
        """

        if not all(
            key in
            data for key in
            [Register.KEY_ADDRESS,
             Register.KEY_VALUE, Register.KEY_DESCRIPTION,
             Register.KEY_LABEL, Register.KEY_DATATYPE, Register.KEY_LOGGING_PARAMETERS]
        ):
            fmt = "Invalid data format: Missing one or more required keys in the input dictionary (file: {} at line {})"
            raise ValueError(fmt.format(__file__, inspect.currentframe().f_lineno))

        logging_parameters_data = data.get(Register.KEY_LOGGING_PARAMETERS)
        if logging_parameters_data is None:
            fmt = "Missing logging parameters in data (file: {} at line {})"
            raise ValueError(fmt.format(__file__, inspect.currentframe().f_lineno))
        logging_parameters = LoggingParameter.from_dict(logging_parameters_data)

        return cls(
            address=data[Register.KEY_ADDRESS],
            value=data[Register.KEY_VALUE],
            description=data.get(Register.KEY_DESCRIPTION, ""),
            label=data.get(Register.KEY_LABEL, ""),
            dataType=data.get(Register.KEY_DATATYPE, REGISTER_DATATYPE_U16),
            logging_parameters=logging_parameters
        )

    def getCalibratedValue(self):
        return self.logging_parameters.getCalibratedValue(self.value)

class HoldingRegister(Register):
    """
    A class representing a holding register.
    Attributes:
        address (int): The address of the register.
        value (int): The value stored in the register.
        description (str): A brief description of the register. Default is an empty string.
        label (str): A label for the register. Default is an empty string.
    Methods:
        __init__(address: int, value: int, description: str = "", label: str = "", **kwargs):
            Initializes a new instance of the HoldingRegister class.
    """
    def __init__(self, address: int, value: int, description: str = "", label: str = "", **kwargs):
        """
        Initialize a new instance of the HoldingRegister class.

        Args:
            address (int): The address of the register.
            value (int): The value of the register.
            description (str, optional): A description of the register. Defaults to an empty string.
            label (str, optional): A label for the register. Defaults to an empty string.
            **kwargs: Additional keyword arguments.
        """
        # pylint: disable=unused-argument
        super().__init__(address, value, description, label, **kwargs)

class InputRegister(Register):
    """
    InputRegister is a subclass of Register that represents an input register
    with an address, value, description, and label.
    Attributes:
        description (str): A description of the instance. Defaults to an empty string.
        label (str): A label for the instance. Defaults to an empty string.
    Methods:
        __init__(address: int, value: int, description: str = "", label: str = "", **kwargs):
    """
    def __init__(self, address: int, value: int, description: str = "", label: str = "", **kwargs):
        """
        Initialize the instance with the given parameters.

        Args:
            address (int): The address of the instance.
            value (int): The value associated with the instance.
            description (str, optional): A description of the instance. Defaults to an empty string.
            label (str, optional): A label for the instance. Defaults to an empty string.
            **kwargs: Additional keyword arguments.
        """
        # pylint: disable=unused-argument
        super().__init__(address, value, description, label, **kwargs)

class DiscreteInput(Register):
    """
    DiscreteInput is a class that represents a discrete input.
    Attributes:
        dataType (str): The data type of the register, set to REGISTER_DATATYPE_BIT.
    Methods:
        __init__(address: int, value: bool, description: str = "", label: str = "", **kwargs):
    """
    def __init__(self, address: int, value: bool, description: str = "", label: str = "", **kwargs):
        """
        Initialize the instance with the given parameters.

        Args:
            address (int): The address of the register.
            value (bool): The value of the register.
            description (str, optional): A description of the register. Defaults to "".
            label (str, optional): A label for the register. Defaults to "".
            **kwargs: Additional keyword arguments.

        """
        # pylint: disable=unused-argument
        super().__init__(address, value, description, label, **kwargs)
        self.dataType = REGISTER_DATATYPE_BIT

class Coil(Register):
    """
    Represents a Coil.
    A Coil is a type of register that holds a boolean value.
    Attributes:
        dataType (str): The data type of the register, set to REGISTER_DATATYPE_BIT.
    """
    def __init__(self, address: int, value: bool, description: str = "", label: str = "", **kwargs):
        """
        Initialize a new instance of the class.

        Args:
            address (int): The address of the register.
            value (bool): The value of the register.
            description (str, optional): A description of the register. Defaults to an empty string.
            label (str, optional): A label for the register. Defaults to an empty string.
            **kwargs: Additional keyword arguments.

        """
        # pylint: disable=unused-argument
        super().__init__(address, value, description, label, **kwargs)
        self.dataType = REGISTER_DATATYPE_BIT

class RegisterReference:
    def __init__(self, register_type:str, device_address:int, register_address:int):
        self.register_type = register_type
        self.device_address = device_address
        self.register_address = register_address

    def to_dict(self):
        return {
            "type": self.register_type,
            "device_address": self.device_address,
            "register_address": self.register_address
        }

    @classmethod
    def from_dict(cls, data):
        rt = data.get("type")
        da = data.get("device_address")
        ra = data.get("register_address")
        return cls(rt, da, ra)

class MonitorGroup:
    """
    A class to represent a group of monitors.
    Attributes:
    -----------
    KEY_NAME : str
        The key for the name attribute in the dictionary representation.
    KEY_POLL_TIME : str
        The key for the poll time attribute in the dictionary representation.
    KEY_REGISTERS : str
        The key for the registers attribute in the dictionary representation.
    Methods:
    --------
    __init__(self, name: str, **kwargs):
        Initializes a MonitorGroup instance with a name, poll time, and registers.
    __str__(self):
        Returns a string representation of the MonitorGroup instance.
    to_dict(self):
        Converts the MonitorGroup instance to a dictionary.
    from_dict(cls, data):
        Creates a MonitorGroup instance from a dictionary.
    __eq__(self, other):
        Checks if two MonitorGroup instances are equal.
    __ne__(self, other):
        Checks if two MonitorGroup instances are not equal.
    __repr__(self):
        Returns a string representation of the MonitorGroup instance.
    add_register(self, register: Register):
        Adds a register to the MonitorGroup instance.
    remove_register(self, register: Register):
        Removes a register from the MonitorGroup instance.
    """

    KEY_NAME = "name"
    KEY_POLL_TIME = "pollTime"
    KEY_REGISTERS = "registers"

    def __init__(self, name:str, **kwargs):
        """
        Initializes a new instance of the class.

        Args:
            name (str): The name of the instance.
            **kwargs: Additional keyword arguments.
                pollTime (int, optional): The polling time in milliseconds. Defaults to 1000.
                registers (list[Register], optional): A list of Register objects.
                Defaults to an empty list.

        Attributes:
            name (str): The name of the instance.
            pollTime (int): The polling time in milliseconds.
            registers (list[Register]): A list of Register objects.
        """
        self.name:str = name
        self.pollTime:int = kwargs.get("pollTime", 1000)
        self.registers: List[RegisterReference] = kwargs.get("registers", [])

    def __str__(self):
        return f"{self.name} with poll time {self.pollTime} ms"

    def to_dict(self):
        return {
            MonitorGroup.KEY_NAME: self.name,
            MonitorGroup.KEY_POLL_TIME: self.pollTime,
            MonitorGroup.KEY_REGISTERS: [register.to_dict() for register in self.registers]
        }

    @classmethod
    def from_dict(cls, data):
        if not isinstance(data, dict):
            fmt = "Input data must be a dictionary, got {} instead, in file {} at line {}"
            raise ValueError(fmt.format(type(data).__name__, __file__, inspect.currentframe().f_lineno))
        name = data.get(cls.KEY_NAME)
        pollTime = int(data.get(cls.KEY_POLL_TIME))
        registers = data.get(cls.KEY_REGISTERS)
        if name is None or pollTime is None or registers is None:
            missing_fields = [field for field in
                              [cls.KEY_NAME, cls.KEY_POLL_TIME, cls.KEY_REGISTERS]
                              if data.get(field) is None
                            ]
            fmt = "Missing required fields in data: {}, in file {} at line {}"
            err_str = fmt.format(", ".join(missing_fields), __file__, inspect.currentframe().f_lineno)
            raise ValueError(err_str)
        return cls(name, pollTime=pollTime, registers=[RegisterReference.from_dict(register) for register in registers])

    def __eq__(self, other):
        if not isinstance(other, MonitorGroup):
            return False
        return self.name == other.name and self.pollTime == other.pollTime and self.registers == other.registers

    def __ne__(self, other):
        return not self.__eq__(other)

    def __repr__(self):
        return f"{self.name} with poll time {self.pollTime} ms"

    def add_register_reference(self, register_type:str, device_address:int, register_address:int):
        rr = RegisterReference(register_type, device_address, register_address)
        self.registers.append(rr)

class ControlGroup:
    KEY_NAME = "name"
    KEY_REGISTERS = "registers"
    def __init__(self, name:str, **kw):
        # pylint: disable=unused-argument
        self.name:str = name
        self.registers:List[RegisterReference] = kw.get("registers", [])

    def to_dict(self):
        return {
            ControlGroup.KEY_NAME: self.name,
            ControlGroup.KEY_REGISTERS: [register.to_dict() for register in self.registers]
        }

    @classmethod
    def from_dict(cls, data):
        if not isinstance(data, dict):
            fmt = "Input data must be a dictionary, got {} instead, in file {} at line {}"
            raise ValueError(fmt.format(type(data).__name__, __file__, inspect.currentframe().f_lineno))
        name = data.get(cls.KEY_NAME)
        registers = data.get(cls.KEY_REGISTERS)
        if name is None or registers is None:
            missing_fields = [field for field in
                              [cls.KEY_NAME, cls.KEY_REGISTERS]
                              if data.get(field) is None
                            ]
            fmt = "Missing required fields in data: {}, in file {} at line {}"
            err_str = fmt.format(", ".join(missing_fields), __file__, inspect.currentframe().f_lineno)
            raise ValueError(err_str)
        return cls(name, registers=[RegisterReference.from_dict(register) for register in registers])

    def add_register_reference(self, register_type:str, device_address:int, register_address:int):
        rr = RegisterReference(register_type, device_address, register_address)
        self.registers.append(rr)

class ChartDataPoint:
    def __init__(self, x, y, ts):
        self.x = x
        self.y = y
        self.timestamp = ts


ANY_MODBUS_MEM_T = Union[Register, HoldingRegister, InputRegister, DiscreteInput, Coil]
ANY_MODBUS_MEM_LIST_T = List[Union[Register, HoldingRegister, InputRegister, DiscreteInput, Coil]]
