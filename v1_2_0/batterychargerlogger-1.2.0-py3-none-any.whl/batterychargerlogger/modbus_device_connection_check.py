import time 
from typing import List
import datetime
import logging
import threading
from .usergui.checkModbusDeviceConnectivity import ModbusDeviceConectivityCheckDialog
from .mbDeviceConfig import ModbusDeviceConfig
from .modbus_master_server import ModbusTransactionToken
from .modbus_master_server import ModbusMasterServer
from .modbus_master_server import DEVICE_NO_ERROR

UNKNOWN = 0
CONNECTED = 1
DISCONNECTED = 2

class ModbusDeviceConectivityCheckGui(ModbusDeviceConectivityCheckDialog):
    # pylint: disable=too-many-ancestors
    def __init__(self, parent, device_list:List[ModbusDeviceConfig]):
        super().__init__(parent)
        self.device_list = device_list
        self.m_grid1.DeleteRows(0, self.m_grid1.GetNumberRows())
        for i, device in enumerate(self.device_list):
            self.m_grid1.AppendRows(1)
            device.connect_status = UNKNOWN
        self._update_gui_with_value()

    def _update_gui_with_value(self):
        self.m_grid1.Freeze()
        for i, device in enumerate(self.device_list):
            self.m_grid1.SetCellValue(i, 0, str(device.device_address))
            if device.connect_status == CONNECTED:
                self.m_grid1.SetCellValue(i, 1, "connected")
            elif device.connect_status == DISCONNECTED:
                self.m_grid1.SetCellValue(i, 1, "disconnected")
            else:
                self.m_grid1.SetCellValue(i, 1, "")
        self.m_grid1.Thaw()

    def _refresh_all(self, event):
        for i, device in enumerate(self.device_list):
            device.connect_status = UNKNOWN
        self._update_gui_with_value()
        thread = threading.Thread(target=self._refresh_all_device_status)
        thread.start()

    def _refresh_all_device_status(self):
        for i, device in enumerate(self.device_list):
            time.sleep(0.5)
            device.connect_status = UNKNOWN
            ts = datetime.datetime.now().timestamp()
            tid = int(ts) << 32 | i
            token = ModbusTransactionToken(
                tid=tid, 
                timestamp=ts,
                device_info = device,
                transactionCompleteSemaphore=threading.Event()
            )
            token.read_or_write = ModbusTransactionToken.OPERATION_ID
            ModbusMasterServer.add_transaction(token)
            logging.info("sent transaction ID: %d", tid)
            semwait = token.transactionCompleteSemaphore.wait(timeout=3.0)
            if semwait is True:
                if token.errorResponse == DEVICE_NO_ERROR:
                    device.connect_status = CONNECTED
                else:
                    device.connect_status = DISCONNECTED
            
            self._update_gui_with_value()