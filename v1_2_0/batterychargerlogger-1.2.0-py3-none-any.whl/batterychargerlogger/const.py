SETUP_JSON_FILE_NAME = 'setup.json'
SCHEME_JSON_FILE_NAME = 'schema.json'
