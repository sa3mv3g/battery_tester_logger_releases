import queue
import threading
import logging
from typing import Optional
from typing import List
from typing import Tuple
import pymodbus
from pymodbus.client.serial import ModbusSerialClient
import pymodbus.exceptions
from .common import HoldingRegister
from .common import InputRegister
from .common import DiscreteInput
from .common import Coil
from .mbDeviceConfig import ModbusDeviceConfig
from .common import ANY_MODBUS_MEM_T

DEVICE_NO_ERROR = 0
DEVICE_DISCONNECT_ERROR = 1
DEVICE_INTERNAL_COMM_ERROR = 2

class ModbusTransactionToken:
# pylint: disable=too-many-instance-attributes
    STATE_INIT = 0
    STATE_WAITING = 1
    STATE_COMPLETED = 2
    OPERATION_READ = 0
    OPERATION_WRITE = 1
    OPERATION_ID = 3

    def __init__(
            self, tid: int, timestamp: float,
            starting_address: int = 0,
            request_length:int = 1,
            register_type: ANY_MODBUS_MEM_T = HoldingRegister(0,0),
            device_info: Optional[ModbusDeviceConfig] = None,
            transactionCompleteSemaphore: Optional[threading.Event] = None
        ):
        # pylint: disable=too-many-arguments
        self.tid:int = tid
        self.timestamp:float = timestamp
        self.read_or_write:int = ModbusTransactionToken.OPERATION_READ
        self.starting_address: int = starting_address
        self.request_length:int = request_length
        self.register_type:ANY_MODBUS_MEM_T = register_type
        self.modbus_device: ModbusDeviceConfig = device_info
        self.response = None
        self.state:int = ModbusTransactionToken.STATE_INIT
        self.transactionCompleteSemaphore = transactionCompleteSemaphore
        self.errorResponse = None

class ModbusMasterServer:
    """
    This class will act as a server which will recieve
    all transaction token and based on those tokens, this
    will send transactions either to serial port or to TCP
    port.

    This class performs transaction in asynchronous way in
    respect to the main thread. This will make sure that the
    main thread is not blocked by the transaction.

    This class has a transfer queue in which applicaiton will
    populate all the transaction in this queue.

    All the responses from the physical device will be placed
    in the reciever queue. Application should query from this
    queue to see if it has recieved the response that it has
    requested.
    """

    transfer_queue = queue.Queue()

    def __init__(self, app_close_event: threading.Event):
        self.app_close_event = app_close_event

    @staticmethod
    def add_transaction(token:ModbusTransactionToken):
        """
        This method will add the transaction token to the transfer queue.
        """
        ModbusMasterServer.transfer_queue.put(token)

    def run(self):
        # pylint: disable=too-many-statements
        """
        This method will run the server and will keep on processing
        the transaction from the transfer queue.
        """
        def _read_from_rtu_device(token:ModbusTransactionToken) -> Tuple[Optional[List[int]], int]:
        # pylint: disable=too-many-statements

            def read_rtu_device(_token:ModbusTransactionToken):
                # pylint: disable=too-many-branches
                retval = None
                errorVal = DEVICE_NO_ERROR
                if isinstance(_token.register_type, HoldingRegister) is True:
                    retry = 3
                    while retry > 0:
                        response =\
                            client.read_holding_registers(
                                _token.starting_address,
                                _token.request_length,
                                slave=_token.modbus_device.device_address
                            )
                        # Check if response is valid and put it in the receiver queue
                        if response and not response.isError():
                            errorVal = DEVICE_NO_ERROR
                            retval = response.registers
                            break
                        else:
                            errorVal = DEVICE_INTERNAL_COMM_ERROR
                            logging.error("Error in transaction ID: %d, retry: %d", token.tid, retry)
                            retry -= 1
                elif isinstance(_token.register_type, Coil) is True: 
                    retry = 3
                    while retry > 0:
                        response =\
                            client.read_coils(
                                _token.starting_address,
                                _token.request_length,
                                slave=_token.modbus_device.device_address
                            )
                        # Check if response is valid and put it in the receiver queue
                        if response and not response.isError():
                            errorVal = DEVICE_NO_ERROR
                            retval = response.bits
                            break
                        else:
                            errorVal = DEVICE_INTERNAL_COMM_ERROR
                            logging.error("Error in transaction ID: %d", token.tid)
                            retry -= 1
                elif isinstance(_token.register_type, InputRegister) is True:
                    retry = 3
                    while retry > 0:
                        response =\
                            client.read_input_registers(
                                _token.starting_address,
                                _token.request_length,
                                slave=_token.modbus_device.device_address
                            )
                        # Check if response is valid and put it in the receiver queue
                        if response and not response.isError():
                            errorVal = DEVICE_NO_ERROR
                            retval = response.registers
                            break
                        else:
                            errorVal = DEVICE_INTERNAL_COMM_ERROR
                            logging.error("Error in transaction ID: %d", token.tid)
                            retry -= 1
                elif isinstance(_token.register_type, DiscreteInput)is True:
                    retry = 3
                    while retry > 0:
                        response =\
                            client.read_discrete_inputs(
                                _token.starting_address,
                                _token.request_length,
                                slave=_token.modbus_device.device_address
                            )
                        # Check if response is valid and put it in the receiver queue
                        if response and not response.isError():
                            errorVal = DEVICE_NO_ERROR
                            retval = response.bits
                            break
                        else:
                            errorVal = DEVICE_INTERNAL_COMM_ERROR
                            logging.error("Error in transaction ID: %d", token.tid)
                            retry -= 1
                else:
                    raise TypeError(f"Unsupported register type for transaction ID: {token.tid}")
                return (retval, errorVal)

            def write_rtu_device(_token:ModbusTransactionToken) -> Tuple[Optional[List[int]], int]:
                # Send the transaction
                retval = None
                errorVal = DEVICE_NO_ERROR
                reg = _token.register_type
                if isinstance(reg, HoldingRegister)is True:
                    response =\
                        client.write_registers(reg.address, reg.value, slave=token.modbus_device.device_address)
                    if response and not response.isError():
                        retval = response
                    else:
                        errorVal = DEVICE_INTERNAL_COMM_ERROR
                        logging.error("Error in transaction ID: %d", token.tid)
                elif isinstance(reg, Coil)is True:
                    response =\
                        client.write_coils(reg.address, reg.value, slave=token.modbus_device.device_address)
                    if response and not response.isError():
                        retval = response
                    else:
                        errorVal = DEVICE_INTERNAL_COMM_ERROR
                        logging.error("Error in transaction ID: %d", token.tid)
                else:
                    raise TypeError(f"Unsupported register type for transaction ID: {token.tid}")
                return (retval, errorVal)

            def get_rtu_device_id(_token:ModbusTransactionToken) -> Tuple[Optional[List[int]], int]:
                req = client.report_slave_id(slave=_token.modbus_device.device_address)
                if req and not req.isError():
                    return (req.slave_id, DEVICE_NO_ERROR)
                else:
                    return (None, DEVICE_INTERNAL_COMM_ERROR)

            # Configure the serial client
            client = ModbusSerialClient(
                method='rtu',
                port=token.modbus_device.interface_config['port'],
                baudrate=token.modbus_device.interface_config['baudrate'],
                timeout=token.modbus_device.interface_config['timeout'] / 1000
            )

            retval: Optional[List[int]] = None
            errCode: int = DEVICE_NO_ERROR

            # Connect to the client
            if client.connect():
                try:
                    if token.read_or_write is ModbusTransactionToken.OPERATION_WRITE:
                        retval, errCode = write_rtu_device(token)
                    elif token.read_or_write is ModbusTransactionToken.OPERATION_READ:
                        retval, errCode = read_rtu_device(token)
                    elif token.read_or_write is ModbusTransactionToken.OPERATION_ID:
                        retval, errCode = get_rtu_device_id(token)
                except pymodbus.ModbusException as modbus_exception:
                    logging.error("Got error: %s", modbus_exception)
                    retval = None
                    errCode = DEVICE_INTERNAL_COMM_ERROR

                # Close the client connection
                client.close()
            else:
                errCode = DEVICE_DISCONNECT_ERROR
                logging.error("Failed to connect to serial port: %s",
                              token.modbus_device.interface_config['port'])

            return (retval, errCode)

        while True:
            if self.app_close_event.is_set():
                break
            try:
                token:ModbusTransactionToken = self.transfer_queue.get(block=True, timeout=0.1)
            except queue.Empty:
                continue

            modbus_resp = None
            err_resp = None

            if token.modbus_device.interface_type == ModbusDeviceConfig.INTERFACE_TYPE_RTU:
                modbus_resp, err_resp = _read_from_rtu_device(token)

            token.state = ModbusTransactionToken.STATE_COMPLETED
            token.response = modbus_resp
            token.errorResponse = err_resp
            if token.transactionCompleteSemaphore:
                token.transactionCompleteSemaphore.set()
