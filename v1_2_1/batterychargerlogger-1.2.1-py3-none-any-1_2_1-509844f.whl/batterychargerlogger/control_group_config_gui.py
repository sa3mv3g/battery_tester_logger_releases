from typing import Optional, List
import wx
from .common import ControlGroup
from .common import RegisterReference
from .common import HoldingRegister
from .common import InputRegister
from .common import DiscreteInput
from .common import Coil
from .common import Register
from .common import REGISTER_TYPE_HOLDING_REGISTER
from .common import REGISTER_TYPE_INPUT_REGISTER
from .common import REGISTER_TYPE_DISCRETE_INPUT
from .common import REGISTER_TYPE_COILS
from .mbDeviceConfig import ModbusDeviceConfig
from .usergui.control_group_config import ControlGroupConfigDialog


class ControlGroupConfigGui(ControlGroupConfigDialog):
    # pylint: disable=too-many-ancestors

    def __init__(self, parent: wx.Window, control_group: ControlGroup, modbus_device_list: List[ModbusDeviceConfig]):
        super().__init__(parent)
        if control_group is None:
            wx.LogError("Monitor group is not provided.")
            self.Destroy()
        self.control_group_config:ControlGroup = control_group
        self.modbus_device_list:List[ModbusDeviceConfig] = modbus_device_list
        self._refresh_all()

    def _refresh_all(self):
        self.m_textCtrl1.SetValue(self.control_group_config.name)
        self._populate_tree_ctrls()
        self._update_wx_grid()

    def _populate_tree_ctrls(self):
        """
        """
        # pylint: disable=unused-argument
        # pylint: disable=too-many-locals
        if not self.modbus_device_list:
            wx.LogError("No Modbus device information available.")
            return
        self.m_treeCtrl1.DeleteAllItems()
        root = self.m_treeCtrl1.AddRoot("Modbus Devices")
        for device in self.modbus_device_list:
            device_item = self.m_treeCtrl1.AppendItem(
                root, f"{device.device_name} ({device.device_address})")
            holding_registers = self.m_treeCtrl1.AppendItem(
                device_item, "Holding Registers")
            self.m_treeCtrl1.SetItemData(holding_registers, device)
            for address, register in device.holding_registers.items():
                hr = self.m_treeCtrl1.AppendItem(holding_registers,
                        f"[{address}] {register.label} ({register.dataType})")
                self.m_treeCtrl1.SetItemData(hr, register)

            input_registers = self.m_treeCtrl1.AppendItem(
                device_item, "Input Registers")
            self.m_treeCtrl1.SetItemData(input_registers, device)
            for address, register in device.input_registers.items():
                ir = self.m_treeCtrl1.AppendItem(input_registers,
                    f"[{address}] {register.label} ({register.dataType})")
                self.m_treeCtrl1.SetItemData(ir, register)

            discrete_inputs = self.m_treeCtrl1.AppendItem(
                device_item, "Discrete Inputs")
            self.m_treeCtrl1.SetItemData(discrete_inputs, device)
            for address, di in device.discrete_inputs.items():
                dic = self.m_treeCtrl1.AppendItem(discrete_inputs,
                    f"[{address}] {di.label}")
                self.m_treeCtrl1.SetItemData(dic, di)

            coils = self.m_treeCtrl1.AppendItem(
                device_item, "Coils")
            self.m_treeCtrl1.SetItemData(coils, device)
            for address, coil in device.coils.items():
                ci = self.m_treeCtrl1.AppendItem(coils,
                    f"[{address}] {coil.label}")
                self.m_treeCtrl1.SetItemData(ci, coil)

        self.m_treeCtrl1.ExpandAll()

    def _evt_on_item_selected(self, event=None):
        """
        Event handler to add the selected item to the monitor group.

        This method is triggered when an item is selected in the tree control.
        It retrieves the selected item, checks if it is an instance of
        `Register`, and if it is not already in the `control_group_config.registers`
        list, it adds the item to the list. Finally, it updates the
        wxPython grid to reflect the changes.

        Args:
            event (wx.Event, optional): The event object. Defaults to None.
        """
        # pylint: disable=unused-argument
        item = self.m_treeCtrl1.GetSelection()
        paren = self.m_treeCtrl1.GetItemParent(item)
        if item:
            itemData:any = self.m_treeCtrl1.GetItemData(item)
            device:any = self.m_treeCtrl1.GetItemData(paren)
            if isinstance(device, ModbusDeviceConfig) :
                if itemData not in self.control_group_config.registers:
                    reg_signature:Optional[RegisterReference] = None
                    register_type: Optional[str] = None
                    if isinstance(itemData, HoldingRegister):
                        register_type = REGISTER_TYPE_HOLDING_REGISTER
                    elif isinstance(itemData, InputRegister):
                        register_type = REGISTER_TYPE_INPUT_REGISTER
                    elif isinstance(itemData, DiscreteInput):
                        register_type = REGISTER_TYPE_DISCRETE_INPUT
                    elif isinstance(itemData, Coil):
                        register_type = REGISTER_TYPE_COILS
                    if register_type is not None:
                        reg_signature = RegisterReference(
                            register_type,
                            device.device_address,
                            itemData.address
                        )
                        self.control_group_config.registers.append(reg_signature)
                    self._update_wx_grid()

    def _update_wx_grid(self):
        """
        Updates the wxGrid with the monitor group configuration registers.

        This method clears the existing rows in the wxGrid and populates it
        with the registers from the monitor group configuration. Each
        register's details such as address, label, data type, description,
        logging parameter name, unit, and history buffer length are set in the grid cells.

        Returns:
            None
        """
        def _get_item_by_key(array_of_dicts:List[ModbusDeviceConfig], addr) -> Optional[ModbusDeviceConfig]:
            """
            Gets the first item from an array of dictionaries where a key matches.

            Args:
                array_of_dicts: The array of dictionaries.
                key_to_find: The key to search for.

            Returns:
                The first matching dictionary, or None if not found.
            """
            for item in array_of_dicts:
                if item.device_address is addr:
                    return item
            return None
        if self.control_group_config.registers is None:
            return
        if len(self.control_group_config.registers) == 0:
            return
        self.m_grid1.ClearGrid()
        # delete all rows
        if self.m_grid1.GetNumberRows() > 0:
            self.m_grid1.DeleteRows(0, self.m_grid1.GetNumberRows())
        # start adding new rows
        for i, rs in enumerate(self.control_group_config.registers):
            register:Optional[Register] = None
            device:ModbusDeviceConfig = _get_item_by_key(self.modbus_device_list, rs.device_address)
            if rs.register_type is REGISTER_TYPE_DISCRETE_INPUT:
                register = device.discrete_inputs[rs.register_address]
            elif rs.register_type is REGISTER_TYPE_COILS:
                register = device.coils[rs.register_address]
            elif rs.register_type is REGISTER_TYPE_HOLDING_REGISTER:
                register = device.holding_registers[rs.register_address]
            elif rs.register_type is REGISTER_TYPE_INPUT_REGISTER:
                register = device.input_registers[rs.register_address]
            if register is not None:
                self.m_grid1.AppendRows(1)
                self.m_grid1.SetCellValue(i, 0, str(device.device_address))
                self.m_grid1.SetCellValue(i, 1, rs.register_type + str(register.address))
                self.m_grid1.SetCellValue(i, 2, str(register.label))
                self.m_grid1.SetCellValue(i, 3, str(register.dataType))
                self.m_grid1.SetCellValue(i, 4, str(register.description))

    def _evt_on_delete_selection( self, event ):
        """
        Event handler to delete the selected item from the monitor group.

        This method is triggered when the user clicks the "Delete Selection"
        button. It retrieves the selected row from the wxGrid, and if the row
        is not empty, it removes the corresponding register from the
        `control_group_config.registers` list. Finally, it updates the wxGrid
        to reflect the changes.

        Args:
            event (wx.Event): The event object.
        """
        # pylint: disable=unused-argument
        selected_rows = self.m_grid1.GetSelectedRows()
        if len(selected_rows) == 0:
            return
        for row in selected_rows:
            if row < len(self.control_group_config.registers):
                self.control_group_config.registers.pop(row)
        self._update_wx_grid()

    def _evt_on_done( self, event ):
        self.control_group_config.name = self.m_textCtrl1.GetValue()
        self.Destroy()

    def _evt_on_cancel( self, event ):
        self.Destroy()
