"""
app.py
This module contains the main application class for managing and configuring Modbus devices,
serial ports, TCP ports, and monitor groups. It provides methods for adding, removing, and
updating configurations, as well as saving and loading configurations from JSON files.

Classes:
    Application:
        Represents the main application for managing and configuring Modbus devices,
        serial ports, TCP ports, and monitor groups.
    Application.fileContents:
        Represents the contents of the current file, including Modbus device configurations, serial ports,
        TCP ports, and monitor groups.
Functions:
    main(): The main entry point for the application. Configures logging,
        ensures necessary directories exist, loads JSON schema and setup file, and starts the application.
"""

import os
import json
import typing
import ctypes
import logging
import threading
import jsonschema
import wx
import matplotlib
from .common import appSerialPortInfo
from .common import appTcpPortInfo
from .common import MonitorGroup
from .mbDeviceConfig import ModbusDeviceConfig
from .usergui.userstart import user_start
from .modbus_device_config_gui import ModbusDeviceConfigGui
from .serial_port_config_gui import SerialPortConfigGui
from .tcp_port_config_gui import TcpPortConfigGui
from .monitor_group_config_gui import MonitorGroupConfigGui
from .monitor_window_gui import MonitorWindowGui
from .modbus_master_server import ModbusMasterServer
from .common import ControlGroup
from .control_group_config_gui import ControlGroupConfigGui
from .control_window_gui import RegisterControlGroupGui
from .modbus_device_connection_check import ModbusDeviceConectivityCheckGui

try:
    ctypes.windll.shcore.SetProcessDpiAwareness(True)
except (OSError, ctypes.ArgumentError) as e:
    print(f"Error setting DPI awareness: {e}")

matplotlib.use('WXAgg')

class Application(user_start): # pylint: disable=too-many-ancestors, too-many-instance-attributes
    """
    The Application class represents the main application for managing and configuring
    Modbus devices, serial ports, TCP ports, and monitor groups. It provides methods
    for adding, removing, and updating configurations, as well as saving and loading
    configurations from JSON files.
    Attributes:
        current_file (typing.Optional[typing.IO]): The currently open file object.
        current_file_name (str): The name of the currently open file.
        current_file_content (Application.fileContents): The content of the currently open file.
        modbus_device_config (typing.List[ModbusDeviceConfig]): List of Modbus device configurations.
        serialPorts (typing.List[typing.Dict]): List of serial port configurations.
        tcpPorts (typing.List[typing.Dict]): List of TCP port configurations.
    Methods:
        __init__(self, parent): Initializes the application with the given parent.
        evt_save_new_serial_port(self, event): Handles the event of saving a new serial port configuration.
        evt_save_new_tcp_port(self, event): Handles the event of saving a new TCP port configuration.
        update_current_file_name(self, filename: str) -> None: Updates the current file name and sets the status text.
        populate_tree_ctrl(self): Populates the tree control with the current file content.
        evt_on_dialog_close(self, event): Handles the close event for the application.
        evt_create_new_file(self, event): Opens a file dialog to create a new JSON file.
        evt_open_app_file(self, event): Handles the event of opening a new application file.
        evt_save_app_file(self, event): Saves the current file content to the file.
        evt_get_new_modbus_device_config(self, event): Opens a dialog to configure a new Modbus device.
        evt_open_monitor_group_dialog(self, event): Opens a dialog to configure a new monitor group.
        evt_show_details(self, event): Updates the properties of the selected device in the tree control.
        evt_startMonitoring(self, event): Starts monitoring for the selected monitor group.
    """
    class fileContents:
        def __init__(self):
            self.modbusDeviceConfig: typing.List[ModbusDeviceConfig] = []
            self.serialPorts: typing.List[appSerialPortInfo] = []
            self.tcpPorts: typing.List[appTcpPortInfo] = []
            self.monitorGroups: typing.List[MonitorGroup] = []
            self.controlGroups: typing.List[ControlGroup] = []

        def addModbusDevice(self, device):
            self.modbusDeviceConfig.append(device)

        def addSerialPort(self, port:appSerialPortInfo):
            a = hasattr(port, appSerialPortInfo.KEY_PARITY)
            b = hasattr(port, appSerialPortInfo.KEY_BAUDRATE)
            c = hasattr(port, appSerialPortInfo.KEY_PORT_NAME)
            d = hasattr(port, appSerialPortInfo.KEY_STOP_BITS)
            if a and b and c and d:
                self.serialPorts.append(port)
            else:
                wx.LogError("Serial port configuration is missing required fields.")

        def addTCPPort(self, port:appTcpPortInfo):
            if all(hasattr(port, attr) for attr in ['portName', 'ipAddress', 'portNumber']):
                self.tcpPorts.append(port)
            else:
                wx.LogError("TCP port configuration is missing required fields.")

        def removeModbusDevice(self, deviceAddress):
            index = next((i for i, device in\
                          enumerate(self.modbusDeviceConfig) if device.device_address == deviceAddress), None)
            if index is not None:
                self.modbusDeviceConfig.pop(index)

        def removeSerialPort(self, uid):
            index = None
            for i, port in enumerate(self.serialPorts):
                if port.uid == uid:
                    index = i
            if index is not None:
                self.serialPorts.pop(index)

        def removeTCPPort(self, uid):
            index = None
            for i, port in enumerate(self.tcpPorts):
                if port.uid == uid:
                    index = i
            if index is not None:
                self.tcpPorts.pop(index)

        def addMonitorGroup(self, group: MonitorGroup):
            """
            Adds a monitor group to the file contents.

            Args:
            group (MonitorGroup): The monitor group to be added.
            """
            self.monitorGroups.append(group)

        def removeMonitorGroup(self, groupName: str):
            """
            Removes a monitor group from the file contents by its name.

            Args:
            groupName (str): The name of the monitor group to be removed.
            """
            index = next((i for i, group in enumerate(self.monitorGroups) if group.name == groupName), None)
            if index is not None:
                self.monitorGroups.pop(index)

        def addControlGroup(self, group:ControlGroup):
            self.controlGroups.append(group)

        def removeControlGroup(self, groupName:str):
            index = next((i for i, group in enumerate(self.controlGroups) if group.name == groupName), None)
            if index is not None:
                self.controlGroups.pop(index)

        def is_empty(self):
            return len(self.modbusDeviceConfig) == 0 and len(self.serialPorts) == 0\
                and len(self.tcpPorts) == 0 and len(self.monitorGroups) == 0 \
                and len(self.controlGroups) == 0

        def to_dict(self):
            return {
                'modbusDeviceConfig': [device.to_dict() for device in self.modbusDeviceConfig],
                'serialPorts': [port.to_dict() for port in self.serialPorts],
                'tcpPorts': [port.to_dict() for port in self.tcpPorts],
                'monitorGroups': [group.to_dict() for group in self.monitorGroups],
                'controlGroups': [group.to_dict() for group in self.controlGroups]
            }

        def from_dict(self, data):
            if not isinstance(data, dict):
                raise ValueError(f"Input data must be a dictionary, got {type(data).__name__} instead")
            modbusDeviceConfig = data.get('modbusDeviceConfig')
            serialPorts = data.get('serialPorts')
            tcpPorts = data.get('tcpPorts')
            monitorGroups = data.get('monitorGroups')
            controlGroups = data.get('controlGroups')
            if modbusDeviceConfig is None or serialPorts is None or tcpPorts is None or \
                monitorGroups is None or controlGroups is None:
                missing_fields = [field for field in ['modbusDeviceConfig', 'serialPorts', 'tcpPorts',\
                                    'monitorGroups', "controlGroups"] if data.get(field) is None]
                raise ValueError(f"Missing required fields in data: {', '.join(missing_fields)}")
            self.modbusDeviceConfig = [ModbusDeviceConfig.from_dict(device) for device in modbusDeviceConfig]
            self.serialPorts = [appSerialPortInfo.from_dict(port) for port in serialPorts]
            self.tcpPorts = [appTcpPortInfo.from_dict(port) for port in tcpPorts]
            self.monitorGroups = [MonitorGroup.from_dict(group) for group in monitorGroups]
            self.controlGroups = [ControlGroup.from_dict(group) for group in controlGroups]

    def __init__(self, parent, app_close_sem:threading.Event):
        super().__init__(parent)
        self.current_file: typing.Optional[typing.IO] = None
        self.current_file_name: str = ""
        self.current_file_content: Application.fileContents = Application.fileContents()
        self.modbus_device_config: typing.List[ModbusDeviceConfig] = self.current_file_content.modbusDeviceConfig
        self.serialPorts: typing.List[typing.Dict] = self.current_file_content.serialPorts
        self.tcpPorts: typing.List[typing.Dict] = self.current_file_content.tcpPorts
        self.app_close_sem:threading.Event = app_close_sem
        self.monitor_window_count:int  = 0

        self.update_current_file_name(self.current_file_name)

    def evt_save_new_serial_port(self, event):
        """
        Handles the event of saving a new serial port configuration.

        This method opens a dialog for the user to input the serial port configuration.
        If the user provides a valid configuration, it stores the configuration in the current file content.

        Args:
            event: The event that triggered this method.
        """
        # pylint: disable=unused-argument
        dialog = SerialPortConfigGui(self)
        dialog.ShowModal()
        if dialog.serial_port_config:
            self.current_file_content.addSerialPort(dialog.serial_port_config)
            self.populate_tree_ctrl()

    def evt_save_new_tcp_port(self, event):
        """
        Handles the event of saving a new TCP port configuration.

        This method opens a dialog for the user to input the TCP port configuration.
        If the user provides a valid configuration, it stores the configuration in the current file content.

        Args:
            event: The event that triggered this method.
        """
        # pylint: disable=unused-argument
        dialog = TcpPortConfigGui(self)
        dialog.ShowModal()
        if dialog.tcp_port_config:
            self.current_file_content.addTCPPort(dialog.tcp_port_config)
            self.populate_tree_ctrl()

    def update_current_file_name(self, filename: str) -> None:
        """
        Updates the current file name and sets the status text.

        Args:
            filename (str): The new file name to be set.

        Returns:
            None
        """
        self.current_file_name = filename
        self.SetStatusText(f"Current File: {filename}")

    def populate_tree_ctrl(self):
        # pylint: disable=too-many-locals
        self.m_treeCtrl2.DeleteAllItems()
        root = self.m_treeCtrl2.AddRoot(self.current_file_name)
        tmp_tag = self.m_treeCtrl2.AppendItem(root, "Modbus Device")
        for i, modbus_device in enumerate(self.current_file_content.modbusDeviceConfig):
            device = self.m_treeCtrl2.AppendItem(tmp_tag,
                                f"{i+1}:{modbus_device.device_name}-{modbus_device.device_address}")
            self.m_treeCtrl2.SetItemData(device, modbus_device)

            holding_registers = self.m_treeCtrl2.AppendItem(device, "Holding Registers")
            for address, register in modbus_device.holding_registers.items():
                hr = self.m_treeCtrl2.AppendItem(holding_registers,
                                f"[{address}] {register.label}, {register.dataType}")
                self.m_treeCtrl2.SetItemData(hr, register)

            input_registers = self.m_treeCtrl2.AppendItem(device, "Input Registers")
            for address, register in modbus_device.input_registers.items():
                ir = self.m_treeCtrl2.AppendItem(input_registers, f"[{address}] {register.label}, {register.dataType}")
                self.m_treeCtrl2.SetItemData(ir, register)

            coils = self.m_treeCtrl2.AppendItem(device, "Coils")
            for address, coil in modbus_device.coils.items():
                cl = self.m_treeCtrl2.AppendItem(coils, f"[{address}] {coil.label}")
                self.m_treeCtrl2.SetItemData(cl, coil)

            discrete_inputs = self.m_treeCtrl2.AppendItem(device, "Discrete Inputs")
            for address, di in modbus_device.discrete_inputs.items():
                dic = self.m_treeCtrl2.AppendItem(discrete_inputs, f"[{address}] {di.label}")
                self.m_treeCtrl2.SetItemData(dic, di)

        tmp_tag = self.m_treeCtrl2.AppendItem(root, "Serial Ports")
        for i, serial_port in enumerate(self.current_file_content.serialPorts):
            display_str = "{}: {}, {}, {}"
            display_str = display_str.format(
                serial_port.port,
                serial_port.baudrate,
                serial_port.parity,
                serial_port.stop_bits
            )
            port = self.m_treeCtrl2.AppendItem(tmp_tag, display_str)
            self.m_treeCtrl2.SetItemData(port, serial_port)

        tmp_tag = self.m_treeCtrl2.AppendItem(root, "TCP Ports")
        for i, tcp_port in enumerate(self.current_file_content.tcpPorts):
            display_str = "{}:{}:{}"
            display_str = display_str.format(
                i+1,
                tcp_port.ip_address,
                tcp_port.port_number
            )
            port = self.m_treeCtrl2.AppendItem(tmp_tag, display_str)
            self.m_treeCtrl2.SetItemData(port, tcp_port)

        tmp_tag = self.m_treeCtrl2.AppendItem(root, "Monitor Groups")
        for i, monitor_group in enumerate(self.current_file_content.monitorGroups):
            group = self.m_treeCtrl2.AppendItem(tmp_tag, f"{monitor_group.name}")
            self.m_treeCtrl2.SetItemData(group, monitor_group)

        tmp_tag = self.m_treeCtrl2.AppendItem(root, "Control Groups")
        for i, ctrl_group in enumerate(self.current_file_content.controlGroups):
            grp = self.m_treeCtrl2.AppendItem(tmp_tag, f"{ctrl_group.name}")
            self.m_treeCtrl2.SetItemData(grp, ctrl_group)

        self.m_treeCtrl2.ExpandAll()

        self.m_monitor_group_tree.DeleteAllItems()
        monitor_root = self.m_monitor_group_tree.AddRoot("Monitor Groups")
        for i, monitor_group in enumerate(self.current_file_content.monitorGroups):
            group = self.m_monitor_group_tree.AppendItem(monitor_root, f"{monitor_group.name}")
            self.m_monitor_group_tree.SetItemData(group, monitor_group)
        self.m_monitor_group_tree.ExpandAll()

        self.m_control_groups_tree.DeleteAllItems()
        control_root = self.m_control_groups_tree.AddRoot("Control Groups")
        for i, control_group in enumerate(self.current_file_content.controlGroups):
            group = self.m_control_groups_tree.AppendItem(control_root, f"{control_group.name}")
            self.m_control_groups_tree.SetItemData(group, control_group)
        self.m_control_groups_tree.ExpandAll()

    def evt_on_dialog_close(self, event):
        """
        Handles the close event for the application.

        This method is called when the application is about to close. It ensures that
        the current file, if open, is properly closed before proceeding with the
        default close event handling.

        Args:
            event: The event object containing information about the close event.
        """
        if self.current_file:
            self.current_file.close()
        self.app_close_sem.set()
        return super().evt_on_dialog_close(event)

    def evt_create_new_file(self, event):
        """
        Opens a file dialog to create a new JSON file. If the user cancels the dialog, the method returns.
        If a file is successfully created, it updates the current file name and stores the file object for later use.
        Args:
            event: The event that triggered the method.
        Raises:
            wx.LogError: If the file cannot be created at the specified location.
        """
        # pylint: disable=unused-argument
        while True:
            with wx.FileDialog(self, "Save JSON file", wildcard="JSON files (*.json)|*.json",
                       style=wx.FD_SAVE | wx.FD_OVERWRITE_PROMPT) as fileDialog:
                if fileDialog.ShowModal() == wx.ID_CANCEL:
                    return

                ## Proceed saving the file chosen by the user
                pathname = fileDialog.GetPath()
                try:
                    file = open(pathname, 'w+', encoding='utf-8') # pylint: disable=consider-using-with
                    json.dump({}, file)
                    logging.info("Created new file at %s", pathname)
                    self.update_current_file_name(pathname)
                    self.current_file = file
                    break
                except IOError:
                    wx.LogError(f"Cannot create file '{pathname}'. Please choose a different location.")

    def evt_open_app_file(self, event):
        """
        Handles the event of opening a new application file.
        This method prompts the user to confirm if they want to discard changes to the current file
        if it is not saved. If confirmed, it opens a file dialog to select a JSON file. Upon selection,
        it loads the JSON content, processes the device configurations, and updates the application state.
        Args:
            event: The event that triggered this method.
        Raises:
            IOError: If the file cannot be opened.
            json.JSONDecodeError: If there is an error decoding the JSON content.
            Exception: For any other exceptions that occur during file loading.
        Side Effects:
            - Updates `self.current_file` with the opened file.
            - Updates `self.current_file_content` with the JSON content of the file.
            - Updates `self.modbus_device_config` with the device configurations from the file.
        if self.current_file is not None or not self.current_file_content.is_empty():
            - Calls `self.populate_tree_ctrl` to update the UI with the new device configurations.
        """
        # pylint: disable=unused-argument
        if self.current_file is not None or self.current_file_content.is_empty() is False:
            dialog = wx.MessageDialog(
                self,
                "Current file is not saved. Do you want to discard changes and open a new file?",
                "Confirm", wx.YES_NO | wx.NO_DEFAULT | wx.ICON_QUESTION
            )
            if dialog.ShowModal() == wx.ID_NO:
                dialog.Destroy()
                return
            dialog.Destroy()

        with wx.FileDialog(self, "Open JSON file", wildcard="JSON files (*.json)|*.json",
                    style=wx.FD_OPEN | wx.FD_FILE_MUST_EXIST) as fileDialog:

            if fileDialog.ShowModal() == wx.ID_CANCEL:
                return  # the user changed their mind

            # Proceed loading the file chosen by the user
            pathname = fileDialog.GetPath()
            try:
                self.current_file = open(pathname, 'r+', encoding='utf-8') # pylint: disable=consider-using-with
                file_content = json.load(self.current_file)
                logging.info("Loaded data from %s", pathname)
                self.current_file_content.from_dict(file_content)
                self.update_current_file_name(pathname)
                self.populate_tree_ctrl()
            except (OSError, IOError) as ioerr:
                wx.LogError(f"File error opening '{pathname}': {ioerr}")
            except json.JSONDecodeError as json_decode_err:
                wx.LogError(f"Error decoding JSON from '{pathname}': {json_decode_err}")
            except ValueError as verr:
                wx.LogError(f"Error loading data from '{pathname}': {verr}")
            except jsonschema.ValidationError as json_schema_err:
                wx.LogError(f"JSON schema validation error in '{pathname}': {json_schema_err}")

    def evt_save_app_file(self, event):
        """
        Saves the current file content to the file.

        This method checks if there is a file currently open. If no file is open, it logs an error message.
        If a file is open, it attempts to save the current content to the file by:
        - Moving the cursor to the beginning of the file.
        - Writing the current file content as JSON.
        - Truncating the file to the current position to remove any remaining old content.

        If an error occurs during the save process, it logs an error message with the exception details.

        Args:
            event: The event that triggered the save action.
        """
        # pylint: disable=unused-argument
        if self.current_file is None:
            wx.LogError("No file is currently open.")
            return
        try:
            self.current_file.seek(0)  # Move the cursor to the beginning of the file
            json.dump(self.current_file_content.to_dict(), self.current_file)
            self.current_file.truncate()  # Truncate the file to the current position
            logging.info("Saved data to file")
        except (OSError, IOError, json.JSONDecodeError) as err:
            wx.LogError(f"Error saving file: {err}")

    def evt_get_new_modbus_device_config(self, event):
        """
        Opens a dialog to configure a new Modbus device and updates the device list if the configuration is valid.

        Parameters:
        event (wx.Event): The event that triggered this method.

        Behavior:
            - Opens a modal dialog for the user to input Modbus device configuration.
            - If the user provides a valid device address and device name, the new configuration is added
                to the list of Modbus device configurations.
            - Updates the Modbus devices tree view and the current file content with the new configuration.
        """
        # pylint: disable=unused-argument
        dialog = ModbusDeviceConfigGui(
            self,
            modbus_device_config=None,
            serial_config_list=self.current_file_content.serialPorts,
            tcp_config_list=self.current_file_content.tcpPorts
        )
        dialog.ShowModal()
        if dialog.modbus_device_config:
            if dialog.modbus_device_config.device_address and dialog.modbus_device_config.device_name:
                self.current_file_content.addModbusDevice(dialog.modbus_device_config)
                self.populate_tree_ctrl()

    def evt_open_monitor_group_dialog(self, event):
        """
        Opens a dialog to configure a new monitor group and updates the monitor group list
        if the configuration is valid.

        Parameters:
            event (wx.Event): The event that triggered this method.

        Behavior:
            - Opens a modal dialog for the user to input monitor group configuration.
            - If the user provides a valid group name and poll time, the new configuration
                is added to the list of monitor groups.
            - Updates the monitor groups tree view and the current file content with the new configuration.
        """
        # pylint: disable=unused-argument
        dialog:MonitorGroupConfigGui = MonitorGroupConfigGui(
            self,
            monitor_group_config=None,
            modbus_device_list=self.current_file_content.modbusDeviceConfig
        )
        dialog.ShowModal()
        if dialog.monitor_group_config:
            if dialog.monitor_group_config.name and dialog.monitor_group_config.pollTime:
                self.current_file_content.addMonitorGroup(dialog.monitor_group_config)
                self.populate_tree_ctrl()

    def _update_serial_port(self, uid:str, serial_port:appSerialPortInfo):
        for device in self.current_file_content.modbusDeviceConfig:
            ca = device.interface_type in (ModbusDeviceConfig.INTERFACE_TYPE_RTU, \
                                           ModbusDeviceConfig.INTERFACE_TYPE_ASCII)
            if ca and 'uid' in device.interface_config:
                if device.interface_config['uid'] == uid:
                    device.configure_serial_interface_from_class(serial_port)

    def _update_tcp_port(self, uid:str, tcp_port:appTcpPortInfo):
        for device in self.current_file_content.modbusDeviceConfig:
            if device.interface_type == ModbusDeviceConfig.INTERFACE_TYPE_TCP and \
                'uid' in device.interface_config and device.interface_config['uid'] == uid:
                device.configure_tcp_interface(
                    tcp_port.ip_address,
                    tcp_port.port_number,
                    tcp_port.timeout
                )

    def evt_show_details(self, event):
        """
        Updates the properties of the selected device in the tree control.

        This method retrieves the selected item from the tree control and opens a dialog to edit the properties
        of the selected device. If the user confirms the changes, the device configuration is updated, and the
        tree control is refreshed with the new properties.

        Args:
            event: The event that triggered this method.
        """
        item = self.m_treeCtrl2.GetSelection()
        if item:
            itemData = self.m_treeCtrl2.GetItemData(item)
            if isinstance(itemData, ModbusDeviceConfig):
                logging.info("Show details of Modbus device")
                dialog = ModbusDeviceConfigGui(
                    self,
                    modbus_device_config=itemData,
                    serial_config_list=self.current_file_content.serialPorts,
                    tcp_config_list=self.current_file_content.tcpPorts
                )
                dialog.ShowModal()
                if dialog.modbus_device_config:
                    self.current_file_content.modbusDeviceConfig\
                        [self.current_file_content.modbusDeviceConfig.index(itemData)] = dialog.modbus_device_config
                    self.populate_tree_ctrl()
            elif isinstance(itemData, appSerialPortInfo):
                logging.info("Show details of Serial Port")
                dialog = SerialPortConfigGui(self, serial_port_config=itemData)
                dialog.ShowModal()
                if dialog.serial_port_config:
                    self.current_file_content.removeSerialPort(itemData.uid)
                    self.current_file_content.addSerialPort(dialog.serial_port_config)
                    self._update_serial_port(itemData.uid, dialog.serial_port_config)
                    self.populate_tree_ctrl()
            elif isinstance(itemData, appTcpPortInfo):
                logging.info("Show details of TCP Port")
                dialog = TcpPortConfigGui(self, tcp_port_config=itemData)
                dialog.ShowModal()
                if dialog.tcp_port_config:
                    self.current_file_content.removeTCPPort(itemData.uid)
                    self.current_file_content.addTCPPort(dialog.tcp_port_config)
                    self._update_tcp_port(itemData.uid, dialog.tcp_port_config)
                    self.populate_tree_ctrl()
            elif isinstance(itemData, MonitorGroup):
                logging.info("Show details of Monitor Group")
                dialog = MonitorGroupConfigGui(self, monitor_group_config=itemData,
                                                modbus_device_list=self.current_file_content.modbusDeviceConfig)
                dialog.ShowModal()
                if dialog.monitor_group_config:
                    self.current_file_content.monitorGroups\
                        [self.current_file_content.monitorGroups.index(itemData)] = dialog.monitor_group_config
                    self.populate_tree_ctrl()
            elif isinstance(itemData, ControlGroup):
                logging.info("Show details of Control Group")
                dialog = ControlGroupConfigGui(self, control_group=itemData,
                                                modbus_device_list=self.current_file_content.modbusDeviceConfig)
                dialog.ShowModal()
                if dialog.control_group_config:
                    self.current_file_content.controlGroups\
                        [self.current_file_content.controlGroups.index(itemData)] = dialog.control_group_config
                    self.populate_tree_ctrl()

    def _evt_check_connectivity(self, event):
        window = ModbusDeviceConectivityCheckGui(
            self,
            self.current_file_content.modbusDeviceConfig
        )
        window.ShowModal()

    def evt_startMonitoring(self, event):
        item = self.m_treeCtrl2.GetSelection()
        if item:
            itemData = self.m_treeCtrl2.GetItemData(item)
            if isinstance(itemData, MonitorGroup):
                logging.info("Starting monitoring for selected monitor group")
                # Open the monitor window here
                self.monitor_window_count += 1
                monitor_window = MonitorWindowGui(
                    self,
                    self.monitor_window_count,
                    monitor_group=itemData,
                    modbus_device_config=self.current_file_content.modbusDeviceConfig
                )
                monitor_window.Show()
            else:
                wx.LogError("Please select a monitor group to start monitoring.")
        else:
            wx.LogError("No item selected. Please select a monitor group to start monitoring.")

    def _evt_start_monitor_window_from_tree(self, event):
        # pylint: disable=unused-argument
        item = self.m_monitor_group_tree.GetSelection()
        if item:
            itemData = self.m_monitor_group_tree.GetItemData(item)
            if isinstance(itemData, MonitorGroup):
                logging.info("Starting monitoring for selected monitor group")
                # Open the monitor window here
                self.monitor_window_count += 1
                monitor_window = MonitorWindowGui(
                    self,
                    self.monitor_window_count,
                    monitor_group=itemData,
                    modbus_device_config=self.current_file_content.modbusDeviceConfig
                )
                monitor_window.Show()
            else:
                wx.LogError("Please select a monitor group to start monitoring.")
        else:
            wx.LogError("No item selected. Please select a monitor group to start monitoring.")

    def _evt_start_control_group_from_tree(self, event):
        # pylint: disable=unused-argument
        item = self.m_control_groups_tree.GetSelection()
        if item:
            itemData = self.m_control_groups_tree.GetItemData(item)
            if isinstance(itemData, ControlGroup):
                logging.info("Starting control for selected control group")
                # Open the control window here
                control_window = RegisterControlGroupGui(
                    self,
                    control_group=itemData,
                    modbus_device_list=self.current_file_content.modbusDeviceConfig
                )
                control_window.Show()
            else:
                wx.LogError("Please select a control group to start control.")

    def _evt_on_new_control_group(self, event):
        # pylint: disable=unused-argument
        control_group = ControlGroup("")
        dialog:ControlGroupConfigGui = ControlGroupConfigGui(
            self,
            control_group,
            self.current_file_content.modbusDeviceConfig
        )
        dialog.ShowModal()
        if dialog.control_group_config:
            if dialog.control_group_config.name:
                self.current_file_content.addControlGroup(dialog.control_group_config)

    def _evt_on_start_control_group(self, event):
        # pylint: disable=unused-argument
        item = self.m_treeCtrl2.GetSelection()
        if item:
            itemData = self.m_treeCtrl2.GetItemData(item)
            if isinstance(itemData, ControlGroup):
                logging.info("Starting control for selected control group")
                # Open the control window here
                control_window = RegisterControlGroupGui(
                    self,
                    control_group=itemData,
                    modbus_device_list=self.current_file_content.modbusDeviceConfig
                )
                control_window.Show()
            else:
                wx.LogError("Please select a control group to start control.")

def app_main():
    # pylint: disable=too-many-statements, too-many-locals
    # Create a semaphore to keep track if the user wants to close the application
    close_app_semaphore:threading.Event = threading.Event()

    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(name)s-%(asctime)s-%(levelname)s-%(message)s',
    )
    # logging.basicConfig()
    # log = logging.getLogger("pymodbus")
    # log.setLevel(logging.DEBUG)

    # open startup file
    def get_documents_path():
        """
        Returns the path to the user's Documents folder, regardless of the OS.
        """
        docs_path = ""
        if os.name == 'nt':  # Windows
            docs_path = os.path.join(os.environ['USERPROFILE'], 'Documents')
        elif os.name == 'posix':  # Linux/macOS
            docs_path = os.path.expanduser('~/Documents')
        else:
            raise OSError("Unsupported operating system")

        return docs_path

    def ensure_directory_exists(directory_path):
        """
        Checks if the given directory path exists, and creates it if it doesn't.
        """
        if not os.path.exists(directory_path):
            os.makedirs(directory_path)
            logging.info("Created directory: %s", directory_path)
        else:
            logging.info("Directory already exists: %s", directory_path)

    def load_json_schema(schema_file_path):
        """
        Loads the JSON schema from the given file path.
        """
        if os.path.exists(schema_file_path):
            try:
                with open(schema_file_path, 'r', encoding='utf-8') as file:
                    schema = json.load(file)
                    logging.info("Loaded JSON schema from %s", schema_file_path)
                    return schema
            except json.JSONDecodeError as json_decode_error:
                logging.error("Error decoding JSON schema from %s: %s", schema_file_path, json_decode_error)
                return None
        else:
            logging.error("Schema file %s does not exist.", schema_file_path)
            return None

    def load_setup_file(file_path, schema):
        """
        Checks if the setup.json file exists, opens it, validates it against the schema,
        and returns its contents as an object.
        """
        if os.path.exists(file_path):
            try:
                with open(file_path, 'r', encoding='utf-8') as file:
                    data = json.load(file)
                    jsonschema.validate(instance=data, schema=schema)
                    logging.info("Loaded and validated settings from %s", file_path)
                    return data
            except json.JSONDecodeError as json_decode_error:
                logging.error("Error decoding JSON from %s: %s", file_path, json_decode_error)
                return None
            except jsonschema.ValidationError as json_schema_error:
                logging.error("JSON schema validation error in %s: %s", file_path, json_schema_error)
                return None
        else:
            logging.warning("Setup file %s does not exist.", file_path)
            return None

    # Get the Documents folder path
    documents_path = get_documents_path()

    # Define the desired directory path
    target_directory = os.path.join(documents_path, 'www.aics.co.in', 'battery_charger_v1')

    # Ensure the directory exists
    ensure_directory_exists(target_directory)

    # Define the setup file path
    setup_file_path = os.path.join(target_directory, 'setup.json')
    # Create the setup file if it does not exist
    if not os.path.exists(setup_file_path):
        default_settings = {}
        try:
            with open(setup_file_path, 'w', encoding='utf-8') as setup_file:
                json.dump(default_settings, setup_file, indent=4)
                logging.info("Created default setup file at %s", setup_file_path)
        except IOError as io_error:
            logging.error("Error creating setup file at %s: %s", setup_file_path, io_error)

    # Load the setup file
    settings = load_setup_file(
                setup_file_path,
                load_json_schema(os.path.join(os.path.dirname(__file__), 'schema', 'schema.json'))
    )

    if settings is None:
        logging.error("Error loading settings. Exiting application.")
        return

    def start_user_interface():
        ex = wx.App(False)
        event_loop = wx.GUIEventLoop()
        wx.EventLoop.SetActive(event_loop)
        app = Application(parent=None, app_close_sem=close_app_semaphore)
        app.Show(True)
        ex.MainLoop()

    def start_modbus_server():
        modbus_server = ModbusMasterServer(app_close_event=close_app_semaphore)
        modbus_server.run()

    # Start the Modbus server in a separate thread
    modbus_thread = threading.Thread(target=start_modbus_server)
    modbus_thread.start()

    start_user_interface()

    modbus_thread.join()
