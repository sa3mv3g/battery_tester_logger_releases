# -*- coding: utf-8 -*-

###########################################################################
## Python code generated with wxFormBuilder (version 3.10.1-0-g8feb16b3)
## http://www.wxformbuilder.org/
##
## PLEASE DO *NOT* EDIT THIS FILE!
###########################################################################

import wx
import wx.xrc

###########################################################################
## Class serial_device_type_selector_dialog
###########################################################################

class serial_device_type_selector_dialog ( wx.Dialog ):

	def __init__( self, parent ):
		wx.Dialog.__init__ ( self, parent, id = wx.ID_ANY, title = u"Serial Device Selector", pos = wx.DefaultPosition, size = wx.DefaultSize, style = wx.DEFAULT_DIALOG_STYLE )

		self.SetSizeHints( wx.DefaultSize, wx.DefaultSize )

		bSizer12 = wx.BoxSizer( wx.VERTICAL )

		bSizer13 = wx.BoxSizer( wx.HORIZONTAL )

		self.m_staticText17 = wx.StaticText( self, wx.ID_ANY, u"Serial Device Type", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_staticText17.Wrap( -1 )

		bSizer13.Add( self.m_staticText17, 0, wx.ALL, 5 )

		m_choice3Choices = [ u"RTU", u"ASCII" ]
		self.m_choice3 = wx.Choice( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, m_choice3Choices, 0 )
		self.m_choice3.SetSelection( 0 )
		bSizer13.Add( self.m_choice3, 0, wx.ALL, 5 )


		bSizer12.Add( bSizer13, 1, wx.EXPAND, 5 )

		bSizer14 = wx.BoxSizer( wx.HORIZONTAL )

		self.m_button19 = wx.Button( self, wx.ID_ANY, u"Okay", wx.DefaultPosition, wx.DefaultSize, 0 )
		bSizer14.Add( self.m_button19, 0, wx.ALL, 5 )


		bSizer12.Add( bSizer14, 0, wx.EXPAND, 5 )


		self.SetSizer( bSizer12 )
		self.Layout()
		bSizer12.Fit( self )

		self.Centre( wx.BOTH )

		# Connect Events
		self.Bind( wx.EVT_CLOSE, self._evt_on_close )
		self.m_button19.Bind( wx.EVT_BUTTON, self._evt_on_close )

	def __del__( self ):
		pass


	# Virtual event handlers, override them in your derived class
	def _evt_on_close( self, event ):
		event.Skip()



