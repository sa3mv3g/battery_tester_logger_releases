import threading
import datetime
import logging
import random
import struct
import time
from typing import List, Optional, Dict, Tuple, Union
import wx
from openpyxl import Workbook
from pymodbus.payload import BinaryPayloadDecoder
from pymodbus.constants import Endian
from .usergui.monitorWindow import monitorWindow
from .common import MonitorGroup
from .common import Register
from .common import HoldingRegister
from .common import InputRegister
from .common import Coil
from .common import DiscreteInput
from .common import ANY_MODBUS_MEM_T
from .common import REGISTER_DATATYPE_I32
from .common import REGISTER_DATATYPE_U32
from .common import REGISTER_DATATYPE_F32
from .common import REGISTER_DATATYPE_U16
from .common import REGISTER_DATATYPE_I16
from .modbus_master_server import ModbusTransactionToken
from .mbDeviceConfig import ModbusDeviceConfig
from .parameter_window_gui import ParameterWindowGui
from .parameter_window_gui import ParameterWindowGui_Params
from .common import ChartDataPoint
from .modbus_master_server import ModbusMasterServer
from .modbus_master_server import DEVICE_NO_ERROR

def calculate_crc16(data):
    """
    Calculates the CRC16-Modbus checksum for a given data string.

    Args:
        data (bytes): The data to calculate the CRC for.

    Returns:
        bytes: The CRC16 checksum as a 2-byte string in little-endian format.
    """
    crc = 0xFFFF
    for byte in data:
        crc ^= byte
        for _ in range(8):
            if crc & 0x0001:
                crc >>= 1
                crc ^= 0xA001
            else:
                crc >>= 1
    return struct.pack('<H', crc)  # Little-endian

class TransactionTokenContext:
    def __init__(self):
        self.token:ModbusTransactionToken = None
        self.modbus_device_context: ModbusDeviceConfigContext = None

class ModbusRegisterContext:
    """
    This class represent an area of the monitor window
    where there would be a plot.
    This class contains all the information or method
    regarding to it.

    Indirectly it represents each register but with
    more infor on how to draw it.

    based on the number of history buffer len, the type
    of display is chosen. If it is 1 then it is a number
    display, if it is more than 1 then it is a plot display.
    """
    def __init__(self, modbus_reg:ANY_MODBUS_MEM_T, parent, sizer:wx.BoxSizer, **kwargs):
        self.modbus_register_info:ANY_MODBUS_MEM_T = modbus_reg
        self.modbus_device_info:Optional[ModbusDeviceConfig] = kwargs.get("modbus_device_info")
        self.data_table:List[ChartDataPoint] = []

        param = ParameterWindowGui_Params()
        param.register = self.modbus_register_info
        param.parent = parent
        param.sizer = sizer
        self.display = ParameterWindowGui(param)

    def add_data(self, data:ChartDataPoint):
        if isinstance(data, ChartDataPoint):
            self.data_table.append(data)
            self.display.add_data(data)

class ModbusDeviceConfigContext:
    # pylint: disable=too-many-instance-attributes

    def __init__(self, device_config:ModbusDeviceConfig):
        self.hrx_list: List[ModbusRegisterContext] = []
        self.irx_list: List[ModbusRegisterContext] = []
        self.dix_list: List[ModbusRegisterContext] = []
        self.coilsx_list: List[ModbusRegisterContext] = []

        ## Contains modbus device configuration
        self.device_config:ModbusDeviceConfig = device_config
        # of all the holding registers, this variable
        # will contain address of 1st holding regiters
        self.hr_first_address: int = 0
        self.ir_first_address: int = 0
        self.di_first_address: int = 0
        self.co_first_address: int = 0

        self.hr_request_len:int = 0
        self.ir_request_len:int = 0
        self.di_request_len:int = 0
        self.co_request_len:int = 0

    def add_register_ctx(self, register_context):
        rctx:ModbusRegisterContext = register_context
        if isinstance(rctx.modbus_register_info, HoldingRegister):
            self.hrx_list.append(rctx)
        if isinstance(rctx.modbus_register_info, InputRegister):
            self.irx_list.append(rctx)
        if isinstance(rctx.modbus_register_info, DiscreteInput):
            self.dix_list.append(rctx)
        if isinstance(rctx.modbus_register_info, Coil):
            self.coilsx_list.append(rctx)

    @staticmethod
    def _convert(_reg_ctx_list) -> Tuple[int, int]:
        if _reg_ctx_list is None:
            return None
        reg_ctx_list:List[ModbusRegisterContext] = _reg_ctx_list
        ret_val:Tuple[int, int] = (0,0)
        if len(_reg_ctx_list) == 0:
            return ret_val
        # sort the entire list based on address
        sorted(reg_ctx_list, key=lambda item: item.modbus_register_info.address)
        # calculate the number of registers based on the types
        # to be requested from the device
        num_of_items_to_request:int = 0
        # pylint: disable=C0200
        for i in range(len(reg_ctx_list)):
            _reg:ANY_MODBUS_MEM_T = reg_ctx_list[i].modbus_register_info
            _this_item_address:int = _reg.address
            _next_item_address:int = _this_item_address
            if i != (len(reg_ctx_list) - 1):
                _next_item_address = reg_ctx_list[i+1].modbus_register_info.address
            addr_diff:int = (_next_item_address - _this_item_address)
            if addr_diff <= 1:
                if _reg.dataType in (REGISTER_DATATYPE_F32, REGISTER_DATATYPE_U32, REGISTER_DATATYPE_I32):
                    num_of_items_to_request += 2
                else:
                    num_of_items_to_request += 1
            else:
                num_of_items_to_request += addr_diff

        ret_val = (reg_ctx_list[0].modbus_register_info.address, num_of_items_to_request)

        return ret_val

    def refresh_hr_calculation(self):
        if len(self.hrx_list) > 0:
            self.hr_first_address, self.hr_request_len = \
                ModbusDeviceConfigContext._convert(self.hrx_list)

    def refresh_ir_calculation(self):
        if len(self.irx_list) > 0:
            self.ir_first_address, self.ir_request_len = \
                ModbusDeviceConfigContext._convert(self.irx_list)

    def refresh_di_calculation(self):
        if len(self.dix_list) > 0:
            self.di_first_address, self.di_request_len = \
                ModbusDeviceConfigContext._convert(self.dix_list)

    def refresh_co_calculation(self):
        if len(self.coilsx_list) > 0:
            self.co_first_address, self.co_request_len = \
                ModbusDeviceConfigContext._convert(self.coilsx_list)

    def _update_from_raw_registers(
            self,
            mem_type:ANY_MODBUS_MEM_T,
            raw_payload:List[int],
            raw_start_address:int,
            raw_length:int
        ) -> Optional[List[ModbusRegisterContext]]:
        # pylint: disable=too-many-branches
        if raw_payload is None:
            return None

        reg_list: List[ModbusRegisterContext] = []

        if isinstance(mem_type, HoldingRegister):
            reg_list = self.hrx_list
        elif isinstance(mem_type, InputRegister):
            reg_list = self.irx_list
        else:
            return None

        decoder = BinaryPayloadDecoder.fromRegisters(
            raw_payload,
            byteorder=Endian.BIG,
            wordorder=Endian.BIG
        )
        active_reg:ANY_MODBUS_MEM_T = None
        _index:int = raw_start_address
        while _index < (raw_start_address + raw_length):
            incr:int  = 1
            active_reg = None
            for _reg in reg_list:
                if _reg.modbus_register_info.address == _index:
                    active_reg = _reg.modbus_register_info
                    break
            if active_reg is None:
                decoder.decode_16bit_uint()
            elif active_reg.dataType == REGISTER_DATATYPE_U16:
                active_reg.value = decoder.decode_16bit_uint()
            elif active_reg.dataType == REGISTER_DATATYPE_I16:
                active_reg.value = decoder.decode_16bit_int()
            elif active_reg.dataType == REGISTER_DATATYPE_F32:
                incr = 2
                active_reg.value = decoder.decode_32bit_float()
            elif active_reg.dataType == REGISTER_DATATYPE_U32:
                incr = 2
                active_reg.value = decoder.decode_32bit_uint()
            elif active_reg.dataType == REGISTER_DATATYPE_I32:
                incr = 2
                active_reg.value = decoder.decode_32bit_int()
            _index += incr

        return reg_list

    def _update_from_raw_bits(
            self,
            mem_type:ANY_MODBUS_MEM_T,
            raw_payload:List[bool],
            raw_start_address:int,
            raw_length:int
        ) -> Optional[List[ModbusRegisterContext]]:

        if raw_payload is None:
            return None
        reg_list: List[ModbusRegisterContext] = []

        if isinstance(mem_type, DiscreteInput):
            reg_list = self.dix_list
        elif isinstance(mem_type, Coil):
            reg_list = self.coilsx_list
        else:
            return None

        active_reg: Optional[ANY_MODBUS_MEM_T] = None
        _index:int = raw_start_address
        while _index < (raw_length + raw_start_address):
            active_reg = None
            for reg in reg_list:
                if reg.modbus_register_info.address == _index:
                    active_reg = reg.modbus_register_info
                    break
            if active_reg is not None:
                active_reg.value = raw_payload[_index - raw_start_address]
            _index += 1

        return reg_list

    def update_from_modbus_respose(
            self,
            mem_type:ANY_MODBUS_MEM_T,
            raw_payload:Union[List[bool], List[int]],
            raw_start_address:int,
            raw_length:int
    ) -> Optional[List[ModbusRegisterContext]]:
        retval : Optional[List[ModbusRegisterContext]] = None
        if isinstance(mem_type, (Coil,DiscreteInput)):
            retval = self._update_from_raw_bits(mem_type, raw_payload, raw_start_address, raw_length)
        else:
            retval = self._update_from_raw_registers(mem_type, raw_payload, raw_start_address, raw_length)

        return retval

class MonitorWindowGui(monitorWindow):
    # pylint: disable=too-many-ancestors, too-many-instance-attributes, too-many-locals, too-many-statements

    def __init__(self, parent, wid:int, monitor_group:MonitorGroup,
                 modbus_device_config:List[ModbusDeviceConfig]):

        CONTROLS_PER_TAB: int = 4
        super().__init__(parent)
        if monitor_group is None:
            wx.LogError("Monitor group is not provided.")
            self.Destroy()

        if modbus_device_config is None:
            wx.LogError("Modbus device list is not provided.")
            self.Destroy()

        self.window_open_timestamp:datetime = datetime.datetime.now().timestamp()
        self.window_id: int = wid
        self._window_alive: bool = True
        self.monitor_group: MonitorGroup = monitor_group
        self.modbus_device_config_list: List[ModbusDeviceConfig] = modbus_device_config
        self.mb_device_ctx: Dict[int, ModbusDeviceConfigContext] = {}
        self.registers_context_list: List[ModbusRegisterContext] = []

        self.SetTitle(f"Monitor Group: {self.monitor_group.name}, ID: {self.window_id}")

        m_sizers = []
        self.m_scrolledWindows = []

        # Hide tabs of the notebook
        self.m_notebook2.SetWindowStyleFlag(wx.NB_TOP | wx.NB_NOPAGETHEME)

        for mbdev in self.modbus_device_config_list:
            dctx = ModbusDeviceConfigContext(mbdev)
            self.mb_device_ctx[mbdev.device_address] = dctx

        rlen = len(self.monitor_group.registers)
        endv = rlen // CONTROLS_PER_TAB
        if rlen % CONTROLS_PER_TAB != 0:
            endv += 1
        for i in range(endv):
            w = wx.ScrolledWindow(
                self.m_notebook2, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.HSCROLL|wx.VSCROLL )
            w.SetScrollRate( 10, 10 )
            s = f"Page {i+1}"
            self.m_notebook2.AddPage( w, s.encode("utf-8"), False )
            self.m_scrolledWindows.append(w)
            m_sizers.append(wx.BoxSizer(wx.VERTICAL))

        cntr = 0
        for regRef in self.monitor_group.registers:
            reg:Optional[Register] = None
            mb_device:Optional[ModbusDeviceConfig] = None
            # find the modbus device and register from the list.
            for _device in self.modbus_device_config_list:
                if _device.device_address == regRef.device_address:
                    reg = _device.get_register_from_reference(regRef)
                    mb_device = _device
                    break

            if (reg is not None) and (mb_device is not None):
                rctx = ModbusRegisterContext(
                    modbus_reg=reg,
                    parent=self.m_scrolledWindows[cntr//CONTROLS_PER_TAB],
                    sizer=m_sizers[cntr//CONTROLS_PER_TAB],
                    modbus_device_info = mb_device
                )
                self.registers_context_list.append(rctx)
                dctx = self.mb_device_ctx[mb_device.device_address]
                dctx.add_register_ctx(rctx)
                dctx.refresh_co_calculation()
                dctx.refresh_hr_calculation()
                dctx.refresh_di_calculation()
                dctx.refresh_ir_calculation()
                cntr += 1

        for i, cw in enumerate(self.m_scrolledWindows):
            sizer = m_sizers[i]
            cw.SetVirtualSize(sizer.GetMinSize())
            cw.SetSizer(sizer)
            cw.Layout()
            sizer.Fit(cw)
        self.Layout()
        self._onPageChange(None)
        self._startTrig = threading.Event()
        self._main_worker_thread = threading.Thread(target=self._main_worker, daemon=True)
        self._main_worker_thread.start()
        self.m_timer1.Start(milliseconds=self.monitor_group.pollTime)
        self._startTrig.set()
        self.SetFocus()

    def _onPageChange(self, event):
        # pylint: disable=too-many-ancestors, too-many-instance-attributes
        active_page = self.m_notebook2.GetSelection()
        active_window = self.m_scrolledWindows[active_page]
        for rctx in self.registers_context_list:
            ctrls = rctx.display.get_control()
            for ctrl in ctrls:
                ctrl.is_window_visible = False
        controls = active_window.GetChildren()
        for control in controls:
            control.is_window_visible = True

    def _evt_on_show(self, event):
        # pylint: disable=too-many-ancestors, too-many-instance-attributes
        self.m_notebook2.SetWindowStyleFlag(wx.NB_TOP)

    def find_dict_index(self, name) -> int:
        """
        Finds the index of the first dictionary in a list where the 'name' key
        matches the provided name.

        Args:
            name: The name value to search for.

        Returns:
            The index of the dictionary if found, otherwise -1.
        """
        data = self.monitor_group.registers
        for index, dictionary in enumerate(data):
            if dictionary.get('name') is name:
                return index
        return -1

    def evt_on_close(self, event):
        """
        Event handler for the close event of the window.

        This method is called when the window is closed. It stops the timer
        and destroys the window.

        Args:
            event: The event object containing information about the close event.
        """
        # pylint: disable=unused-argument
        self._window_alive = False
        self.m_timer1.Stop()
        self._main_worker_thread.join()
        self.Destroy()

    def evt_request_data(self, event):
        # pylint: disable=unused-argument, too-many-branches, too-many-statements, too-many-locals
        """
        Callback function of timer.

        wxTimer seems to create a new thread everytime
        and so this function is always called in a
        new thread
        """
        self._startTrig.set()

    def _get_data_from_device_and_update_display(self):
        # pylint: disable=unused-argument, too-many-nested-blocks, too-many-branches

        def generate_unique_tid(wid:int, regtype:int):
            ts = datetime.datetime.now().timestamp()
            rk = random.SystemRandom().randint(0, 1000000)
            return (((wid & 0xff) << 24) | ((regtype & 0xff) << 16) | (int(ts) & 0xffff) << 8 | (rk & 0xff))

        ts = datetime.datetime.now().timestamp()
        for d_ctx in self.mb_device_ctx.values():
            REG_TYPE_HR = 0
            REG_TYPE_IR = 1
            REG_TYPE_DI = 2
            REG_TYPE_CO = 3
            if len(d_ctx.hrx_list) > 0:
                tid = generate_unique_tid(self.window_id, REG_TYPE_HR)
                token = ModbusTransactionToken(
                    tid= tid,
                    timestamp = ts,
                    starting_address = d_ctx.hr_first_address,
                    request_length= d_ctx.hr_request_len,
                    register_type=HoldingRegister(0,0),
                    device_info=d_ctx.device_config,
                    transactionCompleteSemaphore=threading.Event()
                )
                ModbusMasterServer.add_transaction(token)
                semwait = token.transactionCompleteSemaphore.wait(timeout=3.0)
                if semwait is True :
                    if token.errorResponse == DEVICE_NO_ERROR:
                        # update each register's value from the response
                        lst = d_ctx.update_from_modbus_respose(
                            token.register_type,
                            token.response,
                            token.starting_address,
                            token.request_length
                        )
                        for rctx in lst:
                            if self._window_alive is False:
                                break
                            reg = rctx.modbus_register_info
                            nval = float(reg.logging_parameters.getCalibratedNumberAsString(reg.value))
                            new_data = ChartDataPoint(
                                int(token.timestamp - self.window_open_timestamp),
                                nval,
                                token.timestamp
                            )
                            rctx.add_data(new_data)
                    else:
                        logging.error("HR TKN ERR TID=%d SA=%d LEN=%d", tid, d_ctx.hr_first_address\
                                ,d_ctx.hr_request_len)

            if len(d_ctx.irx_list) > 0:
                tid = generate_unique_tid(self.window_id, REG_TYPE_IR)
                token = ModbusTransactionToken(
                    tid=tid,
                    timestamp = ts,
                    starting_address = d_ctx.ir_first_address,
                    request_length= d_ctx.ir_request_len,
                    register_type=InputRegister(0,0),
                    device_info=d_ctx.device_config,
                    transactionCompleteSemaphore=threading.Event()
                )
                ModbusMasterServer.add_transaction(token)
                semwait = token.transactionCompleteSemaphore.wait(timeout=3.0)
                if semwait is True:
                    if token.errorResponse == DEVICE_NO_ERROR:
                        lst = d_ctx.update_from_modbus_respose(
                            token.register_type,
                            token.response,
                            token.starting_address,
                            token.request_length
                        )
                        for rctx in lst:
                            if self._window_alive is False:
                                break
                            reg = rctx.modbus_register_info
                            nval = float(reg.logging_parameters.getCalibratedNumberAsString(reg.value))
                            new_data = ChartDataPoint(
                                int(token.timestamp - self.window_open_timestamp),
                                nval,
                                token.timestamp
                            )
                            rctx.add_data(new_data)
                    else:
                        logging.error("IR TKN ERR TID=%d SA=%d LEN=%d", tid, d_ctx.ir_first_address\
                                ,d_ctx.ir_request_len)


            if len(d_ctx.dix_list) > 0:
                tid = generate_unique_tid(self.window_id, REG_TYPE_DI)
                token = ModbusTransactionToken(
                    tid=tid,
                    timestamp = ts,
                    starting_address = d_ctx.di_first_address,
                    request_length= d_ctx.di_request_len,
                    register_type=DiscreteInput(0,False),
                    device_info=d_ctx.device_config,
                    transactionCompleteSemaphore=threading.Event()
                )
                ModbusMasterServer.add_transaction(token)
                semwait = token.transactionCompleteSemaphore.wait(timeout=3.0)
                if semwait is True:
                    if token.errorResponse == DEVICE_NO_ERROR:
                        lst = d_ctx.update_from_modbus_respose(
                            token.register_type,
                            token.response,
                            token.starting_address,
                            token.request_length
                        )
                        for rctx in lst:
                            if self._window_alive is False:
                                break
                            new_data = ChartDataPoint(
                                int(token.timestamp - self.window_open_timestamp),
                                rctx.modbus_register_info.value,
                                token.timestamp
                            )
                            rctx.add_data(new_data)
                    else:
                        logging.error("DI TKN ERR TID=%d SA=%d LEN=%d", tid, d_ctx.di_first_address\
                                ,d_ctx.di_request_len)

            if len(d_ctx.coilsx_list) > 0:
                tid = generate_unique_tid(self.window_id, REG_TYPE_CO)
                token = ModbusTransactionToken(
                    tid=tid,
                    timestamp = ts,
                    starting_address = d_ctx.co_first_address,
                    request_length= d_ctx.co_request_len,
                    register_type=Coil(0,False),
                    device_info=d_ctx.device_config,
                    transactionCompleteSemaphore=threading.Event()
                )
                ModbusMasterServer.add_transaction(token)
                semwait = token.transactionCompleteSemaphore.wait(timeout=3.0)
                if semwait is True:
                    if token.errorResponse == DEVICE_NO_ERROR:
                        lst = d_ctx.update_from_modbus_respose(
                            token.register_type,
                            token.response,
                            token.starting_address,
                            token.request_length
                        )
                        for rctx in lst:
                            if self._window_alive is False:
                                break
                            new_data = ChartDataPoint(
                                int(token.timestamp - self.window_open_timestamp),
                                rctx.modbus_register_info.value,
                                token.timestamp
                            )
                            rctx.add_data(new_data)
                    else:
                        logging.error("CO TKN ERR TID=%d SA=%d LEN=%d", tid, d_ctx.co_first_address\
                                ,d_ctx.co_request_len)

    def _main_worker(self):
        """
        Main worker thread for handling Modbus communication.
        This should take more than 0.5 seconds to complete.
        It is called by the wxTimer and runs in a separate thread.
        """
        # pylint: disable=unused-argument, too-many-branches, too-many-statements, too-many-branches, too-many-locals
        # pylint: disable=too-many-nested-blocks, trailing-whitespace

        while self._window_alive:
            self._startTrig.wait(timeout=0.5)
            if self._startTrig.is_set() is False:
                continue
            self._startTrig.clear()
            # get data from each device from interface
            t0 = time.perf_counter()
            self._get_data_from_device_and_update_display()
            t1 = time.perf_counter()
            logging.info("Time taken to get data from device: %.2f ms", (t1-t0)*1000)
        logging.info("Main worker thread exiting...")

    def _evt_on_pause_timer(self, event):
        # pylint: disable=unused-argument, too-many-branches, too-many-statements, too-many-locals
        self.m_timer1.Stop()

    def _evt_on_timer_resume(self, event):
        # pylint: disable=unused-argument, too-many-branches, too-many-statements, too-many-locals
        self.m_timer1.Start()

    def _evt_on_export_to_excel(self, event):
        # pylint: disable=unused-argument, too-many-branches, too-many-statements, too-many-locals

        self._evt_on_pause_timer(event)

        # Create a new workbook and select the active worksheet
        workbook = Workbook()

        # Populate data
        for d_ctx in self.mb_device_ctx.values():
            if(len(d_ctx.hrx_list) > 0 or len(d_ctx.irx_list) > 0 or \
                    len(d_ctx.dix_list) > 0 or len(d_ctx.coilsx_list) > 0):
                excel_data = {}
                # Create a new sheet for each device
                sheet = workbook.create_sheet(title=f"Device_{d_ctx.device_config.device_address}")
                columns = []
                columns.append("Date")
                columns.append("Time")
                for hrx in d_ctx.hrx_list:
                    holding_register = hrx.modbus_register_info
                    data = hrx.data_table
                    _unit = str(holding_register.logging_parameters.unit).strip()
                    if _unit == "":
                        col_name = f"{holding_register.logging_parameters.name}"
                    else:
                        col_name = f"{holding_register.logging_parameters.name} ({_unit})"
                    columns.append(col_name)
                    for data_point in data:
                        if data_point.timestamp not in excel_data:
                            excel_data[data_point.timestamp] = {}
                        v = holding_register.logging_parameters.getCalibratedNumberAsString(data_point.y)
                        excel_data[data_point.timestamp][col_name] = v
                for irx in d_ctx.irx_list:
                    input_registers = irx.modbus_register_info
                    data = irx.data_table
                    _unit = str(input_registers.logging_parameters.unit).strip()
                    if _unit == "":
                        col_name = f"{input_registers.logging_parameters.name}"
                    else:
                        col_name = f"{input_registers.logging_parameters.name} ({_unit})"
                    columns.append(col_name)
                    for data_point in data:
                        if data_point.timestamp not in excel_data:
                            excel_data[data_point.timestamp] = {}
                        v = input_registers.logging_parameters.getCalibratedNumberAsString(data_point.y)
                        excel_data[data_point.timestamp][col_name] = v
                for dix in d_ctx.dix_list:
                    discrete_inputs = dix.modbus_register_info
                    data = dix.data_table
                    _unit = str(discrete_inputs.logging_parameters.unit).strip()
                    if _unit == "":
                        col_name = f"{discrete_inputs.logging_parameters.name}"
                    else:
                        col_name = f"{discrete_inputs.logging_parameters.name} ({_unit})"
                    columns.append(col_name)
                    for data_point in data:
                        if data_point.timestamp not in excel_data:
                            excel_data[data_point.timestamp] = {}
                        excel_data[data_point.timestamp][col_name] = data_point.y
                for cx in d_ctx.coilsx_list:
                    coilsx = cx.modbus_register_info
                    data = cx.data_table
                    _unit = str(coilsx.logging_parameters.unit).strip()
                    if _unit == "":
                        col_name = f"{coilsx.logging_parameters.name}"
                    else:
                        col_name = f"{coilsx.logging_parameters.name} ({_unit})"
                    columns.append(col_name)
                    for data_point in data:
                        if data_point.timestamp not in excel_data:
                            excel_data[data_point.timestamp] = {}
                        excel_data[data_point.timestamp][col_name] = data_point.y
                # Write headers
                sheet.append(columns)
                for ts, data in excel_data.items():
                    # instead of writing timestamp, write data and time
                    date_time = datetime.datetime.fromtimestamp(ts)
                    row = [date_time.strftime("%Y-%m-%d"), date_time.strftime("%H:%M:%S")]
                    for col in columns[2:]:
                        row.append(data.get(col, None))
                    sheet.append(row)

        # Save the workbook to a file
        file_path = wx.FileDialog(
            self,
            "Save Excel File",
            wildcard="Excel files (*.xlsx)|*.xlsx",
            style=wx.FD_SAVE | wx.FD_OVERWRITE_PROMPT
        )
        if file_path.ShowModal() == wx.ID_OK:
            workbook.save(file_path.GetPath())
            wx.LogMessage(f"Data exported successfully to {file_path.GetPath()}")
        file_path.Destroy()
        self._evt_on_timer_resume(event)
