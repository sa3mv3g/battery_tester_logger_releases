"""
A GUI class for configuring monitor groups in a battery charger application.

Args:
    parent: The parent window for this dialog.
    monitor_group_config (MonitorGroup, optional):
        The configuration for the monitor group.
    modbus_device_list (typing.List[ModbusDeviceConfig], optional):
        List of Modbus device configurations.

Attributes:
    monitor_group_config (MonitorGroup): The configuration for the monitor group.
    modbus_device_list (typing.List[ModbusDeviceConfig]): List of Modbus device configurations.

Methods:
    refresh_all_ctrls():
        Refreshes all controls in the GUI.
    populate_tree_ctrls():
        Populates the tree control with Modbus device information.
    evt_add_selection_to_monitor_group(event=None):
        Adds the selected item to the monitor group configuration.
    _update_wx_grid():
        Updates the wx grid with the monitor group configuration.
    evt_on_item_select(event=None):
        Handles the event when an item is selected in the tree control.
    evt_ok_btn(event=None):
        Handles the event when the OK button is clicked.
    evt_cancel_btn_click(event=None):
        Handles the event when the Cancel button is clicked.
"""
import typing
from typing import Optional, List, Dict
import wx
from .mbDeviceConfig import ModbusDeviceConfig
from .usergui.newMonitorGroupGui import monitorGroupDialog
from .common import Register, MonitorGroup
from .common import HoldingRegister, InputRegister, Coil, DiscreteInput
from .common import REGISTER_TYPE_DISCRETE_INPUT
from .common import REGISTER_TYPE_COILS
from .common import REGISTER_TYPE_HOLDING_REGISTER
from .common import REGISTER_TYPE_INPUT_REGISTER
from .common import RegisterReference
from .common import ANY_MODBUS_MEM_T

class MonitorGroupConfigGui(monitorGroupDialog):
    """
    A GUI class for configuring monitor groups in a battery charger application.
    Args:
        parent: The parent window for this dialog.
        monitor_group_config (MonitorGroup, optional):
            The configuration for the monitor group.
        modbus_device_list (typing.List[ModbusDeviceConfig], optional):
            List of Modbus device configurations.
    Attributes:
        monitor_group_config (MonitorGroup): The configuration for the monitor group.
        modbus_device_list (typing.List[ModbusDeviceConfig]): List of Modbus device configurations.
    Methods:
        refresh_all_ctrls():
            Refreshes all controls in the GUI.
        populate_tree_ctrls():
            Populates the tree control with Modbus device information.
        evt_add_selection_to_monitor_group(event=None):
            Adds the selected item to the monitor group configuration.
        _update_wx_grid():
            Updates the wx grid with the monitor group configuration.
        evt_on_item_select(event=None):
            Handles the event when an item is selected in the tree control.
        evt_ok_btn(event=None):
            Handles the event when the OK button is clicked.
        evt_cancel_btn_click(event=None):
            Handles the event when the Cancel button is clicked.
    """
    # pylint: disable=too-many-ancestors
    def __init__(
            self,
            parent,
            monitor_group_config:MonitorGroup = None,
            modbus_device_list:typing.List[ModbusDeviceConfig] = None
        ):
        super().__init__(parent)
        self.monitor_group_config:MonitorGroup = monitor_group_config
        self.modbus_device_list:typing.List[ModbusDeviceConfig] = modbus_device_list
        if self.monitor_group_config is None:
            self.monitor_group_config = MonitorGroup(name="", pollTime=1000, registers=[])
        self.m_textCtrl15.SetValue(self.monitor_group_config.name)
        self.m_textCtrl16.SetValue(str(self.monitor_group_config.pollTime))
        self.refresh_all_ctrls()

    def refresh_all_ctrls(self):
        """
        Refreshes all control elements in the GUI.

        This method performs the following actions:
        1. Calls `populate_tree_ctrls` to update the tree controls.
        2. Calls `_update_wx_grid` to refresh the wx grid.

        This ensures that all GUI elements display the most current data.
        """
        self.populate_tree_ctrls()
        self._update_wx_grid()

    def populate_tree_ctrls(self):
        """
        Populates the tree control with Modbus device information.
        This method clears the existing items in the tree control and populates it
        with the Modbus devices and their respective registers
        (holding registers, input registers, discrete inputs, and coils).
        Each register is added as a child item under its corresponding device.
        If no Modbus device information is available, an error message is logged.
        The tree structure is as follows:
        - Root: "Modbus Devices"
          - Device: "<device_name> (<device_address>)"
            - Holding Registers
              - Address: <address>, Label: <label>, Description: <description>, DataType: <dataType>
            - Input Registers
              - Address: <address>, Label: <label>, Description: <description>, DataType: <dataType>
            - Discrete Inputs
              - Address: <address>, Label: <label>, Description: <description>
            - Coils
              - Address: <address>, Label: <label>, Description: <description>
        The tree is expanded to show all items after population.
        Returns:
            None
        """
        # pylint: disable=unused-argument
        # pylint: disable=too-many-locals
        if not self.modbus_device_list:
            wx.LogError("No Modbus device information available.")
            return
        self.m_treeCtrl_monitor_group.DeleteAllItems()
        root = self.m_treeCtrl_monitor_group.AddRoot("Modbus Devices")
        for device in self.modbus_device_list:
            device_item = self.m_treeCtrl_monitor_group.AppendItem(
                root, f"{device.device_name} ({device.device_address})")
            holding_registers = self.m_treeCtrl_monitor_group.AppendItem(
                device_item, "Holding Registers")
            for address, register in device.holding_registers.items():
                hr = self.m_treeCtrl_monitor_group.AppendItem(holding_registers,
                        f"[{address}] {register.label} ({register.dataType})")
                self.m_treeCtrl_monitor_group.SetItemData(hr, {'reg': register, "device": device})

            input_registers = self.m_treeCtrl_monitor_group.AppendItem(
                device_item, "Input Registers")
            for address, register in device.input_registers.items():
                ir = self.m_treeCtrl_monitor_group.AppendItem(input_registers,
                    f"[{address}] {register.label} ({register.dataType})")
                self.m_treeCtrl_monitor_group.SetItemData(ir, {'reg': register, "device": device})

            discrete_inputs = self.m_treeCtrl_monitor_group.AppendItem(
                device_item, "Discrete Inputs")
            for address, di in device.discrete_inputs.items():
                dic = self.m_treeCtrl_monitor_group.AppendItem(discrete_inputs,
                    f"[{address}] {di.label}")
                self.m_treeCtrl_monitor_group.SetItemData(dic, {'reg': di, "device": device})

            coils = self.m_treeCtrl_monitor_group.AppendItem(
                device_item, "Coils")
            for address, coil in device.coils.items():
                ci = self.m_treeCtrl_monitor_group.AppendItem(coils,
                    f"[{address}] {coil.label}")
                self.m_treeCtrl_monitor_group.SetItemData(ci, {'reg': coil, "device": device})

        self.m_treeCtrl_monitor_group.ExpandAll()

    def evt_add_selection_to_monitor_group(self, event=None):
        """
        Event handler to add the selected item to the monitor group.

        This method is triggered when an item is selected in the tree control.
        It retrieves the selected item, checks if it is an instance of
        `Register`, and if it is not already in the `monitor_group_config.registers`
        list, it adds the item to the list. Finally, it updates the
        wxPython grid to reflect the changes.

        Args:
            event (wx.Event, optional): The event object. Defaults to None.
        """
        # pylint: disable=unused-argument
        item = self.m_treeCtrl_monitor_group.GetSelection()
        if item:
            itemData:Dict = self.m_treeCtrl_monitor_group.GetItemData(item)
            device:ModbusDeviceConfig = itemData['device']
            reg:ANY_MODBUS_MEM_T = itemData['reg']
            if isinstance(device, ModbusDeviceConfig):
                if reg not in self.monitor_group_config.registers:
                    reg_signature:Optional[RegisterReference] = None
                    register_type: Optional[str] = None
                    if isinstance(reg, HoldingRegister):
                        register_type = REGISTER_TYPE_HOLDING_REGISTER
                    elif isinstance(reg, InputRegister):
                        register_type = REGISTER_TYPE_INPUT_REGISTER
                    elif isinstance(reg, DiscreteInput):
                        register_type = REGISTER_TYPE_DISCRETE_INPUT
                    elif isinstance(reg, Coil):
                        register_type = REGISTER_TYPE_COILS
                    if register_type is not None:
                        reg_signature = RegisterReference(
                            register_type,
                            device.device_address,
                            reg.address
                        )
                        self.monitor_group_config.registers.append(reg_signature)
                    self._update_wx_grid()

    def _update_wx_grid(self):
        """
        Updates the wxGrid with the monitor group configuration registers.

        This method clears the existing rows in the wxGrid and populates it
        with the registers from the monitor group configuration. Each
        register's details such as address, label, data type, description,
        logging parameter name, unit, and history buffer length are set in the grid cells.

        Returns:
            None
        """
        def _get_item_by_key(array_of_dicts:List[ModbusDeviceConfig], addr) -> Optional[ModbusDeviceConfig]:
            """
            Gets the first item from an array of dictionaries where a key matches.

            Args:
                array_of_dicts: The array of dictionaries.
                key_to_find: The key to search for.

            Returns:
                The first matching dictionary, or None if not found.
            """
            for item in array_of_dicts:
                if item.device_address is addr:
                    return item
            return None
        if self.monitor_group_config.registers is None:
            return
        if len(self.monitor_group_config.registers) == 0:
            return
        self.m_grid_monitor_group.ClearGrid()
        # delete all rows
        if self.m_grid_monitor_group.GetNumberRows() > 0:
            self.m_grid_monitor_group.DeleteRows(0, self.m_grid_monitor_group.GetNumberRows())
        # start adding new rows
        for i, rs in enumerate(self.monitor_group_config.registers):
            register:Optional[Register] = None
            device:ModbusDeviceConfig = _get_item_by_key(self.modbus_device_list, rs.device_address)
            if rs.register_type is REGISTER_TYPE_DISCRETE_INPUT:
                register = device.discrete_inputs[rs.register_address]
            elif rs.register_type is REGISTER_TYPE_COILS:
                register = device.coils[rs.register_address]
            elif rs.register_type is REGISTER_TYPE_HOLDING_REGISTER:
                register = device.holding_registers[rs.register_address]
            elif rs.register_type is REGISTER_TYPE_INPUT_REGISTER:
                register = device.input_registers[rs.register_address]
            if register is not None:
                self.m_grid_monitor_group.AppendRows(1)
                self.m_grid_monitor_group.SetCellValue(i, 0, str(device.device_address))
                self.m_grid_monitor_group.SetCellValue(i, 1, str(register.address))
                self.m_grid_monitor_group.SetCellValue(i, 2, str(register.label))
                self.m_grid_monitor_group.SetCellValue(i, 3, str(register.dataType))
                self.m_grid_monitor_group.SetCellValue(i, 4, str(register.description))
                self.m_grid_monitor_group.SetCellValue(i, 5, str(register.logging_parameters.name))
                self.m_grid_monitor_group.SetCellValue(i, 6, str(register.logging_parameters.unit))
                self.m_grid_monitor_group.SetCellValue(i, 7,
                    str(register.logging_parameters.historyBufferLen)
                )

    def evt_on_item_select(self, event=None):
        """
        Handles the event when an item is selected in the monitor
        group tree control.

        Args:
            event (wx.Event, optional): The event object associated
            with the item selection. Defaults to None.

        This method retrieves the selected item from the tree control
        and updates various text controls with the item's data. If the
        item's logging parameters are not set, it initializes them with default values.
        """
        # pylint: disable=unused-argument
        item = self.m_treeCtrl_monitor_group.GetSelection()
        if item:
            itemData:any = self.m_treeCtrl_monitor_group.GetItemData(item)
            if isinstance(itemData, Register):
                self.m_textCtrl20.SetValue(str(itemData.address))
                self.m_textCtrl21.SetValue(str(itemData.label))
                self.m_textCtrl22.SetValue(str(itemData.dataType))
                self.m_textCtrl23.SetValue(str(itemData.description))
                if (itemData.logging_parameters.name is None) or (len(itemData.logging_parameters.name.strip()) == 0):
                    itemData.logging_parameters.name = itemData.label.strip()
                self.m_textCtrl17.SetValue(itemData.logging_parameters.name)
                if itemData.logging_parameters.unit is None or len(itemData.logging_parameters.unit.strip()) == 0:
                    itemData.logging_parameters.unit = ""
                self.m_textCtrl18.SetValue(itemData.logging_parameters.unit)
                if  itemData.logging_parameters.historyBufferLen is None:
                    itemData.logging_parameters.historyBufferLen = 1
                self.m_textCtrl19.SetValue(str(itemData.logging_parameters.historyBufferLen))

    def evt_ok_btn(self, event=None):
        # pylint: disable=unused-argument
        self.monitor_group_config.name = self.m_textCtrl15.GetValue()
        self.monitor_group_config.pollTime = int(self.m_textCtrl16.GetValue())
        self.Close()

    def evt_cancel_btn_click(self, event=None):
        # pylint: disable=unused-argument
        self.monitor_group_config = None
        self.Close()
