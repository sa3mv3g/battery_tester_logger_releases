from batterychargerlogger.app import app_main

if __name__ == "__main__":
    app_main()
